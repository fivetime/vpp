#ifndef __included_hpp_sfdp_api_json
#define __included_hpp_sfdp_api_json

#include <vapi/vapi.hpp>
#include <vapi/sfdp.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_tenant_add_del>(vapi_msg_sfdp_tenant_add_del *msg)
{
  vapi_msg_sfdp_tenant_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_tenant_add_del>(vapi_msg_sfdp_tenant_add_del *msg)
{
  vapi_msg_sfdp_tenant_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_tenant_add_del>()
{
  return ::vapi_msg_id_sfdp_tenant_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_tenant_add_del>>()
{
  return ::vapi_msg_id_sfdp_tenant_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_tenant_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_tenant_add_del>(vapi_msg_id_sfdp_tenant_add_del);
}

template <> inline vapi_msg_sfdp_tenant_add_del* vapi_alloc<vapi_msg_sfdp_tenant_add_del>(Connection &con)
{
  vapi_msg_sfdp_tenant_add_del* result = vapi_alloc_sfdp_tenant_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_tenant_add_del>;

template class Request<vapi_msg_sfdp_tenant_add_del, vapi_msg_sfdp_tenant_add_del_reply>;

using Sfdp_tenant_add_del = Request<vapi_msg_sfdp_tenant_add_del, vapi_msg_sfdp_tenant_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_tenant_add_del_reply>(vapi_msg_sfdp_tenant_add_del_reply *msg)
{
  vapi_msg_sfdp_tenant_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_tenant_add_del_reply>(vapi_msg_sfdp_tenant_add_del_reply *msg)
{
  vapi_msg_sfdp_tenant_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_tenant_add_del_reply>()
{
  return ::vapi_msg_id_sfdp_tenant_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_tenant_add_del_reply>>()
{
  return ::vapi_msg_id_sfdp_tenant_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_tenant_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_tenant_add_del_reply>(vapi_msg_id_sfdp_tenant_add_del_reply);
}

template class Msg<vapi_msg_sfdp_tenant_add_del_reply>;

using Sfdp_tenant_add_del_reply = Msg<vapi_msg_sfdp_tenant_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_services>(vapi_msg_sfdp_set_services *msg)
{
  vapi_msg_sfdp_set_services_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_services>(vapi_msg_sfdp_set_services *msg)
{
  vapi_msg_sfdp_set_services_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_services>()
{
  return ::vapi_msg_id_sfdp_set_services; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_services>>()
{
  return ::vapi_msg_id_sfdp_set_services; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_services()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_services>(vapi_msg_id_sfdp_set_services);
}

template <> inline vapi_msg_sfdp_set_services* vapi_alloc<vapi_msg_sfdp_set_services, size_t>(Connection &con, size_t _services_array_size)
{
  vapi_msg_sfdp_set_services* result = vapi_alloc_sfdp_set_services(con.vapi_ctx, _services_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_set_services>;

template class Request<vapi_msg_sfdp_set_services, vapi_msg_sfdp_set_services_reply, size_t>;

using Sfdp_set_services = Request<vapi_msg_sfdp_set_services, vapi_msg_sfdp_set_services_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_services_reply>(vapi_msg_sfdp_set_services_reply *msg)
{
  vapi_msg_sfdp_set_services_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_services_reply>(vapi_msg_sfdp_set_services_reply *msg)
{
  vapi_msg_sfdp_set_services_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_services_reply>()
{
  return ::vapi_msg_id_sfdp_set_services_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_services_reply>>()
{
  return ::vapi_msg_id_sfdp_set_services_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_services_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_services_reply>(vapi_msg_id_sfdp_set_services_reply);
}

template class Msg<vapi_msg_sfdp_set_services_reply>;

using Sfdp_set_services_reply = Msg<vapi_msg_sfdp_set_services_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_session_dump>(vapi_msg_sfdp_session_dump *msg)
{
  vapi_msg_sfdp_session_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_session_dump>(vapi_msg_sfdp_session_dump *msg)
{
  vapi_msg_sfdp_session_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_session_dump>()
{
  return ::vapi_msg_id_sfdp_session_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_session_dump>>()
{
  return ::vapi_msg_id_sfdp_session_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_session_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_session_dump>(vapi_msg_id_sfdp_session_dump);
}

template <> inline vapi_msg_sfdp_session_dump* vapi_alloc<vapi_msg_sfdp_session_dump>(Connection &con)
{
  vapi_msg_sfdp_session_dump* result = vapi_alloc_sfdp_session_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_session_dump>;

template class Dump<vapi_msg_sfdp_session_dump, vapi_msg_sfdp_session_details>;

using Sfdp_session_dump = Dump<vapi_msg_sfdp_session_dump, vapi_msg_sfdp_session_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_session_details>(vapi_msg_sfdp_session_details *msg)
{
  vapi_msg_sfdp_session_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_session_details>(vapi_msg_sfdp_session_details *msg)
{
  vapi_msg_sfdp_session_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_session_details>()
{
  return ::vapi_msg_id_sfdp_session_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_session_details>>()
{
  return ::vapi_msg_id_sfdp_session_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_session_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_session_details>(vapi_msg_id_sfdp_session_details);
}

template class Msg<vapi_msg_sfdp_session_details>;

using Sfdp_session_details = Msg<vapi_msg_sfdp_session_details>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_kill_session>(vapi_msg_sfdp_kill_session *msg)
{
  vapi_msg_sfdp_kill_session_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_kill_session>(vapi_msg_sfdp_kill_session *msg)
{
  vapi_msg_sfdp_kill_session_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_kill_session>()
{
  return ::vapi_msg_id_sfdp_kill_session; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_kill_session>>()
{
  return ::vapi_msg_id_sfdp_kill_session; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_kill_session()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_kill_session>(vapi_msg_id_sfdp_kill_session);
}

template <> inline vapi_msg_sfdp_kill_session* vapi_alloc<vapi_msg_sfdp_kill_session>(Connection &con)
{
  vapi_msg_sfdp_kill_session* result = vapi_alloc_sfdp_kill_session(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_kill_session>;

template class Request<vapi_msg_sfdp_kill_session, vapi_msg_sfdp_kill_session_reply>;

using Sfdp_kill_session = Request<vapi_msg_sfdp_kill_session, vapi_msg_sfdp_kill_session_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_kill_session_reply>(vapi_msg_sfdp_kill_session_reply *msg)
{
  vapi_msg_sfdp_kill_session_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_kill_session_reply>(vapi_msg_sfdp_kill_session_reply *msg)
{
  vapi_msg_sfdp_kill_session_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_kill_session_reply>()
{
  return ::vapi_msg_id_sfdp_kill_session_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_kill_session_reply>>()
{
  return ::vapi_msg_id_sfdp_kill_session_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_kill_session_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_kill_session_reply>(vapi_msg_id_sfdp_kill_session_reply);
}

template class Msg<vapi_msg_sfdp_kill_session_reply>;

using Sfdp_kill_session_reply = Msg<vapi_msg_sfdp_kill_session_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_tenant_dump>(vapi_msg_sfdp_tenant_dump *msg)
{
  vapi_msg_sfdp_tenant_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_tenant_dump>(vapi_msg_sfdp_tenant_dump *msg)
{
  vapi_msg_sfdp_tenant_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_tenant_dump>()
{
  return ::vapi_msg_id_sfdp_tenant_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_tenant_dump>>()
{
  return ::vapi_msg_id_sfdp_tenant_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_tenant_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_tenant_dump>(vapi_msg_id_sfdp_tenant_dump);
}

template <> inline vapi_msg_sfdp_tenant_dump* vapi_alloc<vapi_msg_sfdp_tenant_dump>(Connection &con)
{
  vapi_msg_sfdp_tenant_dump* result = vapi_alloc_sfdp_tenant_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_tenant_dump>;

template class Dump<vapi_msg_sfdp_tenant_dump, vapi_msg_sfdp_tenant_details>;

using Sfdp_tenant_dump = Dump<vapi_msg_sfdp_tenant_dump, vapi_msg_sfdp_tenant_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_tenant_details>(vapi_msg_sfdp_tenant_details *msg)
{
  vapi_msg_sfdp_tenant_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_tenant_details>(vapi_msg_sfdp_tenant_details *msg)
{
  vapi_msg_sfdp_tenant_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_tenant_details>()
{
  return ::vapi_msg_id_sfdp_tenant_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_tenant_details>>()
{
  return ::vapi_msg_id_sfdp_tenant_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_tenant_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_tenant_details>(vapi_msg_id_sfdp_tenant_details);
}

template class Msg<vapi_msg_sfdp_tenant_details>;

using Sfdp_tenant_details = Msg<vapi_msg_sfdp_tenant_details>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_timeout>(vapi_msg_sfdp_set_timeout *msg)
{
  vapi_msg_sfdp_set_timeout_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_timeout>(vapi_msg_sfdp_set_timeout *msg)
{
  vapi_msg_sfdp_set_timeout_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_timeout>()
{
  return ::vapi_msg_id_sfdp_set_timeout; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_timeout>>()
{
  return ::vapi_msg_id_sfdp_set_timeout; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_timeout()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_timeout>(vapi_msg_id_sfdp_set_timeout);
}

template <> inline vapi_msg_sfdp_set_timeout* vapi_alloc<vapi_msg_sfdp_set_timeout>(Connection &con)
{
  vapi_msg_sfdp_set_timeout* result = vapi_alloc_sfdp_set_timeout(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_set_timeout>;

template class Request<vapi_msg_sfdp_set_timeout, vapi_msg_sfdp_set_timeout_reply>;

using Sfdp_set_timeout = Request<vapi_msg_sfdp_set_timeout, vapi_msg_sfdp_set_timeout_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_timeout_reply>(vapi_msg_sfdp_set_timeout_reply *msg)
{
  vapi_msg_sfdp_set_timeout_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_timeout_reply>(vapi_msg_sfdp_set_timeout_reply *msg)
{
  vapi_msg_sfdp_set_timeout_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_timeout_reply>()
{
  return ::vapi_msg_id_sfdp_set_timeout_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_timeout_reply>>()
{
  return ::vapi_msg_id_sfdp_set_timeout_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_timeout_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_timeout_reply>(vapi_msg_id_sfdp_set_timeout_reply);
}

template class Msg<vapi_msg_sfdp_set_timeout_reply>;

using Sfdp_set_timeout_reply = Msg<vapi_msg_sfdp_set_timeout_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_sp_node>(vapi_msg_sfdp_set_sp_node *msg)
{
  vapi_msg_sfdp_set_sp_node_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_sp_node>(vapi_msg_sfdp_set_sp_node *msg)
{
  vapi_msg_sfdp_set_sp_node_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_sp_node>()
{
  return ::vapi_msg_id_sfdp_set_sp_node; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_sp_node>>()
{
  return ::vapi_msg_id_sfdp_set_sp_node; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_sp_node()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_sp_node>(vapi_msg_id_sfdp_set_sp_node);
}

template <> inline vapi_msg_sfdp_set_sp_node* vapi_alloc<vapi_msg_sfdp_set_sp_node>(Connection &con)
{
  vapi_msg_sfdp_set_sp_node* result = vapi_alloc_sfdp_set_sp_node(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_set_sp_node>;

template class Request<vapi_msg_sfdp_set_sp_node, vapi_msg_sfdp_set_sp_node_reply>;

using Sfdp_set_sp_node = Request<vapi_msg_sfdp_set_sp_node, vapi_msg_sfdp_set_sp_node_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_sp_node_reply>(vapi_msg_sfdp_set_sp_node_reply *msg)
{
  vapi_msg_sfdp_set_sp_node_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_sp_node_reply>(vapi_msg_sfdp_set_sp_node_reply *msg)
{
  vapi_msg_sfdp_set_sp_node_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_sp_node_reply>()
{
  return ::vapi_msg_id_sfdp_set_sp_node_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_sp_node_reply>>()
{
  return ::vapi_msg_id_sfdp_set_sp_node_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_sp_node_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_sp_node_reply>(vapi_msg_id_sfdp_set_sp_node_reply);
}

template class Msg<vapi_msg_sfdp_set_sp_node_reply>;

using Sfdp_set_sp_node_reply = Msg<vapi_msg_sfdp_set_sp_node_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_icmp_error_node>(vapi_msg_sfdp_set_icmp_error_node *msg)
{
  vapi_msg_sfdp_set_icmp_error_node_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_icmp_error_node>(vapi_msg_sfdp_set_icmp_error_node *msg)
{
  vapi_msg_sfdp_set_icmp_error_node_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_icmp_error_node>()
{
  return ::vapi_msg_id_sfdp_set_icmp_error_node; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_icmp_error_node>>()
{
  return ::vapi_msg_id_sfdp_set_icmp_error_node; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_icmp_error_node()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_icmp_error_node>(vapi_msg_id_sfdp_set_icmp_error_node);
}

template <> inline vapi_msg_sfdp_set_icmp_error_node* vapi_alloc<vapi_msg_sfdp_set_icmp_error_node>(Connection &con)
{
  vapi_msg_sfdp_set_icmp_error_node* result = vapi_alloc_sfdp_set_icmp_error_node(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_set_icmp_error_node>;

template class Request<vapi_msg_sfdp_set_icmp_error_node, vapi_msg_sfdp_set_icmp_error_node_reply>;

using Sfdp_set_icmp_error_node = Request<vapi_msg_sfdp_set_icmp_error_node, vapi_msg_sfdp_set_icmp_error_node_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_set_icmp_error_node_reply>(vapi_msg_sfdp_set_icmp_error_node_reply *msg)
{
  vapi_msg_sfdp_set_icmp_error_node_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_set_icmp_error_node_reply>(vapi_msg_sfdp_set_icmp_error_node_reply *msg)
{
  vapi_msg_sfdp_set_icmp_error_node_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_set_icmp_error_node_reply>()
{
  return ::vapi_msg_id_sfdp_set_icmp_error_node_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_set_icmp_error_node_reply>>()
{
  return ::vapi_msg_id_sfdp_set_icmp_error_node_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_set_icmp_error_node_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_set_icmp_error_node_reply>(vapi_msg_id_sfdp_set_icmp_error_node_reply);
}

template class Msg<vapi_msg_sfdp_set_icmp_error_node_reply>;

using Sfdp_set_icmp_error_node_reply = Msg<vapi_msg_sfdp_set_icmp_error_node_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_service_dump>(vapi_msg_sfdp_service_dump *msg)
{
  vapi_msg_sfdp_service_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_service_dump>(vapi_msg_sfdp_service_dump *msg)
{
  vapi_msg_sfdp_service_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_service_dump>()
{
  return ::vapi_msg_id_sfdp_service_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_service_dump>>()
{
  return ::vapi_msg_id_sfdp_service_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_service_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_service_dump>(vapi_msg_id_sfdp_service_dump);
}

template <> inline vapi_msg_sfdp_service_dump* vapi_alloc<vapi_msg_sfdp_service_dump>(Connection &con)
{
  vapi_msg_sfdp_service_dump* result = vapi_alloc_sfdp_service_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_service_dump>;

template class Dump<vapi_msg_sfdp_service_dump, vapi_msg_sfdp_service_details>;

using Sfdp_service_dump = Dump<vapi_msg_sfdp_service_dump, vapi_msg_sfdp_service_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_service_details>(vapi_msg_sfdp_service_details *msg)
{
  vapi_msg_sfdp_service_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_service_details>(vapi_msg_sfdp_service_details *msg)
{
  vapi_msg_sfdp_service_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_service_details>()
{
  return ::vapi_msg_id_sfdp_service_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_service_details>>()
{
  return ::vapi_msg_id_sfdp_service_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_service_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_service_details>(vapi_msg_id_sfdp_service_details);
}

template class Msg<vapi_msg_sfdp_service_details>;

using Sfdp_service_details = Msg<vapi_msg_sfdp_service_details>;
}
#endif

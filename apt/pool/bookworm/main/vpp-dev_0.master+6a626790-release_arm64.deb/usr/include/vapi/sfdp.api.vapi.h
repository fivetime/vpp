#ifndef __included_sfdp_api_json
#define __included_sfdp_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_sfdp_tenant_add_del;
extern vapi_msg_id_t vapi_msg_id_sfdp_tenant_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_services;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_services_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_session_dump;
extern vapi_msg_id_t vapi_msg_id_sfdp_session_details;
extern vapi_msg_id_t vapi_msg_id_sfdp_kill_session;
extern vapi_msg_id_t vapi_msg_id_sfdp_kill_session_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_tenant_dump;
extern vapi_msg_id_t vapi_msg_id_sfdp_tenant_details;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_timeout;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_timeout_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_sp_node;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_sp_node_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_icmp_error_node;
extern vapi_msg_id_t vapi_msg_id_sfdp_set_icmp_error_node_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_service_dump;
extern vapi_msg_id_t vapi_msg_id_sfdp_service_details;

#define DEFINE_VAPI_MSG_IDS_SFDP_API_JSON\
  vapi_msg_id_t vapi_msg_id_sfdp_tenant_add_del;\
  vapi_msg_id_t vapi_msg_id_sfdp_tenant_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_services;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_services_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_session_dump;\
  vapi_msg_id_t vapi_msg_id_sfdp_session_details;\
  vapi_msg_id_t vapi_msg_id_sfdp_kill_session;\
  vapi_msg_id_t vapi_msg_id_sfdp_kill_session_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_tenant_dump;\
  vapi_msg_id_t vapi_msg_id_sfdp_tenant_details;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_timeout;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_timeout_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_sp_node;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_sp_node_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_icmp_error_node;\
  vapi_msg_id_t vapi_msg_id_sfdp_set_icmp_error_node_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_service_dump;\
  vapi_msg_id_t vapi_msg_id_sfdp_service_details;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_direction
#define __vapi_def_defined_vapi_enum_sfdp_session_direction
typedef enum {
  SFDP_API_FORWARD = 0,
  SFDP_API_REVERSE = 1,
} __attribute__((packed)) vapi_enum_sfdp_session_direction;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_direction
#define __vapi_code_defined_vapi_enum_sfdp_session_direction
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_state
#define __vapi_def_defined_vapi_enum_sfdp_session_state
typedef enum {
  SFDP_API_SESSION_STATE_FSOL = 0,
  SFDP_API_SESSION_STATE_ESTABLISHED = 1,
  SFDP_API_SESSION_STATE_TIME_WAIT = 2,
} __attribute__((packed)) vapi_enum_sfdp_session_state;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_state
#define __vapi_code_defined_vapi_enum_sfdp_session_state
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_sp_node
#define __vapi_def_defined_vapi_enum_sfdp_sp_node
typedef enum {
  SFDP_API_SP_NODE_IP4_REASS = 0,
  SFDP_API_SP_NODE_IP6_REASS = 1,
  SFDP_API_SP_NODE_IP4_UNKNOWN_PROTO = 2,
  SFDP_API_SP_NODE_IP6_UNKNOWN_PROTO = 3,
  SFDP_API_SP_NODE_IP4_ICMP4_ERROR = 4,
  SFDP_API_SP_NODE_IP6_ICMP6_ERROR = 5,
} __attribute__((packed)) vapi_enum_sfdp_sp_node;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_sp_node
#define __vapi_code_defined_vapi_enum_sfdp_sp_node
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_type
#define __vapi_def_defined_vapi_enum_sfdp_session_type
typedef enum {
  SFDP_API_SESSION_TYPE_IP4 = 0,
  SFDP_API_SESSION_TYPE_IP6 = 1,
  SFDP_API_SESSION_TYPE_USER = 2,
} __attribute__((packed)) vapi_enum_sfdp_session_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_type
#define __vapi_code_defined_vapi_enum_sfdp_session_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_sfdp_service_name
#define __vapi_def_defined_vapi_type_sfdp_service_name
typedef struct __attribute__((__packed__)) {
  u8 data[32];
} vapi_type_sfdp_service_name;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_sfdp_service_name
#define __vapi_code_defined_vapi_type_sfdp_service_name
static inline void vapi_type_sfdp_service_name_hton(vapi_type_sfdp_service_name *msg)
{

}

static inline void vapi_type_sfdp_service_name_ntoh(vapi_type_sfdp_service_name *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_sfdp_session_key
#define __vapi_def_defined_vapi_type_sfdp_session_key
typedef struct __attribute__((__packed__)) {
  u32 context_id;
  vapi_type_address init_addr;
  u16 init_port;
  vapi_type_address resp_addr;
  u16 resp_port;
} vapi_type_sfdp_session_key;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_sfdp_session_key
#define __vapi_code_defined_vapi_type_sfdp_session_key
static inline void vapi_type_sfdp_session_key_hton(vapi_type_sfdp_session_key *msg)
{
  msg->context_id = htobe32(msg->context_id);
  msg->init_port = htobe16(msg->init_port);
  msg->resp_port = htobe16(msg->resp_port);
}

static inline void vapi_type_sfdp_session_key_ntoh(vapi_type_sfdp_session_key *msg)
{
  msg->context_id = be32toh(msg->context_id);
  msg->init_port = be16toh(msg->init_port);
  msg->resp_port = be16toh(msg->resp_port);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tenant_add_del_reply
#define __vapi_def_defined_vapi_msg_sfdp_tenant_add_del_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_tenant_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_tenant_add_del_reply payload;
} vapi_msg_sfdp_tenant_add_del_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tenant_add_del_reply
#define __vapi_code_defined_vapi_msg_sfdp_tenant_add_del_reply
static inline void vapi_msg_sfdp_tenant_add_del_reply_payload_hton(vapi_payload_sfdp_tenant_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_tenant_add_del_reply_payload_ntoh(vapi_payload_sfdp_tenant_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_tenant_add_del_reply_hton(vapi_msg_sfdp_tenant_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_tenant_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_tenant_add_del_reply_ntoh(vapi_msg_sfdp_tenant_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_tenant_add_del_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_tenant_add_del_reply_msg_size(vapi_msg_sfdp_tenant_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_tenant_add_del_reply_msg_size(vapi_msg_sfdp_tenant_add_del_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tenant_add_del_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_add_del_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tenant_add_del_reply));
      return -1;
    }
  if (vapi_calc_sfdp_tenant_add_del_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_add_del_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tenant_add_del_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_tenant_add_del_reply()
{
  static const char name[] = "sfdp_tenant_add_del_reply";
  static const char name_with_crc[] = "sfdp_tenant_add_del_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_tenant_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_tenant_add_del_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_tenant_add_del_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_add_del_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tenant_add_del_reply = vapi_register_msg(&__vapi_metadata_sfdp_tenant_add_del_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_tenant_add_del_reply", vapi_msg_id_sfdp_tenant_add_del_reply);
}

static inline void vapi_set_vapi_msg_sfdp_tenant_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_tenant_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_tenant_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tenant_add_del
#define __vapi_def_defined_vapi_msg_sfdp_tenant_add_del
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  u32 context_id;
  bool is_del; 
} vapi_payload_sfdp_tenant_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_tenant_add_del payload;
} vapi_msg_sfdp_tenant_add_del;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tenant_add_del
#define __vapi_code_defined_vapi_msg_sfdp_tenant_add_del
static inline void vapi_msg_sfdp_tenant_add_del_payload_hton(vapi_payload_sfdp_tenant_add_del *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->context_id = htobe32(payload->context_id);
}

static inline void vapi_msg_sfdp_tenant_add_del_payload_ntoh(vapi_payload_sfdp_tenant_add_del *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->context_id = be32toh(payload->context_id);
}

static inline void vapi_msg_sfdp_tenant_add_del_hton(vapi_msg_sfdp_tenant_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_tenant_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_tenant_add_del_ntoh(vapi_msg_sfdp_tenant_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_tenant_add_del_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_tenant_add_del_msg_size(vapi_msg_sfdp_tenant_add_del *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_tenant_add_del_msg_size(vapi_msg_sfdp_tenant_add_del *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tenant_add_del) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_add_del' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tenant_add_del));
      return -1;
    }
  if (vapi_calc_sfdp_tenant_add_del_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_add_del' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tenant_add_del_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_tenant_add_del* vapi_alloc_sfdp_tenant_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_tenant_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_tenant_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_tenant_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_tenant_add_del);

  return msg;
}

static inline vapi_error_e vapi_sfdp_tenant_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_tenant_add_del *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_tenant_add_del_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_tenant_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_tenant_add_del_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_tenant_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_tenant_add_del()
{
  static const char name[] = "sfdp_tenant_add_del";
  static const char name_with_crc[] = "sfdp_tenant_add_del_f03b121c";
  static vapi_message_desc_t __vapi_metadata_sfdp_tenant_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_tenant_add_del, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_tenant_add_del_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_add_del_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_add_del_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tenant_add_del = vapi_register_msg(&__vapi_metadata_sfdp_tenant_add_del);
  VAPI_DBG("Assigned msg id %d to sfdp_tenant_add_del", vapi_msg_id_sfdp_tenant_add_del);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_services_reply
#define __vapi_def_defined_vapi_msg_sfdp_set_services_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_set_services_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_set_services_reply payload;
} vapi_msg_sfdp_set_services_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_services_reply
#define __vapi_code_defined_vapi_msg_sfdp_set_services_reply
static inline void vapi_msg_sfdp_set_services_reply_payload_hton(vapi_payload_sfdp_set_services_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_set_services_reply_payload_ntoh(vapi_payload_sfdp_set_services_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_set_services_reply_hton(vapi_msg_sfdp_set_services_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_services_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_set_services_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_services_reply_ntoh(vapi_msg_sfdp_set_services_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_services_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_services_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_services_reply_msg_size(vapi_msg_sfdp_set_services_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_services_reply_msg_size(vapi_msg_sfdp_set_services_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_services_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_services_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_services_reply));
      return -1;
    }
  if (vapi_calc_sfdp_set_services_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_services_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_services_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_set_services_reply()
{
  static const char name[] = "sfdp_set_services_reply";
  static const char name_with_crc[] = "sfdp_set_services_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_services_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_set_services_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_services_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_services_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_services_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_services_reply = vapi_register_msg(&__vapi_metadata_sfdp_set_services_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_set_services_reply", vapi_msg_id_sfdp_set_services_reply);
}

static inline void vapi_set_vapi_msg_sfdp_set_services_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_set_services_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_set_services_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_services
#define __vapi_def_defined_vapi_msg_sfdp_set_services
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  vapi_enum_sfdp_session_direction dir;
  u8 n_services;
  vapi_type_sfdp_service_name services[0]; 
} vapi_payload_sfdp_set_services;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_set_services payload;
} vapi_msg_sfdp_set_services;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_services
#define __vapi_code_defined_vapi_msg_sfdp_set_services
static inline void vapi_msg_sfdp_set_services_payload_hton(vapi_payload_sfdp_set_services *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
}

static inline void vapi_msg_sfdp_set_services_payload_ntoh(vapi_payload_sfdp_set_services *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
}

static inline void vapi_msg_sfdp_set_services_hton(vapi_msg_sfdp_set_services *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_services'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_set_services_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_services_ntoh(vapi_msg_sfdp_set_services *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_services'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_services_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_services_msg_size(vapi_msg_sfdp_set_services *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.services[0]) * msg->payload.n_services;
}

static inline int vapi_verify_sfdp_set_services_msg_size(vapi_msg_sfdp_set_services *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_services) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_services' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_services));
      return -1;
    }
  if (vapi_calc_sfdp_set_services_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_services' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_services_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_set_services* vapi_alloc_sfdp_set_services(struct vapi_ctx_s *ctx, size_t _services_array_size)
{
  vapi_msg_sfdp_set_services *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_set_services) + sizeof(msg->payload.services[0]) * _services_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_set_services*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_set_services);
  msg->payload.n_services = _services_array_size;

  return msg;
}

static inline vapi_error_e vapi_sfdp_set_services(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_set_services *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_set_services_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_set_services_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_set_services_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_set_services_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_set_services()
{
  static const char name[] = "sfdp_set_services";
  static const char name_with_crc[] = "sfdp_set_services_6227a034";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_services = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_set_services, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_services_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_services_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_services_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_services = vapi_register_msg(&__vapi_metadata_sfdp_set_services);
  VAPI_DBG("Assigned msg id %d to sfdp_set_services", vapi_msg_id_sfdp_set_services);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_session_details
#define __vapi_def_defined_vapi_msg_sfdp_session_details
typedef struct __attribute__ ((__packed__)) {
  u64 session_id;
  u32 thread_index;
  u32 tenant_id;
  u32 session_idx;
  vapi_enum_sfdp_session_type session_type;
  vapi_enum_ip_proto protocol;
  vapi_enum_sfdp_session_state state;
  f64 remaining_time;
  u64 forward_bitmap;
  u64 reverse_bitmap;
  u8 n_keys;
  vapi_type_sfdp_session_key keys[0]; 
} vapi_payload_sfdp_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_session_details payload;
} vapi_msg_sfdp_session_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_session_details
#define __vapi_code_defined_vapi_msg_sfdp_session_details
static inline void vapi_msg_sfdp_session_details_payload_hton(vapi_payload_sfdp_session_details *payload)
{
  payload->session_id = htobe64(payload->session_id);
  payload->thread_index = htobe32(payload->thread_index);
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->session_idx = htobe32(payload->session_idx);
  payload->forward_bitmap = htobe64(payload->forward_bitmap);
  payload->reverse_bitmap = htobe64(payload->reverse_bitmap);
  do { unsigned i; for (i = 0; i < payload->n_keys; ++i) { vapi_type_sfdp_session_key_hton(&payload->keys[i]); } } while(0);
}

static inline void vapi_msg_sfdp_session_details_payload_ntoh(vapi_payload_sfdp_session_details *payload)
{
  payload->session_id = be64toh(payload->session_id);
  payload->thread_index = be32toh(payload->thread_index);
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->session_idx = be32toh(payload->session_idx);
  payload->forward_bitmap = be64toh(payload->forward_bitmap);
  payload->reverse_bitmap = be64toh(payload->reverse_bitmap);
  do { unsigned i; for (i = 0; i < payload->n_keys; ++i) { vapi_type_sfdp_session_key_ntoh(&payload->keys[i]); } } while(0);
}

static inline void vapi_msg_sfdp_session_details_hton(vapi_msg_sfdp_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_session_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_session_details_ntoh(vapi_msg_sfdp_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_session_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_session_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_session_details_msg_size(vapi_msg_sfdp_session_details *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.keys[0]) * msg->payload.n_keys;
}

static inline int vapi_verify_sfdp_session_details_msg_size(vapi_msg_sfdp_session_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_session_details) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_session_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_session_details));
      return -1;
    }
  if (vapi_calc_sfdp_session_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_session_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_session_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_session_details()
{
  static const char name[] = "sfdp_session_details";
  static const char name_with_crc[] = "sfdp_session_details_3eaab6b9";
  static vapi_message_desc_t __vapi_metadata_sfdp_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_session_details, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_session_details_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_session_details_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_session_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_session_details = vapi_register_msg(&__vapi_metadata_sfdp_session_details);
  VAPI_DBG("Assigned msg id %d to sfdp_session_details", vapi_msg_id_sfdp_session_details);
}

static inline void vapi_set_vapi_msg_sfdp_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_session_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_session_dump
#define __vapi_def_defined_vapi_msg_sfdp_session_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_sfdp_session_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_session_dump
#define __vapi_code_defined_vapi_msg_sfdp_session_dump
static inline void vapi_msg_sfdp_session_dump_hton(vapi_msg_sfdp_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_sfdp_session_dump_ntoh(vapi_msg_sfdp_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_sfdp_session_dump_msg_size(vapi_msg_sfdp_session_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_session_dump_msg_size(vapi_msg_sfdp_session_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_session_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_session_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_session_dump));
      return -1;
    }
  if (vapi_calc_sfdp_session_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_session_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_session_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_session_dump* vapi_alloc_sfdp_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_session_dump);

  return msg;
}

static inline vapi_error_e vapi_sfdp_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_session_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_session_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_session_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_session_dump()
{
  static const char name[] = "sfdp_session_dump";
  static const char name_with_crc[] = "sfdp_session_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_sfdp_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_sfdp_session_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_session_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_session_dump = vapi_register_msg(&__vapi_metadata_sfdp_session_dump);
  VAPI_DBG("Assigned msg id %d to sfdp_session_dump", vapi_msg_id_sfdp_session_dump);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_kill_session_reply
#define __vapi_def_defined_vapi_msg_sfdp_kill_session_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_kill_session_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_kill_session_reply payload;
} vapi_msg_sfdp_kill_session_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_kill_session_reply
#define __vapi_code_defined_vapi_msg_sfdp_kill_session_reply
static inline void vapi_msg_sfdp_kill_session_reply_payload_hton(vapi_payload_sfdp_kill_session_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_kill_session_reply_payload_ntoh(vapi_payload_sfdp_kill_session_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_kill_session_reply_hton(vapi_msg_sfdp_kill_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_kill_session_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_kill_session_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_kill_session_reply_ntoh(vapi_msg_sfdp_kill_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_kill_session_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_kill_session_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_kill_session_reply_msg_size(vapi_msg_sfdp_kill_session_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_kill_session_reply_msg_size(vapi_msg_sfdp_kill_session_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_kill_session_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_kill_session_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_kill_session_reply));
      return -1;
    }
  if (vapi_calc_sfdp_kill_session_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_kill_session_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_kill_session_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_kill_session_reply()
{
  static const char name[] = "sfdp_kill_session_reply";
  static const char name_with_crc[] = "sfdp_kill_session_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_kill_session_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_kill_session_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_kill_session_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_kill_session_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_kill_session_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_kill_session_reply = vapi_register_msg(&__vapi_metadata_sfdp_kill_session_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_kill_session_reply", vapi_msg_id_sfdp_kill_session_reply);
}

static inline void vapi_set_vapi_msg_sfdp_kill_session_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_kill_session_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_kill_session_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_kill_session
#define __vapi_def_defined_vapi_msg_sfdp_kill_session
typedef struct __attribute__ ((__packed__)) {
  u32 session_index;
  bool is_all; 
} vapi_payload_sfdp_kill_session;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_kill_session payload;
} vapi_msg_sfdp_kill_session;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_kill_session
#define __vapi_code_defined_vapi_msg_sfdp_kill_session
static inline void vapi_msg_sfdp_kill_session_payload_hton(vapi_payload_sfdp_kill_session *payload)
{
  payload->session_index = htobe32(payload->session_index);
}

static inline void vapi_msg_sfdp_kill_session_payload_ntoh(vapi_payload_sfdp_kill_session *payload)
{
  payload->session_index = be32toh(payload->session_index);
}

static inline void vapi_msg_sfdp_kill_session_hton(vapi_msg_sfdp_kill_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_kill_session'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_kill_session_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_kill_session_ntoh(vapi_msg_sfdp_kill_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_kill_session'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_kill_session_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_kill_session_msg_size(vapi_msg_sfdp_kill_session *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_kill_session_msg_size(vapi_msg_sfdp_kill_session *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_kill_session) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_kill_session' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_kill_session));
      return -1;
    }
  if (vapi_calc_sfdp_kill_session_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_kill_session' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_kill_session_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_kill_session* vapi_alloc_sfdp_kill_session(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_kill_session *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_kill_session);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_kill_session*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_kill_session);

  return msg;
}

static inline vapi_error_e vapi_sfdp_kill_session(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_kill_session *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_kill_session_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_kill_session_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_kill_session_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_kill_session_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_kill_session()
{
  static const char name[] = "sfdp_kill_session";
  static const char name_with_crc[] = "sfdp_kill_session_1a16d196";
  static vapi_message_desc_t __vapi_metadata_sfdp_kill_session = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_kill_session, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_kill_session_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_kill_session_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_kill_session_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_kill_session = vapi_register_msg(&__vapi_metadata_sfdp_kill_session);
  VAPI_DBG("Assigned msg id %d to sfdp_kill_session", vapi_msg_id_sfdp_kill_session);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tenant_details
#define __vapi_def_defined_vapi_msg_sfdp_tenant_details
typedef struct __attribute__ ((__packed__)) {
  u32 index;
  u32 context_id;
  u64 forward_bitmap;
  u64 reverse_bitmap;
  u32 n_timeout;
  u32 timeout[0]; 
} vapi_payload_sfdp_tenant_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_tenant_details payload;
} vapi_msg_sfdp_tenant_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tenant_details
#define __vapi_code_defined_vapi_msg_sfdp_tenant_details
static inline void vapi_msg_sfdp_tenant_details_payload_hton(vapi_payload_sfdp_tenant_details *payload)
{
  payload->index = htobe32(payload->index);
  payload->context_id = htobe32(payload->context_id);
  payload->forward_bitmap = htobe64(payload->forward_bitmap);
  payload->reverse_bitmap = htobe64(payload->reverse_bitmap);
  payload->n_timeout = htobe32(payload->n_timeout);
  do { unsigned i; for (i = 0; i < be32toh(payload->n_timeout); ++i) { payload->timeout[i] = htobe32(payload->timeout[i]); } } while(0);
}

static inline void vapi_msg_sfdp_tenant_details_payload_ntoh(vapi_payload_sfdp_tenant_details *payload)
{
  payload->index = be32toh(payload->index);
  payload->context_id = be32toh(payload->context_id);
  payload->forward_bitmap = be64toh(payload->forward_bitmap);
  payload->reverse_bitmap = be64toh(payload->reverse_bitmap);
  payload->n_timeout = be32toh(payload->n_timeout);
  do { unsigned i; for (i = 0; i < payload->n_timeout; ++i) { payload->timeout[i] = be32toh(payload->timeout[i]); } } while(0);
}

static inline void vapi_msg_sfdp_tenant_details_hton(vapi_msg_sfdp_tenant_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_tenant_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_tenant_details_ntoh(vapi_msg_sfdp_tenant_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_tenant_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_tenant_details_msg_size(vapi_msg_sfdp_tenant_details *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.timeout[0]) * msg->payload.n_timeout;
}

static inline int vapi_verify_sfdp_tenant_details_msg_size(vapi_msg_sfdp_tenant_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tenant_details) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tenant_details));
      return -1;
    }
  if (vapi_calc_sfdp_tenant_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tenant_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_tenant_details()
{
  static const char name[] = "sfdp_tenant_details";
  static const char name_with_crc[] = "sfdp_tenant_details_128e06c3";
  static vapi_message_desc_t __vapi_metadata_sfdp_tenant_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_tenant_details, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_tenant_details_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_details_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tenant_details = vapi_register_msg(&__vapi_metadata_sfdp_tenant_details);
  VAPI_DBG("Assigned msg id %d to sfdp_tenant_details", vapi_msg_id_sfdp_tenant_details);
}

static inline void vapi_set_vapi_msg_sfdp_tenant_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_tenant_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_tenant_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tenant_dump
#define __vapi_def_defined_vapi_msg_sfdp_tenant_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_sfdp_tenant_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tenant_dump
#define __vapi_code_defined_vapi_msg_sfdp_tenant_dump
static inline void vapi_msg_sfdp_tenant_dump_hton(vapi_msg_sfdp_tenant_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_sfdp_tenant_dump_ntoh(vapi_msg_sfdp_tenant_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tenant_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_sfdp_tenant_dump_msg_size(vapi_msg_sfdp_tenant_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_tenant_dump_msg_size(vapi_msg_sfdp_tenant_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tenant_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tenant_dump));
      return -1;
    }
  if (vapi_calc_sfdp_tenant_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tenant_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tenant_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_tenant_dump* vapi_alloc_sfdp_tenant_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_tenant_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_tenant_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_tenant_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_tenant_dump);

  return msg;
}

static inline vapi_error_e vapi_sfdp_tenant_dump(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_tenant_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_tenant_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_tenant_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_tenant_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_tenant_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_tenant_dump()
{
  static const char name[] = "sfdp_tenant_dump";
  static const char name_with_crc[] = "sfdp_tenant_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_sfdp_tenant_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_sfdp_tenant_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_dump_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tenant_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tenant_dump = vapi_register_msg(&__vapi_metadata_sfdp_tenant_dump);
  VAPI_DBG("Assigned msg id %d to sfdp_tenant_dump", vapi_msg_id_sfdp_tenant_dump);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_timeout_reply
#define __vapi_def_defined_vapi_msg_sfdp_set_timeout_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_set_timeout_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_set_timeout_reply payload;
} vapi_msg_sfdp_set_timeout_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_timeout_reply
#define __vapi_code_defined_vapi_msg_sfdp_set_timeout_reply
static inline void vapi_msg_sfdp_set_timeout_reply_payload_hton(vapi_payload_sfdp_set_timeout_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_set_timeout_reply_payload_ntoh(vapi_payload_sfdp_set_timeout_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_set_timeout_reply_hton(vapi_msg_sfdp_set_timeout_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_timeout_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_set_timeout_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_timeout_reply_ntoh(vapi_msg_sfdp_set_timeout_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_timeout_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_timeout_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_timeout_reply_msg_size(vapi_msg_sfdp_set_timeout_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_timeout_reply_msg_size(vapi_msg_sfdp_set_timeout_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_timeout_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_timeout_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_timeout_reply));
      return -1;
    }
  if (vapi_calc_sfdp_set_timeout_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_timeout_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_timeout_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_set_timeout_reply()
{
  static const char name[] = "sfdp_set_timeout_reply";
  static const char name_with_crc[] = "sfdp_set_timeout_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_timeout_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_set_timeout_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_timeout_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_timeout_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_timeout_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_timeout_reply = vapi_register_msg(&__vapi_metadata_sfdp_set_timeout_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_set_timeout_reply", vapi_msg_id_sfdp_set_timeout_reply);
}

static inline void vapi_set_vapi_msg_sfdp_set_timeout_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_set_timeout_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_set_timeout_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_timeout
#define __vapi_def_defined_vapi_msg_sfdp_set_timeout
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  u32 timeout_id;
  u32 timeout_value; 
} vapi_payload_sfdp_set_timeout;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_set_timeout payload;
} vapi_msg_sfdp_set_timeout;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_timeout
#define __vapi_code_defined_vapi_msg_sfdp_set_timeout
static inline void vapi_msg_sfdp_set_timeout_payload_hton(vapi_payload_sfdp_set_timeout *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->timeout_id = htobe32(payload->timeout_id);
  payload->timeout_value = htobe32(payload->timeout_value);
}

static inline void vapi_msg_sfdp_set_timeout_payload_ntoh(vapi_payload_sfdp_set_timeout *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->timeout_id = be32toh(payload->timeout_id);
  payload->timeout_value = be32toh(payload->timeout_value);
}

static inline void vapi_msg_sfdp_set_timeout_hton(vapi_msg_sfdp_set_timeout *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_timeout'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_set_timeout_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_timeout_ntoh(vapi_msg_sfdp_set_timeout *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_timeout'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_timeout_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_timeout_msg_size(vapi_msg_sfdp_set_timeout *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_timeout_msg_size(vapi_msg_sfdp_set_timeout *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_timeout) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_timeout' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_timeout));
      return -1;
    }
  if (vapi_calc_sfdp_set_timeout_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_timeout' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_timeout_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_set_timeout* vapi_alloc_sfdp_set_timeout(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_set_timeout *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_set_timeout);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_set_timeout*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_set_timeout);

  return msg;
}

static inline vapi_error_e vapi_sfdp_set_timeout(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_set_timeout *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_set_timeout_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_set_timeout_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_set_timeout_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_set_timeout_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_set_timeout()
{
  static const char name[] = "sfdp_set_timeout";
  static const char name_with_crc[] = "sfdp_set_timeout_36440b87";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_timeout = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_set_timeout, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_timeout_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_timeout_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_timeout_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_timeout = vapi_register_msg(&__vapi_metadata_sfdp_set_timeout);
  VAPI_DBG("Assigned msg id %d to sfdp_set_timeout", vapi_msg_id_sfdp_set_timeout);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_sp_node_reply
#define __vapi_def_defined_vapi_msg_sfdp_set_sp_node_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_set_sp_node_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_set_sp_node_reply payload;
} vapi_msg_sfdp_set_sp_node_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_sp_node_reply
#define __vapi_code_defined_vapi_msg_sfdp_set_sp_node_reply
static inline void vapi_msg_sfdp_set_sp_node_reply_payload_hton(vapi_payload_sfdp_set_sp_node_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_set_sp_node_reply_payload_ntoh(vapi_payload_sfdp_set_sp_node_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_set_sp_node_reply_hton(vapi_msg_sfdp_set_sp_node_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_sp_node_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_set_sp_node_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_sp_node_reply_ntoh(vapi_msg_sfdp_set_sp_node_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_sp_node_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_sp_node_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_sp_node_reply_msg_size(vapi_msg_sfdp_set_sp_node_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_sp_node_reply_msg_size(vapi_msg_sfdp_set_sp_node_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_sp_node_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_sp_node_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_sp_node_reply));
      return -1;
    }
  if (vapi_calc_sfdp_set_sp_node_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_sp_node_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_sp_node_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_set_sp_node_reply()
{
  static const char name[] = "sfdp_set_sp_node_reply";
  static const char name_with_crc[] = "sfdp_set_sp_node_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_sp_node_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_set_sp_node_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_sp_node_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_sp_node_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_sp_node_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_sp_node_reply = vapi_register_msg(&__vapi_metadata_sfdp_set_sp_node_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_set_sp_node_reply", vapi_msg_id_sfdp_set_sp_node_reply);
}

static inline void vapi_set_vapi_msg_sfdp_set_sp_node_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_set_sp_node_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_set_sp_node_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_sp_node
#define __vapi_def_defined_vapi_msg_sfdp_set_sp_node
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  vapi_enum_sfdp_sp_node sp_node;
  u32 node_index; 
} vapi_payload_sfdp_set_sp_node;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_set_sp_node payload;
} vapi_msg_sfdp_set_sp_node;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_sp_node
#define __vapi_code_defined_vapi_msg_sfdp_set_sp_node
static inline void vapi_msg_sfdp_set_sp_node_payload_hton(vapi_payload_sfdp_set_sp_node *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->node_index = htobe32(payload->node_index);
}

static inline void vapi_msg_sfdp_set_sp_node_payload_ntoh(vapi_payload_sfdp_set_sp_node *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->node_index = be32toh(payload->node_index);
}

static inline void vapi_msg_sfdp_set_sp_node_hton(vapi_msg_sfdp_set_sp_node *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_sp_node'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_set_sp_node_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_sp_node_ntoh(vapi_msg_sfdp_set_sp_node *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_sp_node'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_sp_node_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_sp_node_msg_size(vapi_msg_sfdp_set_sp_node *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_sp_node_msg_size(vapi_msg_sfdp_set_sp_node *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_sp_node) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_sp_node' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_sp_node));
      return -1;
    }
  if (vapi_calc_sfdp_set_sp_node_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_sp_node' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_sp_node_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_set_sp_node* vapi_alloc_sfdp_set_sp_node(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_set_sp_node *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_set_sp_node);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_set_sp_node*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_set_sp_node);

  return msg;
}

static inline vapi_error_e vapi_sfdp_set_sp_node(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_set_sp_node *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_set_sp_node_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_set_sp_node_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_set_sp_node_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_set_sp_node_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_set_sp_node()
{
  static const char name[] = "sfdp_set_sp_node";
  static const char name_with_crc[] = "sfdp_set_sp_node_e721277f";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_sp_node = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_set_sp_node, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_sp_node_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_sp_node_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_sp_node_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_sp_node = vapi_register_msg(&__vapi_metadata_sfdp_set_sp_node);
  VAPI_DBG("Assigned msg id %d to sfdp_set_sp_node", vapi_msg_id_sfdp_set_sp_node);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_icmp_error_node_reply
#define __vapi_def_defined_vapi_msg_sfdp_set_icmp_error_node_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_set_icmp_error_node_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_set_icmp_error_node_reply payload;
} vapi_msg_sfdp_set_icmp_error_node_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_icmp_error_node_reply
#define __vapi_code_defined_vapi_msg_sfdp_set_icmp_error_node_reply
static inline void vapi_msg_sfdp_set_icmp_error_node_reply_payload_hton(vapi_payload_sfdp_set_icmp_error_node_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_reply_payload_ntoh(vapi_payload_sfdp_set_icmp_error_node_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_reply_hton(vapi_msg_sfdp_set_icmp_error_node_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_icmp_error_node_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_set_icmp_error_node_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_reply_ntoh(vapi_msg_sfdp_set_icmp_error_node_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_icmp_error_node_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_icmp_error_node_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_icmp_error_node_reply_msg_size(vapi_msg_sfdp_set_icmp_error_node_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_icmp_error_node_reply_msg_size(vapi_msg_sfdp_set_icmp_error_node_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_icmp_error_node_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_icmp_error_node_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_icmp_error_node_reply));
      return -1;
    }
  if (vapi_calc_sfdp_set_icmp_error_node_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_icmp_error_node_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_icmp_error_node_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_set_icmp_error_node_reply()
{
  static const char name[] = "sfdp_set_icmp_error_node_reply";
  static const char name_with_crc[] = "sfdp_set_icmp_error_node_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_icmp_error_node_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_set_icmp_error_node_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_icmp_error_node_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_icmp_error_node_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_icmp_error_node_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_icmp_error_node_reply = vapi_register_msg(&__vapi_metadata_sfdp_set_icmp_error_node_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_set_icmp_error_node_reply", vapi_msg_id_sfdp_set_icmp_error_node_reply);
}

static inline void vapi_set_vapi_msg_sfdp_set_icmp_error_node_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_set_icmp_error_node_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_set_icmp_error_node_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_set_icmp_error_node
#define __vapi_def_defined_vapi_msg_sfdp_set_icmp_error_node
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  bool is_ip6;
  u32 node_index; 
} vapi_payload_sfdp_set_icmp_error_node;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_set_icmp_error_node payload;
} vapi_msg_sfdp_set_icmp_error_node;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_set_icmp_error_node
#define __vapi_code_defined_vapi_msg_sfdp_set_icmp_error_node
static inline void vapi_msg_sfdp_set_icmp_error_node_payload_hton(vapi_payload_sfdp_set_icmp_error_node *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->node_index = htobe32(payload->node_index);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_payload_ntoh(vapi_payload_sfdp_set_icmp_error_node *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->node_index = be32toh(payload->node_index);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_hton(vapi_msg_sfdp_set_icmp_error_node *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_icmp_error_node'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_set_icmp_error_node_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_set_icmp_error_node_ntoh(vapi_msg_sfdp_set_icmp_error_node *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_set_icmp_error_node'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_set_icmp_error_node_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_set_icmp_error_node_msg_size(vapi_msg_sfdp_set_icmp_error_node *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_set_icmp_error_node_msg_size(vapi_msg_sfdp_set_icmp_error_node *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_set_icmp_error_node) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_icmp_error_node' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_set_icmp_error_node));
      return -1;
    }
  if (vapi_calc_sfdp_set_icmp_error_node_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_set_icmp_error_node' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_set_icmp_error_node_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_set_icmp_error_node* vapi_alloc_sfdp_set_icmp_error_node(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_set_icmp_error_node *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_set_icmp_error_node);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_set_icmp_error_node*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_set_icmp_error_node);

  return msg;
}

static inline vapi_error_e vapi_sfdp_set_icmp_error_node(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_set_icmp_error_node *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_set_icmp_error_node_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_set_icmp_error_node_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_set_icmp_error_node_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_set_icmp_error_node_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_set_icmp_error_node()
{
  static const char name[] = "sfdp_set_icmp_error_node";
  static const char name_with_crc[] = "sfdp_set_icmp_error_node_90d10424";
  static vapi_message_desc_t __vapi_metadata_sfdp_set_icmp_error_node = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_set_icmp_error_node, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_set_icmp_error_node_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_set_icmp_error_node_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_set_icmp_error_node_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_set_icmp_error_node = vapi_register_msg(&__vapi_metadata_sfdp_set_icmp_error_node);
  VAPI_DBG("Assigned msg id %d to sfdp_set_icmp_error_node", vapi_msg_id_sfdp_set_icmp_error_node);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_service_details
#define __vapi_def_defined_vapi_msg_sfdp_service_details
typedef struct __attribute__ ((__packed__)) {
  u8 node_name[32];
  u8 scope[32];
  bool is_terminal;
  u8 index; 
} vapi_payload_sfdp_service_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_service_details payload;
} vapi_msg_sfdp_service_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_service_details
#define __vapi_code_defined_vapi_msg_sfdp_service_details
static inline void vapi_msg_sfdp_service_details_payload_hton(vapi_payload_sfdp_service_details *payload)
{

}

static inline void vapi_msg_sfdp_service_details_payload_ntoh(vapi_payload_sfdp_service_details *payload)
{

}

static inline void vapi_msg_sfdp_service_details_hton(vapi_msg_sfdp_service_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_service_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_service_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_service_details_ntoh(vapi_msg_sfdp_service_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_service_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_service_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_service_details_msg_size(vapi_msg_sfdp_service_details *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_service_details_msg_size(vapi_msg_sfdp_service_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_service_details) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_service_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_service_details));
      return -1;
    }
  if (vapi_calc_sfdp_service_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_service_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_service_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_service_details()
{
  static const char name[] = "sfdp_service_details";
  static const char name_with_crc[] = "sfdp_service_details_2a8d1427";
  static vapi_message_desc_t __vapi_metadata_sfdp_service_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_service_details, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_service_details_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_service_details_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_service_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_service_details = vapi_register_msg(&__vapi_metadata_sfdp_service_details);
  VAPI_DBG("Assigned msg id %d to sfdp_service_details", vapi_msg_id_sfdp_service_details);
}

static inline void vapi_set_vapi_msg_sfdp_service_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_service_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_service_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_service_dump
#define __vapi_def_defined_vapi_msg_sfdp_service_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_sfdp_service_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_service_dump
#define __vapi_code_defined_vapi_msg_sfdp_service_dump
static inline void vapi_msg_sfdp_service_dump_hton(vapi_msg_sfdp_service_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_service_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_sfdp_service_dump_ntoh(vapi_msg_sfdp_service_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_service_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_sfdp_service_dump_msg_size(vapi_msg_sfdp_service_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_service_dump_msg_size(vapi_msg_sfdp_service_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_service_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_service_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_service_dump));
      return -1;
    }
  if (vapi_calc_sfdp_service_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_service_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_service_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_service_dump* vapi_alloc_sfdp_service_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_service_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_service_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_service_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_service_dump);

  return msg;
}

static inline vapi_error_e vapi_sfdp_service_dump(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_service_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_service_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_service_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_service_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_service_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_service_dump()
{
  static const char name[] = "sfdp_service_dump";
  static const char name_with_crc[] = "sfdp_service_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_sfdp_service_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_sfdp_service_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_service_dump_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_service_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_service_dump = vapi_register_msg(&__vapi_metadata_sfdp_service_dump);
  VAPI_DBG("Assigned msg id %d to sfdp_service_dump", vapi_msg_id_sfdp_service_dump);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

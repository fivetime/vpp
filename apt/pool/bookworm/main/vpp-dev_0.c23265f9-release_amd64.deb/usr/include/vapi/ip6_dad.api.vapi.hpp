#ifndef __included_hpp_ip6_dad_api_json
#define __included_hpp_ip6_dad_api_json

#include <vapi/vapi.hpp>
#include <vapi/ip6_dad.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_ip6_dad_enable_disable>(vapi_msg_ip6_dad_enable_disable *msg)
{
  vapi_msg_ip6_dad_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_dad_enable_disable>(vapi_msg_ip6_dad_enable_disable *msg)
{
  vapi_msg_ip6_dad_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_dad_enable_disable>()
{
  return ::vapi_msg_id_ip6_dad_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_dad_enable_disable>>()
{
  return ::vapi_msg_id_ip6_dad_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_dad_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_dad_enable_disable>(vapi_msg_id_ip6_dad_enable_disable);
}

template <> inline vapi_msg_ip6_dad_enable_disable* vapi_alloc<vapi_msg_ip6_dad_enable_disable>(Connection &con)
{
  vapi_msg_ip6_dad_enable_disable* result = vapi_alloc_ip6_dad_enable_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6_dad_enable_disable>;

template class Request<vapi_msg_ip6_dad_enable_disable, vapi_msg_ip6_dad_enable_disable_reply>;

using Ip6_dad_enable_disable = Request<vapi_msg_ip6_dad_enable_disable, vapi_msg_ip6_dad_enable_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip6_dad_enable_disable_reply>(vapi_msg_ip6_dad_enable_disable_reply *msg)
{
  vapi_msg_ip6_dad_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_dad_enable_disable_reply>(vapi_msg_ip6_dad_enable_disable_reply *msg)
{
  vapi_msg_ip6_dad_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_dad_enable_disable_reply>()
{
  return ::vapi_msg_id_ip6_dad_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_dad_enable_disable_reply>>()
{
  return ::vapi_msg_id_ip6_dad_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_dad_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_dad_enable_disable_reply>(vapi_msg_id_ip6_dad_enable_disable_reply);
}

template class Msg<vapi_msg_ip6_dad_enable_disable_reply>;

using Ip6_dad_enable_disable_reply = Msg<vapi_msg_ip6_dad_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6_dad_dump>(vapi_msg_ip6_dad_dump *msg)
{
  vapi_msg_ip6_dad_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_dad_dump>(vapi_msg_ip6_dad_dump *msg)
{
  vapi_msg_ip6_dad_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_dad_dump>()
{
  return ::vapi_msg_id_ip6_dad_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_dad_dump>>()
{
  return ::vapi_msg_id_ip6_dad_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_dad_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_dad_dump>(vapi_msg_id_ip6_dad_dump);
}

template <> inline vapi_msg_ip6_dad_dump* vapi_alloc<vapi_msg_ip6_dad_dump>(Connection &con)
{
  vapi_msg_ip6_dad_dump* result = vapi_alloc_ip6_dad_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6_dad_dump>;

template class Dump<vapi_msg_ip6_dad_dump, vapi_msg_ip6_dad_details>;

using Ip6_dad_dump = Dump<vapi_msg_ip6_dad_dump, vapi_msg_ip6_dad_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip6_dad_details>(vapi_msg_ip6_dad_details *msg)
{
  vapi_msg_ip6_dad_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_dad_details>(vapi_msg_ip6_dad_details *msg)
{
  vapi_msg_ip6_dad_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_dad_details>()
{
  return ::vapi_msg_id_ip6_dad_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_dad_details>>()
{
  return ::vapi_msg_id_ip6_dad_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_dad_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_dad_details>(vapi_msg_id_ip6_dad_details);
}

template class Msg<vapi_msg_ip6_dad_details>;

using Ip6_dad_details = Msg<vapi_msg_ip6_dad_details>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_dad_events>(vapi_msg_want_ip6_dad_events *msg)
{
  vapi_msg_want_ip6_dad_events_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_dad_events>(vapi_msg_want_ip6_dad_events *msg)
{
  vapi_msg_want_ip6_dad_events_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_dad_events>()
{
  return ::vapi_msg_id_want_ip6_dad_events; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_dad_events>>()
{
  return ::vapi_msg_id_want_ip6_dad_events; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_dad_events()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_dad_events>(vapi_msg_id_want_ip6_dad_events);
}

template <> inline vapi_msg_want_ip6_dad_events* vapi_alloc<vapi_msg_want_ip6_dad_events>(Connection &con)
{
  vapi_msg_want_ip6_dad_events* result = vapi_alloc_want_ip6_dad_events(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip6_dad_events>;

template class Request<vapi_msg_want_ip6_dad_events, vapi_msg_want_ip6_dad_events_reply>;

using Want_ip6_dad_events = Request<vapi_msg_want_ip6_dad_events, vapi_msg_want_ip6_dad_events_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_dad_events_reply>(vapi_msg_want_ip6_dad_events_reply *msg)
{
  vapi_msg_want_ip6_dad_events_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_dad_events_reply>(vapi_msg_want_ip6_dad_events_reply *msg)
{
  vapi_msg_want_ip6_dad_events_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_dad_events_reply>()
{
  return ::vapi_msg_id_want_ip6_dad_events_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_dad_events_reply>>()
{
  return ::vapi_msg_id_want_ip6_dad_events_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_dad_events_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_dad_events_reply>(vapi_msg_id_want_ip6_dad_events_reply);
}

template class Msg<vapi_msg_want_ip6_dad_events_reply>;

using Want_ip6_dad_events_reply = Msg<vapi_msg_want_ip6_dad_events_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6_dad_event>(vapi_msg_ip6_dad_event *msg)
{
  vapi_msg_ip6_dad_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_dad_event>(vapi_msg_ip6_dad_event *msg)
{
  vapi_msg_ip6_dad_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_dad_event>()
{
  return ::vapi_msg_id_ip6_dad_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_dad_event>>()
{
  return ::vapi_msg_id_ip6_dad_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_dad_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_dad_event>(vapi_msg_id_ip6_dad_event);
}

template class Msg<vapi_msg_ip6_dad_event>;

using Ip6_dad_event = Msg<vapi_msg_ip6_dad_event>;
}
#endif

#ifndef __included_probe_api_json
#define __included_probe_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_probe_fib_add_del;
extern vapi_msg_id_t vapi_msg_id_probe_fib_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_probe_fib_dump;
extern vapi_msg_id_t vapi_msg_id_probe_fib_details;
extern vapi_msg_id_t vapi_msg_id_probe_classify_lookup;
extern vapi_msg_id_t vapi_msg_id_probe_classify_lookup_reply;

#define DEFINE_VAPI_MSG_IDS_PROBE_API_JSON\
  vapi_msg_id_t vapi_msg_id_probe_fib_add_del;\
  vapi_msg_id_t vapi_msg_id_probe_fib_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_probe_fib_dump;\
  vapi_msg_id_t vapi_msg_id_probe_fib_details;\
  vapi_msg_id_t vapi_msg_id_probe_classify_lookup;\
  vapi_msg_id_t vapi_msg_id_probe_classify_lookup_reply;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_fib_add_del_reply
#define __vapi_def_defined_vapi_msg_probe_fib_add_del_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_probe_fib_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_probe_fib_add_del_reply payload;
} vapi_msg_probe_fib_add_del_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_fib_add_del_reply
#define __vapi_code_defined_vapi_msg_probe_fib_add_del_reply
static inline void vapi_msg_probe_fib_add_del_reply_payload_hton(vapi_payload_probe_fib_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_probe_fib_add_del_reply_payload_ntoh(vapi_payload_probe_fib_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_probe_fib_add_del_reply_hton(vapi_msg_probe_fib_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_probe_fib_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_probe_fib_add_del_reply_ntoh(vapi_msg_probe_fib_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_probe_fib_add_del_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_probe_fib_add_del_reply_msg_size(vapi_msg_probe_fib_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_probe_fib_add_del_reply_msg_size(vapi_msg_probe_fib_add_del_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_fib_add_del_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_add_del_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_fib_add_del_reply));
      return -1;
    }
  if (vapi_calc_probe_fib_add_del_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_add_del_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_fib_add_del_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_probe_fib_add_del_reply()
{
  static const char name[] = "probe_fib_add_del_reply";
  static const char name_with_crc[] = "probe_fib_add_del_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_probe_fib_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_probe_fib_add_del_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_probe_fib_add_del_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_fib_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_probe_fib_add_del_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_fib_add_del_reply = vapi_register_msg(&__vapi_metadata_probe_fib_add_del_reply);
  VAPI_DBG("Assigned msg id %d to probe_fib_add_del_reply", vapi_msg_id_probe_fib_add_del_reply);
}

static inline void vapi_set_vapi_msg_probe_fib_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_probe_fib_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_probe_fib_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_fib_add_del
#define __vapi_def_defined_vapi_msg_probe_fib_add_del
typedef struct __attribute__ ((__packed__)) {
  bool is_add;
  u32 table_id;
  vapi_type_prefix prefix;
  u8 name[64]; 
} vapi_payload_probe_fib_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_probe_fib_add_del payload;
} vapi_msg_probe_fib_add_del;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_fib_add_del
#define __vapi_code_defined_vapi_msg_probe_fib_add_del
static inline void vapi_msg_probe_fib_add_del_payload_hton(vapi_payload_probe_fib_add_del *payload)
{
  payload->table_id = htobe32(payload->table_id);
}

static inline void vapi_msg_probe_fib_add_del_payload_ntoh(vapi_payload_probe_fib_add_del *payload)
{
  payload->table_id = be32toh(payload->table_id);
}

static inline void vapi_msg_probe_fib_add_del_hton(vapi_msg_probe_fib_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_probe_fib_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_probe_fib_add_del_ntoh(vapi_msg_probe_fib_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_probe_fib_add_del_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_probe_fib_add_del_msg_size(vapi_msg_probe_fib_add_del *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_probe_fib_add_del_msg_size(vapi_msg_probe_fib_add_del *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_fib_add_del) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_add_del' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_fib_add_del));
      return -1;
    }
  if (vapi_calc_probe_fib_add_del_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_add_del' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_fib_add_del_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_probe_fib_add_del* vapi_alloc_probe_fib_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_probe_fib_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_probe_fib_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_probe_fib_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_probe_fib_add_del);

  return msg;
}

static inline vapi_error_e vapi_probe_fib_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_probe_fib_add_del *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_probe_fib_add_del_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_probe_fib_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_probe_fib_add_del_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_probe_fib_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_probe_fib_add_del()
{
  static const char name[] = "probe_fib_add_del";
  static const char name_with_crc[] = "probe_fib_add_del_6c72341e";
  static vapi_message_desc_t __vapi_metadata_probe_fib_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_probe_fib_add_del, payload),
    (verify_msg_size_fn_t)vapi_verify_probe_fib_add_del_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_fib_add_del_hton,
    (generic_swap_fn_t)vapi_msg_probe_fib_add_del_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_fib_add_del = vapi_register_msg(&__vapi_metadata_probe_fib_add_del);
  VAPI_DBG("Assigned msg id %d to probe_fib_add_del", vapi_msg_id_probe_fib_add_del);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_fib_details
#define __vapi_def_defined_vapi_msg_probe_fib_details
typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  vapi_type_prefix prefix;
  u8 name[64];
  u8 reachable;
  u8 dpo_type; 
} vapi_payload_probe_fib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_probe_fib_details payload;
} vapi_msg_probe_fib_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_fib_details
#define __vapi_code_defined_vapi_msg_probe_fib_details
static inline void vapi_msg_probe_fib_details_payload_hton(vapi_payload_probe_fib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
}

static inline void vapi_msg_probe_fib_details_payload_ntoh(vapi_payload_probe_fib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
}

static inline void vapi_msg_probe_fib_details_hton(vapi_msg_probe_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_probe_fib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_probe_fib_details_ntoh(vapi_msg_probe_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_probe_fib_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_probe_fib_details_msg_size(vapi_msg_probe_fib_details *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_probe_fib_details_msg_size(vapi_msg_probe_fib_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_fib_details) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_fib_details));
      return -1;
    }
  if (vapi_calc_probe_fib_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_fib_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_probe_fib_details()
{
  static const char name[] = "probe_fib_details";
  static const char name_with_crc[] = "probe_fib_details_7a55763a";
  static vapi_message_desc_t __vapi_metadata_probe_fib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_probe_fib_details, payload),
    (verify_msg_size_fn_t)vapi_verify_probe_fib_details_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_fib_details_hton,
    (generic_swap_fn_t)vapi_msg_probe_fib_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_fib_details = vapi_register_msg(&__vapi_metadata_probe_fib_details);
  VAPI_DBG("Assigned msg id %d to probe_fib_details", vapi_msg_id_probe_fib_details);
}

static inline void vapi_set_vapi_msg_probe_fib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_probe_fib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_probe_fib_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_fib_dump
#define __vapi_def_defined_vapi_msg_probe_fib_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_probe_fib_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_fib_dump
#define __vapi_code_defined_vapi_msg_probe_fib_dump
static inline void vapi_msg_probe_fib_dump_hton(vapi_msg_probe_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_probe_fib_dump_ntoh(vapi_msg_probe_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_fib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_probe_fib_dump_msg_size(vapi_msg_probe_fib_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_probe_fib_dump_msg_size(vapi_msg_probe_fib_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_fib_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_fib_dump));
      return -1;
    }
  if (vapi_calc_probe_fib_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_fib_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_fib_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_probe_fib_dump* vapi_alloc_probe_fib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_probe_fib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_probe_fib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_probe_fib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_probe_fib_dump);

  return msg;
}

static inline vapi_error_e vapi_probe_fib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_probe_fib_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_probe_fib_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_probe_fib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_probe_fib_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_probe_fib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_probe_fib_dump()
{
  static const char name[] = "probe_fib_dump";
  static const char name_with_crc[] = "probe_fib_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_probe_fib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_probe_fib_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_fib_dump_hton,
    (generic_swap_fn_t)vapi_msg_probe_fib_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_fib_dump = vapi_register_msg(&__vapi_metadata_probe_fib_dump);
  VAPI_DBG("Assigned msg id %d to probe_fib_dump", vapi_msg_id_probe_fib_dump);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_classify_lookup_reply
#define __vapi_def_defined_vapi_msg_probe_classify_lookup_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 count;
  u32 hits[0]; 
} vapi_payload_probe_classify_lookup_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_probe_classify_lookup_reply payload;
} vapi_msg_probe_classify_lookup_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_classify_lookup_reply
#define __vapi_code_defined_vapi_msg_probe_classify_lookup_reply
static inline void vapi_msg_probe_classify_lookup_reply_payload_hton(vapi_payload_probe_classify_lookup_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { payload->hits[i] = htobe32(payload->hits[i]); } } while(0);
}

static inline void vapi_msg_probe_classify_lookup_reply_payload_ntoh(vapi_payload_probe_classify_lookup_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->hits[i] = be32toh(payload->hits[i]); } } while(0);
}

static inline void vapi_msg_probe_classify_lookup_reply_hton(vapi_msg_probe_classify_lookup_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_classify_lookup_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_probe_classify_lookup_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_probe_classify_lookup_reply_ntoh(vapi_msg_probe_classify_lookup_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_classify_lookup_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_probe_classify_lookup_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_probe_classify_lookup_reply_msg_size(vapi_msg_probe_classify_lookup_reply *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.hits[0]) * msg->payload.count;
}

static inline int vapi_verify_probe_classify_lookup_reply_msg_size(vapi_msg_probe_classify_lookup_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_classify_lookup_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_classify_lookup_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_classify_lookup_reply));
      return -1;
    }
  if (vapi_calc_probe_classify_lookup_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_classify_lookup_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_classify_lookup_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_probe_classify_lookup_reply()
{
  static const char name[] = "probe_classify_lookup_reply";
  static const char name_with_crc[] = "probe_classify_lookup_reply_c98ec7b7";
  static vapi_message_desc_t __vapi_metadata_probe_classify_lookup_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_probe_classify_lookup_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_probe_classify_lookup_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_classify_lookup_reply_hton,
    (generic_swap_fn_t)vapi_msg_probe_classify_lookup_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_classify_lookup_reply = vapi_register_msg(&__vapi_metadata_probe_classify_lookup_reply);
  VAPI_DBG("Assigned msg id %d to probe_classify_lookup_reply", vapi_msg_id_probe_classify_lookup_reply);
}

static inline void vapi_set_vapi_msg_probe_classify_lookup_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_probe_classify_lookup_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_probe_classify_lookup_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_probe_classify_lookup
#define __vapi_def_defined_vapi_msg_probe_classify_lookup
typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u32 key_len;
  u32 match_len;
  u8 match[0]; 
} vapi_payload_probe_classify_lookup;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_probe_classify_lookup payload;
} vapi_msg_probe_classify_lookup;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_probe_classify_lookup
#define __vapi_code_defined_vapi_msg_probe_classify_lookup
static inline void vapi_msg_probe_classify_lookup_payload_hton(vapi_payload_probe_classify_lookup *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->key_len = htobe32(payload->key_len);
  payload->match_len = htobe32(payload->match_len);
}

static inline void vapi_msg_probe_classify_lookup_payload_ntoh(vapi_payload_probe_classify_lookup *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->key_len = be32toh(payload->key_len);
  payload->match_len = be32toh(payload->match_len);
}

static inline void vapi_msg_probe_classify_lookup_hton(vapi_msg_probe_classify_lookup *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_classify_lookup'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_probe_classify_lookup_payload_hton(&msg->payload);
}

static inline void vapi_msg_probe_classify_lookup_ntoh(vapi_msg_probe_classify_lookup *msg)
{
  VAPI_DBG("Swapping `vapi_msg_probe_classify_lookup'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_probe_classify_lookup_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_probe_classify_lookup_msg_size(vapi_msg_probe_classify_lookup *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.match[0]) * msg->payload.match_len;
}

static inline int vapi_verify_probe_classify_lookup_msg_size(vapi_msg_probe_classify_lookup *msg, uword buf_size)
{
  if (sizeof(vapi_msg_probe_classify_lookup) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_classify_lookup' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_probe_classify_lookup));
      return -1;
    }
  if (vapi_calc_probe_classify_lookup_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'probe_classify_lookup' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_probe_classify_lookup_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_probe_classify_lookup* vapi_alloc_probe_classify_lookup(struct vapi_ctx_s *ctx, size_t _match_array_size)
{
  vapi_msg_probe_classify_lookup *msg = NULL;
  const size_t size = sizeof(vapi_msg_probe_classify_lookup) + sizeof(msg->payload.match[0]) * _match_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_probe_classify_lookup*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_probe_classify_lookup);
  msg->payload.match_len = _match_array_size;

  return msg;
}

static inline vapi_error_e vapi_probe_classify_lookup(struct vapi_ctx_s *ctx,
  vapi_msg_probe_classify_lookup *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_probe_classify_lookup_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_probe_classify_lookup_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_probe_classify_lookup_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_probe_classify_lookup_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_probe_classify_lookup()
{
  static const char name[] = "probe_classify_lookup";
  static const char name_with_crc[] = "probe_classify_lookup_63ac8370";
  static vapi_message_desc_t __vapi_metadata_probe_classify_lookup = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_probe_classify_lookup, payload),
    (verify_msg_size_fn_t)vapi_verify_probe_classify_lookup_msg_size,
    (generic_swap_fn_t)vapi_msg_probe_classify_lookup_hton,
    (generic_swap_fn_t)vapi_msg_probe_classify_lookup_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_probe_classify_lookup = vapi_register_msg(&__vapi_metadata_probe_classify_lookup);
  VAPI_DBG("Assigned msg id %d to probe_classify_lookup", vapi_msg_id_probe_classify_lookup);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

#ifndef __included_hpp_tm_api_json
#define __included_hpp_tm_api_json

#include <vapi/vapi.hpp>
#include <vapi/tm.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_add>(vapi_msg_tm_sys_node_add *msg)
{
  vapi_msg_tm_sys_node_add_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_add>(vapi_msg_tm_sys_node_add *msg)
{
  vapi_msg_tm_sys_node_add_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_add>()
{
  return ::vapi_msg_id_tm_sys_node_add; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_add>>()
{
  return ::vapi_msg_id_tm_sys_node_add; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_add()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_add>(vapi_msg_id_tm_sys_node_add);
}

template <> inline vapi_msg_tm_sys_node_add* vapi_alloc<vapi_msg_tm_sys_node_add>(Connection &con)
{
  vapi_msg_tm_sys_node_add* result = vapi_alloc_tm_sys_node_add(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_add>;

template class Request<vapi_msg_tm_sys_node_add, vapi_msg_tm_sys_node_add_reply>;

using Tm_sys_node_add = Request<vapi_msg_tm_sys_node_add, vapi_msg_tm_sys_node_add_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_add_reply>(vapi_msg_tm_sys_node_add_reply *msg)
{
  vapi_msg_tm_sys_node_add_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_add_reply>(vapi_msg_tm_sys_node_add_reply *msg)
{
  vapi_msg_tm_sys_node_add_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_add_reply>()
{
  return ::vapi_msg_id_tm_sys_node_add_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_add_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_add_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_add_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_add_reply>(vapi_msg_id_tm_sys_node_add_reply);
}

template class Msg<vapi_msg_tm_sys_node_add_reply>;

using Tm_sys_node_add_reply = Msg<vapi_msg_tm_sys_node_add_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_suspend>(vapi_msg_tm_sys_node_suspend *msg)
{
  vapi_msg_tm_sys_node_suspend_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_suspend>(vapi_msg_tm_sys_node_suspend *msg)
{
  vapi_msg_tm_sys_node_suspend_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_suspend>()
{
  return ::vapi_msg_id_tm_sys_node_suspend; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_suspend>>()
{
  return ::vapi_msg_id_tm_sys_node_suspend; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_suspend()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_suspend>(vapi_msg_id_tm_sys_node_suspend);
}

template <> inline vapi_msg_tm_sys_node_suspend* vapi_alloc<vapi_msg_tm_sys_node_suspend>(Connection &con)
{
  vapi_msg_tm_sys_node_suspend* result = vapi_alloc_tm_sys_node_suspend(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_suspend>;

template class Request<vapi_msg_tm_sys_node_suspend, vapi_msg_tm_sys_node_suspend_reply>;

using Tm_sys_node_suspend = Request<vapi_msg_tm_sys_node_suspend, vapi_msg_tm_sys_node_suspend_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_suspend_reply>(vapi_msg_tm_sys_node_suspend_reply *msg)
{
  vapi_msg_tm_sys_node_suspend_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_suspend_reply>(vapi_msg_tm_sys_node_suspend_reply *msg)
{
  vapi_msg_tm_sys_node_suspend_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_suspend_reply>()
{
  return ::vapi_msg_id_tm_sys_node_suspend_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_suspend_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_suspend_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_suspend_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_suspend_reply>(vapi_msg_id_tm_sys_node_suspend_reply);
}

template class Msg<vapi_msg_tm_sys_node_suspend_reply>;

using Tm_sys_node_suspend_reply = Msg<vapi_msg_tm_sys_node_suspend_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_resume>(vapi_msg_tm_sys_node_resume *msg)
{
  vapi_msg_tm_sys_node_resume_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_resume>(vapi_msg_tm_sys_node_resume *msg)
{
  vapi_msg_tm_sys_node_resume_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_resume>()
{
  return ::vapi_msg_id_tm_sys_node_resume; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_resume>>()
{
  return ::vapi_msg_id_tm_sys_node_resume; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_resume()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_resume>(vapi_msg_id_tm_sys_node_resume);
}

template <> inline vapi_msg_tm_sys_node_resume* vapi_alloc<vapi_msg_tm_sys_node_resume>(Connection &con)
{
  vapi_msg_tm_sys_node_resume* result = vapi_alloc_tm_sys_node_resume(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_resume>;

template class Request<vapi_msg_tm_sys_node_resume, vapi_msg_tm_sys_node_resume_reply>;

using Tm_sys_node_resume = Request<vapi_msg_tm_sys_node_resume, vapi_msg_tm_sys_node_resume_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_resume_reply>(vapi_msg_tm_sys_node_resume_reply *msg)
{
  vapi_msg_tm_sys_node_resume_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_resume_reply>(vapi_msg_tm_sys_node_resume_reply *msg)
{
  vapi_msg_tm_sys_node_resume_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_resume_reply>()
{
  return ::vapi_msg_id_tm_sys_node_resume_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_resume_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_resume_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_resume_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_resume_reply>(vapi_msg_id_tm_sys_node_resume_reply);
}

template class Msg<vapi_msg_tm_sys_node_resume_reply>;

using Tm_sys_node_resume_reply = Msg<vapi_msg_tm_sys_node_resume_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_delete>(vapi_msg_tm_sys_node_delete *msg)
{
  vapi_msg_tm_sys_node_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_delete>(vapi_msg_tm_sys_node_delete *msg)
{
  vapi_msg_tm_sys_node_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_delete>()
{
  return ::vapi_msg_id_tm_sys_node_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_delete>>()
{
  return ::vapi_msg_id_tm_sys_node_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_delete>(vapi_msg_id_tm_sys_node_delete);
}

template <> inline vapi_msg_tm_sys_node_delete* vapi_alloc<vapi_msg_tm_sys_node_delete>(Connection &con)
{
  vapi_msg_tm_sys_node_delete* result = vapi_alloc_tm_sys_node_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_delete>;

template class Request<vapi_msg_tm_sys_node_delete, vapi_msg_tm_sys_node_delete_reply>;

using Tm_sys_node_delete = Request<vapi_msg_tm_sys_node_delete, vapi_msg_tm_sys_node_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_delete_reply>(vapi_msg_tm_sys_node_delete_reply *msg)
{
  vapi_msg_tm_sys_node_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_delete_reply>(vapi_msg_tm_sys_node_delete_reply *msg)
{
  vapi_msg_tm_sys_node_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_delete_reply>()
{
  return ::vapi_msg_id_tm_sys_node_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_delete_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_delete_reply>(vapi_msg_id_tm_sys_node_delete_reply);
}

template class Msg<vapi_msg_tm_sys_node_delete_reply>;

using Tm_sys_node_delete_reply = Msg<vapi_msg_tm_sys_node_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_shaper_profile_create>(vapi_msg_tm_sys_shaper_profile_create *msg)
{
  vapi_msg_tm_sys_shaper_profile_create_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_shaper_profile_create>(vapi_msg_tm_sys_shaper_profile_create *msg)
{
  vapi_msg_tm_sys_shaper_profile_create_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_shaper_profile_create>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_create; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_shaper_profile_create>>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_create; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_shaper_profile_create()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_shaper_profile_create>(vapi_msg_id_tm_sys_shaper_profile_create);
}

template <> inline vapi_msg_tm_sys_shaper_profile_create* vapi_alloc<vapi_msg_tm_sys_shaper_profile_create>(Connection &con)
{
  vapi_msg_tm_sys_shaper_profile_create* result = vapi_alloc_tm_sys_shaper_profile_create(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_shaper_profile_create>;

template class Request<vapi_msg_tm_sys_shaper_profile_create, vapi_msg_tm_sys_shaper_profile_create_reply>;

using Tm_sys_shaper_profile_create = Request<vapi_msg_tm_sys_shaper_profile_create, vapi_msg_tm_sys_shaper_profile_create_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_shaper_profile_create_reply>(vapi_msg_tm_sys_shaper_profile_create_reply *msg)
{
  vapi_msg_tm_sys_shaper_profile_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_shaper_profile_create_reply>(vapi_msg_tm_sys_shaper_profile_create_reply *msg)
{
  vapi_msg_tm_sys_shaper_profile_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_shaper_profile_create_reply>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_shaper_profile_create_reply>>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_shaper_profile_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_shaper_profile_create_reply>(vapi_msg_id_tm_sys_shaper_profile_create_reply);
}

template class Msg<vapi_msg_tm_sys_shaper_profile_create_reply>;

using Tm_sys_shaper_profile_create_reply = Msg<vapi_msg_tm_sys_shaper_profile_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_shaper_update>(vapi_msg_tm_sys_node_shaper_update *msg)
{
  vapi_msg_tm_sys_node_shaper_update_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_shaper_update>(vapi_msg_tm_sys_node_shaper_update *msg)
{
  vapi_msg_tm_sys_node_shaper_update_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_shaper_update>()
{
  return ::vapi_msg_id_tm_sys_node_shaper_update; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_shaper_update>>()
{
  return ::vapi_msg_id_tm_sys_node_shaper_update; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_shaper_update()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_shaper_update>(vapi_msg_id_tm_sys_node_shaper_update);
}

template <> inline vapi_msg_tm_sys_node_shaper_update* vapi_alloc<vapi_msg_tm_sys_node_shaper_update>(Connection &con)
{
  vapi_msg_tm_sys_node_shaper_update* result = vapi_alloc_tm_sys_node_shaper_update(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_shaper_update>;

template class Request<vapi_msg_tm_sys_node_shaper_update, vapi_msg_tm_sys_node_shaper_update_reply>;

using Tm_sys_node_shaper_update = Request<vapi_msg_tm_sys_node_shaper_update, vapi_msg_tm_sys_node_shaper_update_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_shaper_update_reply>(vapi_msg_tm_sys_node_shaper_update_reply *msg)
{
  vapi_msg_tm_sys_node_shaper_update_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_shaper_update_reply>(vapi_msg_tm_sys_node_shaper_update_reply *msg)
{
  vapi_msg_tm_sys_node_shaper_update_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_shaper_update_reply>()
{
  return ::vapi_msg_id_tm_sys_node_shaper_update_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_shaper_update_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_shaper_update_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_shaper_update_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_shaper_update_reply>(vapi_msg_id_tm_sys_node_shaper_update_reply);
}

template class Msg<vapi_msg_tm_sys_node_shaper_update_reply>;

using Tm_sys_node_shaper_update_reply = Msg<vapi_msg_tm_sys_node_shaper_update_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_shaper_profile_delete>(vapi_msg_tm_sys_shaper_profile_delete *msg)
{
  vapi_msg_tm_sys_shaper_profile_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_shaper_profile_delete>(vapi_msg_tm_sys_shaper_profile_delete *msg)
{
  vapi_msg_tm_sys_shaper_profile_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_shaper_profile_delete>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_shaper_profile_delete>>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_shaper_profile_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_shaper_profile_delete>(vapi_msg_id_tm_sys_shaper_profile_delete);
}

template <> inline vapi_msg_tm_sys_shaper_profile_delete* vapi_alloc<vapi_msg_tm_sys_shaper_profile_delete>(Connection &con)
{
  vapi_msg_tm_sys_shaper_profile_delete* result = vapi_alloc_tm_sys_shaper_profile_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_shaper_profile_delete>;

template class Request<vapi_msg_tm_sys_shaper_profile_delete, vapi_msg_tm_sys_shaper_profile_delete_reply>;

using Tm_sys_shaper_profile_delete = Request<vapi_msg_tm_sys_shaper_profile_delete, vapi_msg_tm_sys_shaper_profile_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_shaper_profile_delete_reply>(vapi_msg_tm_sys_shaper_profile_delete_reply *msg)
{
  vapi_msg_tm_sys_shaper_profile_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_shaper_profile_delete_reply>(vapi_msg_tm_sys_shaper_profile_delete_reply *msg)
{
  vapi_msg_tm_sys_shaper_profile_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_shaper_profile_delete_reply>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_shaper_profile_delete_reply>>()
{
  return ::vapi_msg_id_tm_sys_shaper_profile_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_shaper_profile_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_shaper_profile_delete_reply>(vapi_msg_id_tm_sys_shaper_profile_delete_reply);
}

template class Msg<vapi_msg_tm_sys_shaper_profile_delete_reply>;

using Tm_sys_shaper_profile_delete_reply = Msg<vapi_msg_tm_sys_shaper_profile_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_sched_weight_update>(vapi_msg_tm_sys_node_sched_weight_update *msg)
{
  vapi_msg_tm_sys_node_sched_weight_update_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_sched_weight_update>(vapi_msg_tm_sys_node_sched_weight_update *msg)
{
  vapi_msg_tm_sys_node_sched_weight_update_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_sched_weight_update>()
{
  return ::vapi_msg_id_tm_sys_node_sched_weight_update; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_sched_weight_update>>()
{
  return ::vapi_msg_id_tm_sys_node_sched_weight_update; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_sched_weight_update()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_sched_weight_update>(vapi_msg_id_tm_sys_node_sched_weight_update);
}

template <> inline vapi_msg_tm_sys_node_sched_weight_update* vapi_alloc<vapi_msg_tm_sys_node_sched_weight_update>(Connection &con)
{
  vapi_msg_tm_sys_node_sched_weight_update* result = vapi_alloc_tm_sys_node_sched_weight_update(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_sched_weight_update>;

template class Request<vapi_msg_tm_sys_node_sched_weight_update, vapi_msg_tm_sys_node_sched_weight_update_reply>;

using Tm_sys_node_sched_weight_update = Request<vapi_msg_tm_sys_node_sched_weight_update, vapi_msg_tm_sys_node_sched_weight_update_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_sched_weight_update_reply>(vapi_msg_tm_sys_node_sched_weight_update_reply *msg)
{
  vapi_msg_tm_sys_node_sched_weight_update_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_sched_weight_update_reply>(vapi_msg_tm_sys_node_sched_weight_update_reply *msg)
{
  vapi_msg_tm_sys_node_sched_weight_update_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_sched_weight_update_reply>()
{
  return ::vapi_msg_id_tm_sys_node_sched_weight_update_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_sched_weight_update_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_sched_weight_update_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_sched_weight_update_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_sched_weight_update_reply>(vapi_msg_id_tm_sys_node_sched_weight_update_reply);
}

template class Msg<vapi_msg_tm_sys_node_sched_weight_update_reply>;

using Tm_sys_node_sched_weight_update_reply = Msg<vapi_msg_tm_sys_node_sched_weight_update_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_get_capabilities>(vapi_msg_tm_sys_get_capabilities *msg)
{
  vapi_msg_tm_sys_get_capabilities_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_get_capabilities>(vapi_msg_tm_sys_get_capabilities *msg)
{
  vapi_msg_tm_sys_get_capabilities_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_get_capabilities>()
{
  return ::vapi_msg_id_tm_sys_get_capabilities; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_get_capabilities>>()
{
  return ::vapi_msg_id_tm_sys_get_capabilities; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_get_capabilities()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_get_capabilities>(vapi_msg_id_tm_sys_get_capabilities);
}

template <> inline vapi_msg_tm_sys_get_capabilities* vapi_alloc<vapi_msg_tm_sys_get_capabilities>(Connection &con)
{
  vapi_msg_tm_sys_get_capabilities* result = vapi_alloc_tm_sys_get_capabilities(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_get_capabilities>;

template class Request<vapi_msg_tm_sys_get_capabilities, vapi_msg_tm_sys_get_capabilities_reply>;

using Tm_sys_get_capabilities = Request<vapi_msg_tm_sys_get_capabilities, vapi_msg_tm_sys_get_capabilities_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_get_capabilities_reply>(vapi_msg_tm_sys_get_capabilities_reply *msg)
{
  vapi_msg_tm_sys_get_capabilities_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_get_capabilities_reply>(vapi_msg_tm_sys_get_capabilities_reply *msg)
{
  vapi_msg_tm_sys_get_capabilities_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_get_capabilities_reply>()
{
  return ::vapi_msg_id_tm_sys_get_capabilities_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_get_capabilities_reply>>()
{
  return ::vapi_msg_id_tm_sys_get_capabilities_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_get_capabilities_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_get_capabilities_reply>(vapi_msg_id_tm_sys_get_capabilities_reply);
}

template class Msg<vapi_msg_tm_sys_get_capabilities_reply>;

using Tm_sys_get_capabilities_reply = Msg<vapi_msg_tm_sys_get_capabilities_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_level_get_capabilities>(vapi_msg_tm_sys_level_get_capabilities *msg)
{
  vapi_msg_tm_sys_level_get_capabilities_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_level_get_capabilities>(vapi_msg_tm_sys_level_get_capabilities *msg)
{
  vapi_msg_tm_sys_level_get_capabilities_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_level_get_capabilities>()
{
  return ::vapi_msg_id_tm_sys_level_get_capabilities; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_level_get_capabilities>>()
{
  return ::vapi_msg_id_tm_sys_level_get_capabilities; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_level_get_capabilities()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_level_get_capabilities>(vapi_msg_id_tm_sys_level_get_capabilities);
}

template <> inline vapi_msg_tm_sys_level_get_capabilities* vapi_alloc<vapi_msg_tm_sys_level_get_capabilities>(Connection &con)
{
  vapi_msg_tm_sys_level_get_capabilities* result = vapi_alloc_tm_sys_level_get_capabilities(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_level_get_capabilities>;

template class Request<vapi_msg_tm_sys_level_get_capabilities, vapi_msg_tm_sys_level_get_capabilities_reply>;

using Tm_sys_level_get_capabilities = Request<vapi_msg_tm_sys_level_get_capabilities, vapi_msg_tm_sys_level_get_capabilities_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_level_get_capabilities_reply>(vapi_msg_tm_sys_level_get_capabilities_reply *msg)
{
  vapi_msg_tm_sys_level_get_capabilities_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_level_get_capabilities_reply>(vapi_msg_tm_sys_level_get_capabilities_reply *msg)
{
  vapi_msg_tm_sys_level_get_capabilities_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_level_get_capabilities_reply>()
{
  return ::vapi_msg_id_tm_sys_level_get_capabilities_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_level_get_capabilities_reply>>()
{
  return ::vapi_msg_id_tm_sys_level_get_capabilities_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_level_get_capabilities_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_level_get_capabilities_reply>(vapi_msg_id_tm_sys_level_get_capabilities_reply);
}

template class Msg<vapi_msg_tm_sys_level_get_capabilities_reply>;

using Tm_sys_level_get_capabilities_reply = Msg<vapi_msg_tm_sys_level_get_capabilities_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_read_stats>(vapi_msg_tm_sys_node_read_stats *msg)
{
  vapi_msg_tm_sys_node_read_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_read_stats>(vapi_msg_tm_sys_node_read_stats *msg)
{
  vapi_msg_tm_sys_node_read_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_read_stats>()
{
  return ::vapi_msg_id_tm_sys_node_read_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_read_stats>>()
{
  return ::vapi_msg_id_tm_sys_node_read_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_read_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_read_stats>(vapi_msg_id_tm_sys_node_read_stats);
}

template <> inline vapi_msg_tm_sys_node_read_stats* vapi_alloc<vapi_msg_tm_sys_node_read_stats>(Connection &con)
{
  vapi_msg_tm_sys_node_read_stats* result = vapi_alloc_tm_sys_node_read_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_node_read_stats>;

template class Request<vapi_msg_tm_sys_node_read_stats, vapi_msg_tm_sys_node_read_stats_reply>;

using Tm_sys_node_read_stats = Request<vapi_msg_tm_sys_node_read_stats, vapi_msg_tm_sys_node_read_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_node_read_stats_reply>(vapi_msg_tm_sys_node_read_stats_reply *msg)
{
  vapi_msg_tm_sys_node_read_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_node_read_stats_reply>(vapi_msg_tm_sys_node_read_stats_reply *msg)
{
  vapi_msg_tm_sys_node_read_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_node_read_stats_reply>()
{
  return ::vapi_msg_id_tm_sys_node_read_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_node_read_stats_reply>>()
{
  return ::vapi_msg_id_tm_sys_node_read_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_node_read_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_node_read_stats_reply>(vapi_msg_id_tm_sys_node_read_stats_reply);
}

template class Msg<vapi_msg_tm_sys_node_read_stats_reply>;

using Tm_sys_node_read_stats_reply = Msg<vapi_msg_tm_sys_node_read_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_start_tm>(vapi_msg_tm_sys_start_tm *msg)
{
  vapi_msg_tm_sys_start_tm_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_start_tm>(vapi_msg_tm_sys_start_tm *msg)
{
  vapi_msg_tm_sys_start_tm_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_start_tm>()
{
  return ::vapi_msg_id_tm_sys_start_tm; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_start_tm>>()
{
  return ::vapi_msg_id_tm_sys_start_tm; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_start_tm()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_start_tm>(vapi_msg_id_tm_sys_start_tm);
}

template <> inline vapi_msg_tm_sys_start_tm* vapi_alloc<vapi_msg_tm_sys_start_tm>(Connection &con)
{
  vapi_msg_tm_sys_start_tm* result = vapi_alloc_tm_sys_start_tm(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_start_tm>;

template class Request<vapi_msg_tm_sys_start_tm, vapi_msg_tm_sys_start_tm_reply>;

using Tm_sys_start_tm = Request<vapi_msg_tm_sys_start_tm, vapi_msg_tm_sys_start_tm_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_start_tm_reply>(vapi_msg_tm_sys_start_tm_reply *msg)
{
  vapi_msg_tm_sys_start_tm_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_start_tm_reply>(vapi_msg_tm_sys_start_tm_reply *msg)
{
  vapi_msg_tm_sys_start_tm_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_start_tm_reply>()
{
  return ::vapi_msg_id_tm_sys_start_tm_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_start_tm_reply>>()
{
  return ::vapi_msg_id_tm_sys_start_tm_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_start_tm_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_start_tm_reply>(vapi_msg_id_tm_sys_start_tm_reply);
}

template class Msg<vapi_msg_tm_sys_start_tm_reply>;

using Tm_sys_start_tm_reply = Msg<vapi_msg_tm_sys_start_tm_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_stop_tm>(vapi_msg_tm_sys_stop_tm *msg)
{
  vapi_msg_tm_sys_stop_tm_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_stop_tm>(vapi_msg_tm_sys_stop_tm *msg)
{
  vapi_msg_tm_sys_stop_tm_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_stop_tm>()
{
  return ::vapi_msg_id_tm_sys_stop_tm; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_stop_tm>>()
{
  return ::vapi_msg_id_tm_sys_stop_tm; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_stop_tm()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_stop_tm>(vapi_msg_id_tm_sys_stop_tm);
}

template <> inline vapi_msg_tm_sys_stop_tm* vapi_alloc<vapi_msg_tm_sys_stop_tm>(Connection &con)
{
  vapi_msg_tm_sys_stop_tm* result = vapi_alloc_tm_sys_stop_tm(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tm_sys_stop_tm>;

template class Request<vapi_msg_tm_sys_stop_tm, vapi_msg_tm_sys_stop_tm_reply>;

using Tm_sys_stop_tm = Request<vapi_msg_tm_sys_stop_tm, vapi_msg_tm_sys_stop_tm_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tm_sys_stop_tm_reply>(vapi_msg_tm_sys_stop_tm_reply *msg)
{
  vapi_msg_tm_sys_stop_tm_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tm_sys_stop_tm_reply>(vapi_msg_tm_sys_stop_tm_reply *msg)
{
  vapi_msg_tm_sys_stop_tm_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tm_sys_stop_tm_reply>()
{
  return ::vapi_msg_id_tm_sys_stop_tm_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tm_sys_stop_tm_reply>>()
{
  return ::vapi_msg_id_tm_sys_stop_tm_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tm_sys_stop_tm_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tm_sys_stop_tm_reply>(vapi_msg_id_tm_sys_stop_tm_reply);
}

template class Msg<vapi_msg_tm_sys_stop_tm_reply>;

using Tm_sys_stop_tm_reply = Msg<vapi_msg_tm_sys_stop_tm_reply>;
}
#endif

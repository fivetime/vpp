#ifndef __included_hpp_tracepath_api_json
#define __included_hpp_tracepath_api_json

#include <vapi/vapi.hpp>
#include <vapi/tracepath.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_tracepath_dump>(vapi_msg_tracepath_dump *msg)
{
  vapi_msg_tracepath_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tracepath_dump>(vapi_msg_tracepath_dump *msg)
{
  vapi_msg_tracepath_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tracepath_dump>()
{
  return ::vapi_msg_id_tracepath_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tracepath_dump>>()
{
  return ::vapi_msg_id_tracepath_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tracepath_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tracepath_dump>(vapi_msg_id_tracepath_dump);
}

template <> inline vapi_msg_tracepath_dump* vapi_alloc<vapi_msg_tracepath_dump>(Connection &con)
{
  vapi_msg_tracepath_dump* result = vapi_alloc_tracepath_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tracepath_dump>;

template class Dump<vapi_msg_tracepath_dump, vapi_msg_tracepath_details>;

using Tracepath_dump = Dump<vapi_msg_tracepath_dump, vapi_msg_tracepath_details>;

template <> inline void vapi_swap_to_be<vapi_msg_tracepath_details>(vapi_msg_tracepath_details *msg)
{
  vapi_msg_tracepath_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tracepath_details>(vapi_msg_tracepath_details *msg)
{
  vapi_msg_tracepath_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tracepath_details>()
{
  return ::vapi_msg_id_tracepath_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tracepath_details>>()
{
  return ::vapi_msg_id_tracepath_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tracepath_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tracepath_details>(vapi_msg_id_tracepath_details);
}

template class Msg<vapi_msg_tracepath_details>;

using Tracepath_details = Msg<vapi_msg_tracepath_details>;
}
#endif

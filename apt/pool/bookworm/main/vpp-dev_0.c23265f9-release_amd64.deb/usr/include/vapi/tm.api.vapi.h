#ifndef __included_tm_api_json
#define __included_tm_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_tm_sys_node_add;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_add_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_suspend;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_suspend_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_resume;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_resume_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_delete;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_delete_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_create;
extern vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_create_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_shaper_update;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_shaper_update_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_delete;
extern vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_delete_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_sched_weight_update;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_sched_weight_update_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_get_capabilities;
extern vapi_msg_id_t vapi_msg_id_tm_sys_get_capabilities_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_level_get_capabilities;
extern vapi_msg_id_t vapi_msg_id_tm_sys_level_get_capabilities_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_read_stats;
extern vapi_msg_id_t vapi_msg_id_tm_sys_node_read_stats_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_start_tm;
extern vapi_msg_id_t vapi_msg_id_tm_sys_start_tm_reply;
extern vapi_msg_id_t vapi_msg_id_tm_sys_stop_tm;
extern vapi_msg_id_t vapi_msg_id_tm_sys_stop_tm_reply;

#define DEFINE_VAPI_MSG_IDS_TM_API_JSON\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_add;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_add_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_suspend;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_suspend_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_resume;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_resume_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_delete;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_delete_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_create;\
  vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_create_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_shaper_update;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_shaper_update_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_delete;\
  vapi_msg_id_t vapi_msg_id_tm_sys_shaper_profile_delete_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_sched_weight_update;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_sched_weight_update_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_get_capabilities;\
  vapi_msg_id_t vapi_msg_id_tm_sys_get_capabilities_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_level_get_capabilities;\
  vapi_msg_id_t vapi_msg_id_tm_sys_level_get_capabilities_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_read_stats;\
  vapi_msg_id_t vapi_msg_id_tm_sys_node_read_stats_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_start_tm;\
  vapi_msg_id_t vapi_msg_id_tm_sys_start_tm_reply;\
  vapi_msg_id_t vapi_msg_id_tm_sys_stop_tm;\
  vapi_msg_id_t vapi_msg_id_tm_sys_stop_tm_reply;


#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_add_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_add_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_add_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_add_reply payload;
} vapi_msg_tm_sys_node_add_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_add_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_add_reply
static inline void vapi_msg_tm_sys_node_add_reply_payload_hton(vapi_payload_tm_sys_node_add_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_add_reply_payload_ntoh(vapi_payload_tm_sys_node_add_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_add_reply_hton(vapi_msg_tm_sys_node_add_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_add_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_add_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_add_reply_ntoh(vapi_msg_tm_sys_node_add_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_add_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_add_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_add_reply_msg_size(vapi_msg_tm_sys_node_add_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_add_reply_msg_size(vapi_msg_tm_sys_node_add_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_add_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_add_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_add_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_add_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_add_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_add_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_add_reply()
{
  static const char name[] = "tm_sys_node_add_reply";
  static const char name_with_crc[] = "tm_sys_node_add_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_add_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_add_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_add_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_add_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_add_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_add_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_add_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_add_reply", vapi_msg_id_tm_sys_node_add_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_add_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_add_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_add_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_add
#define __vapi_def_defined_vapi_msg_tm_sys_node_add
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  i32 parent_node_id;
  u32 node_id;
  u32 weight;
  i32 shaper_id;
  u32 lvl;
  u32 priority;
  u8 flow_name[64]; 
} vapi_payload_tm_sys_node_add;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_add payload;
} vapi_msg_tm_sys_node_add;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_add
#define __vapi_code_defined_vapi_msg_tm_sys_node_add
static inline void vapi_msg_tm_sys_node_add_payload_hton(vapi_payload_tm_sys_node_add *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->parent_node_id = htobe32(payload->parent_node_id);
  payload->node_id = htobe32(payload->node_id);
  payload->weight = htobe32(payload->weight);
  payload->shaper_id = htobe32(payload->shaper_id);
  payload->lvl = htobe32(payload->lvl);
  payload->priority = htobe32(payload->priority);
}

static inline void vapi_msg_tm_sys_node_add_payload_ntoh(vapi_payload_tm_sys_node_add *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->parent_node_id = be32toh(payload->parent_node_id);
  payload->node_id = be32toh(payload->node_id);
  payload->weight = be32toh(payload->weight);
  payload->shaper_id = be32toh(payload->shaper_id);
  payload->lvl = be32toh(payload->lvl);
  payload->priority = be32toh(payload->priority);
}

static inline void vapi_msg_tm_sys_node_add_hton(vapi_msg_tm_sys_node_add *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_add'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_add_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_add_ntoh(vapi_msg_tm_sys_node_add *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_add'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_add_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_add_msg_size(vapi_msg_tm_sys_node_add *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_add_msg_size(vapi_msg_tm_sys_node_add *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_add) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_add' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_add));
      return -1;
    }
  if (vapi_calc_tm_sys_node_add_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_add' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_add_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_add* vapi_alloc_tm_sys_node_add(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_add *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_add);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_add*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_add);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_add(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_add *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_add_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_add_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_add_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_add_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_add()
{
  static const char name[] = "tm_sys_node_add";
  static const char name_with_crc[] = "tm_sys_node_add_0f60688a";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_add = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_add, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_add_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_add_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_add_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_add = vapi_register_msg(&__vapi_metadata_tm_sys_node_add);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_add", vapi_msg_id_tm_sys_node_add);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_suspend_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_suspend_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_suspend_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_suspend_reply payload;
} vapi_msg_tm_sys_node_suspend_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_suspend_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_suspend_reply
static inline void vapi_msg_tm_sys_node_suspend_reply_payload_hton(vapi_payload_tm_sys_node_suspend_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_suspend_reply_payload_ntoh(vapi_payload_tm_sys_node_suspend_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_suspend_reply_hton(vapi_msg_tm_sys_node_suspend_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_suspend_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_suspend_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_suspend_reply_ntoh(vapi_msg_tm_sys_node_suspend_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_suspend_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_suspend_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_suspend_reply_msg_size(vapi_msg_tm_sys_node_suspend_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_suspend_reply_msg_size(vapi_msg_tm_sys_node_suspend_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_suspend_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_suspend_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_suspend_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_suspend_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_suspend_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_suspend_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_suspend_reply()
{
  static const char name[] = "tm_sys_node_suspend_reply";
  static const char name_with_crc[] = "tm_sys_node_suspend_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_suspend_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_suspend_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_suspend_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_suspend_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_suspend_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_suspend_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_suspend_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_suspend_reply", vapi_msg_id_tm_sys_node_suspend_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_suspend_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_suspend_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_suspend_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_suspend
#define __vapi_def_defined_vapi_msg_tm_sys_node_suspend
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 tm_node_id; 
} vapi_payload_tm_sys_node_suspend;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_suspend payload;
} vapi_msg_tm_sys_node_suspend;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_suspend
#define __vapi_code_defined_vapi_msg_tm_sys_node_suspend
static inline void vapi_msg_tm_sys_node_suspend_payload_hton(vapi_payload_tm_sys_node_suspend *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->tm_node_id = htobe32(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_suspend_payload_ntoh(vapi_payload_tm_sys_node_suspend *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->tm_node_id = be32toh(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_suspend_hton(vapi_msg_tm_sys_node_suspend *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_suspend'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_suspend_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_suspend_ntoh(vapi_msg_tm_sys_node_suspend *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_suspend'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_suspend_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_suspend_msg_size(vapi_msg_tm_sys_node_suspend *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_suspend_msg_size(vapi_msg_tm_sys_node_suspend *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_suspend) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_suspend' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_suspend));
      return -1;
    }
  if (vapi_calc_tm_sys_node_suspend_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_suspend' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_suspend_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_suspend* vapi_alloc_tm_sys_node_suspend(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_suspend *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_suspend);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_suspend*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_suspend);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_suspend(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_suspend *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_suspend_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_suspend_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_suspend_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_suspend_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_suspend()
{
  static const char name[] = "tm_sys_node_suspend";
  static const char name_with_crc[] = "tm_sys_node_suspend_0cfbb348";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_suspend = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_suspend, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_suspend_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_suspend_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_suspend_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_suspend = vapi_register_msg(&__vapi_metadata_tm_sys_node_suspend);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_suspend", vapi_msg_id_tm_sys_node_suspend);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_resume_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_resume_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_resume_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_resume_reply payload;
} vapi_msg_tm_sys_node_resume_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_resume_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_resume_reply
static inline void vapi_msg_tm_sys_node_resume_reply_payload_hton(vapi_payload_tm_sys_node_resume_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_resume_reply_payload_ntoh(vapi_payload_tm_sys_node_resume_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_resume_reply_hton(vapi_msg_tm_sys_node_resume_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_resume_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_resume_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_resume_reply_ntoh(vapi_msg_tm_sys_node_resume_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_resume_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_resume_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_resume_reply_msg_size(vapi_msg_tm_sys_node_resume_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_resume_reply_msg_size(vapi_msg_tm_sys_node_resume_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_resume_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_resume_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_resume_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_resume_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_resume_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_resume_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_resume_reply()
{
  static const char name[] = "tm_sys_node_resume_reply";
  static const char name_with_crc[] = "tm_sys_node_resume_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_resume_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_resume_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_resume_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_resume_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_resume_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_resume_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_resume_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_resume_reply", vapi_msg_id_tm_sys_node_resume_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_resume_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_resume_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_resume_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_resume
#define __vapi_def_defined_vapi_msg_tm_sys_node_resume
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 tm_node_id; 
} vapi_payload_tm_sys_node_resume;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_resume payload;
} vapi_msg_tm_sys_node_resume;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_resume
#define __vapi_code_defined_vapi_msg_tm_sys_node_resume
static inline void vapi_msg_tm_sys_node_resume_payload_hton(vapi_payload_tm_sys_node_resume *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->tm_node_id = htobe32(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_resume_payload_ntoh(vapi_payload_tm_sys_node_resume *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->tm_node_id = be32toh(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_resume_hton(vapi_msg_tm_sys_node_resume *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_resume'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_resume_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_resume_ntoh(vapi_msg_tm_sys_node_resume *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_resume'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_resume_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_resume_msg_size(vapi_msg_tm_sys_node_resume *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_resume_msg_size(vapi_msg_tm_sys_node_resume *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_resume) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_resume' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_resume));
      return -1;
    }
  if (vapi_calc_tm_sys_node_resume_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_resume' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_resume_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_resume* vapi_alloc_tm_sys_node_resume(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_resume *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_resume);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_resume*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_resume);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_resume(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_resume *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_resume_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_resume_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_resume_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_resume_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_resume()
{
  static const char name[] = "tm_sys_node_resume";
  static const char name_with_crc[] = "tm_sys_node_resume_0cfbb348";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_resume = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_resume, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_resume_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_resume_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_resume_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_resume = vapi_register_msg(&__vapi_metadata_tm_sys_node_resume);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_resume", vapi_msg_id_tm_sys_node_resume);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_delete_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_delete_reply payload;
} vapi_msg_tm_sys_node_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_delete_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_delete_reply
static inline void vapi_msg_tm_sys_node_delete_reply_payload_hton(vapi_payload_tm_sys_node_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_delete_reply_payload_ntoh(vapi_payload_tm_sys_node_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_delete_reply_hton(vapi_msg_tm_sys_node_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_delete_reply_ntoh(vapi_msg_tm_sys_node_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_delete_reply_msg_size(vapi_msg_tm_sys_node_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_delete_reply_msg_size(vapi_msg_tm_sys_node_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_delete_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_delete_reply()
{
  static const char name[] = "tm_sys_node_delete_reply";
  static const char name_with_crc[] = "tm_sys_node_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_delete_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_delete_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_delete_reply", vapi_msg_id_tm_sys_node_delete_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_delete
#define __vapi_def_defined_vapi_msg_tm_sys_node_delete
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 tm_node_id; 
} vapi_payload_tm_sys_node_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_delete payload;
} vapi_msg_tm_sys_node_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_delete
#define __vapi_code_defined_vapi_msg_tm_sys_node_delete
static inline void vapi_msg_tm_sys_node_delete_payload_hton(vapi_payload_tm_sys_node_delete *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->tm_node_id = htobe32(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_delete_payload_ntoh(vapi_payload_tm_sys_node_delete *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->tm_node_id = be32toh(payload->tm_node_id);
}

static inline void vapi_msg_tm_sys_node_delete_hton(vapi_msg_tm_sys_node_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_delete_ntoh(vapi_msg_tm_sys_node_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_delete_msg_size(vapi_msg_tm_sys_node_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_delete_msg_size(vapi_msg_tm_sys_node_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_delete));
      return -1;
    }
  if (vapi_calc_tm_sys_node_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_delete* vapi_alloc_tm_sys_node_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_delete);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_delete(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_delete()
{
  static const char name[] = "tm_sys_node_delete";
  static const char name_with_crc[] = "tm_sys_node_delete_0cfbb348";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_delete_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_delete = vapi_register_msg(&__vapi_metadata_tm_sys_node_delete);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_delete", vapi_msg_id_tm_sys_node_delete);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_create_reply
#define __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_create_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_shaper_profile_create_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_shaper_profile_create_reply payload;
} vapi_msg_tm_sys_shaper_profile_create_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_create_reply
#define __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_create_reply
static inline void vapi_msg_tm_sys_shaper_profile_create_reply_payload_hton(vapi_payload_tm_sys_shaper_profile_create_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_reply_payload_ntoh(vapi_payload_tm_sys_shaper_profile_create_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_reply_hton(vapi_msg_tm_sys_shaper_profile_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_create_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_shaper_profile_create_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_reply_ntoh(vapi_msg_tm_sys_shaper_profile_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_create_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_shaper_profile_create_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_shaper_profile_create_reply_msg_size(vapi_msg_tm_sys_shaper_profile_create_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_shaper_profile_create_reply_msg_size(vapi_msg_tm_sys_shaper_profile_create_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_shaper_profile_create_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_shaper_profile_create_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_shaper_profile_create_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_shaper_profile_create_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_shaper_profile_create_reply()
{
  static const char name[] = "tm_sys_shaper_profile_create_reply";
  static const char name_with_crc[] = "tm_sys_shaper_profile_create_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_shaper_profile_create_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_shaper_profile_create_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_shaper_profile_create_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_create_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_create_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_shaper_profile_create_reply = vapi_register_msg(&__vapi_metadata_tm_sys_shaper_profile_create_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_shaper_profile_create_reply", vapi_msg_id_tm_sys_shaper_profile_create_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_shaper_profile_create_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_shaper_profile_create_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_shaper_profile_create_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_create
#define __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_create
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 tm_shaper_id;
  u8 is_pkt_mode;
  u64 shaper_commit_rate;
  u64 shaper_commit_burst;
  u64 shaper_peak_rate;
  u64 shaper_peak_burst;
  i32 shaper_len_adjust; 
} vapi_payload_tm_sys_shaper_profile_create;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_shaper_profile_create payload;
} vapi_msg_tm_sys_shaper_profile_create;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_create
#define __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_create
static inline void vapi_msg_tm_sys_shaper_profile_create_payload_hton(vapi_payload_tm_sys_shaper_profile_create *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->tm_shaper_id = htobe32(payload->tm_shaper_id);
  payload->shaper_commit_rate = htobe64(payload->shaper_commit_rate);
  payload->shaper_commit_burst = htobe64(payload->shaper_commit_burst);
  payload->shaper_peak_rate = htobe64(payload->shaper_peak_rate);
  payload->shaper_peak_burst = htobe64(payload->shaper_peak_burst);
  payload->shaper_len_adjust = htobe32(payload->shaper_len_adjust);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_payload_ntoh(vapi_payload_tm_sys_shaper_profile_create *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->tm_shaper_id = be32toh(payload->tm_shaper_id);
  payload->shaper_commit_rate = be64toh(payload->shaper_commit_rate);
  payload->shaper_commit_burst = be64toh(payload->shaper_commit_burst);
  payload->shaper_peak_rate = be64toh(payload->shaper_peak_rate);
  payload->shaper_peak_burst = be64toh(payload->shaper_peak_burst);
  payload->shaper_len_adjust = be32toh(payload->shaper_len_adjust);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_hton(vapi_msg_tm_sys_shaper_profile_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_create'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_shaper_profile_create_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_shaper_profile_create_ntoh(vapi_msg_tm_sys_shaper_profile_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_create'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_shaper_profile_create_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_shaper_profile_create_msg_size(vapi_msg_tm_sys_shaper_profile_create *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_shaper_profile_create_msg_size(vapi_msg_tm_sys_shaper_profile_create *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_shaper_profile_create) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_shaper_profile_create));
      return -1;
    }
  if (vapi_calc_tm_sys_shaper_profile_create_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_shaper_profile_create_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_shaper_profile_create* vapi_alloc_tm_sys_shaper_profile_create(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_shaper_profile_create *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_shaper_profile_create);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_shaper_profile_create*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_shaper_profile_create);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_shaper_profile_create(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_shaper_profile_create *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_shaper_profile_create_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_shaper_profile_create_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_shaper_profile_create_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_shaper_profile_create_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_shaper_profile_create()
{
  static const char name[] = "tm_sys_shaper_profile_create";
  static const char name_with_crc[] = "tm_sys_shaper_profile_create_65d7728b";
  static vapi_message_desc_t __vapi_metadata_tm_sys_shaper_profile_create = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_shaper_profile_create, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_shaper_profile_create_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_create_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_create_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_shaper_profile_create = vapi_register_msg(&__vapi_metadata_tm_sys_shaper_profile_create);
  VAPI_DBG("Assigned msg id %d to tm_sys_shaper_profile_create", vapi_msg_id_tm_sys_shaper_profile_create);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_shaper_update_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_shaper_update_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_shaper_update_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_shaper_update_reply payload;
} vapi_msg_tm_sys_node_shaper_update_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_shaper_update_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_shaper_update_reply
static inline void vapi_msg_tm_sys_node_shaper_update_reply_payload_hton(vapi_payload_tm_sys_node_shaper_update_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_shaper_update_reply_payload_ntoh(vapi_payload_tm_sys_node_shaper_update_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_shaper_update_reply_hton(vapi_msg_tm_sys_node_shaper_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_shaper_update_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_shaper_update_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_shaper_update_reply_ntoh(vapi_msg_tm_sys_node_shaper_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_shaper_update_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_shaper_update_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_shaper_update_reply_msg_size(vapi_msg_tm_sys_node_shaper_update_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_shaper_update_reply_msg_size(vapi_msg_tm_sys_node_shaper_update_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_shaper_update_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_shaper_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_shaper_update_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_shaper_update_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_shaper_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_shaper_update_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_shaper_update_reply()
{
  static const char name[] = "tm_sys_node_shaper_update_reply";
  static const char name_with_crc[] = "tm_sys_node_shaper_update_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_shaper_update_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_shaper_update_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_shaper_update_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_shaper_update_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_shaper_update_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_shaper_update_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_shaper_update_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_shaper_update_reply", vapi_msg_id_tm_sys_node_shaper_update_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_shaper_update_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_shaper_update_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_shaper_update_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_shaper_update
#define __vapi_def_defined_vapi_msg_tm_sys_node_shaper_update
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  i32 shaper_id;
  u32 node_id; 
} vapi_payload_tm_sys_node_shaper_update;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_shaper_update payload;
} vapi_msg_tm_sys_node_shaper_update;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_shaper_update
#define __vapi_code_defined_vapi_msg_tm_sys_node_shaper_update
static inline void vapi_msg_tm_sys_node_shaper_update_payload_hton(vapi_payload_tm_sys_node_shaper_update *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->shaper_id = htobe32(payload->shaper_id);
  payload->node_id = htobe32(payload->node_id);
}

static inline void vapi_msg_tm_sys_node_shaper_update_payload_ntoh(vapi_payload_tm_sys_node_shaper_update *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->shaper_id = be32toh(payload->shaper_id);
  payload->node_id = be32toh(payload->node_id);
}

static inline void vapi_msg_tm_sys_node_shaper_update_hton(vapi_msg_tm_sys_node_shaper_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_shaper_update'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_shaper_update_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_shaper_update_ntoh(vapi_msg_tm_sys_node_shaper_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_shaper_update'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_shaper_update_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_shaper_update_msg_size(vapi_msg_tm_sys_node_shaper_update *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_shaper_update_msg_size(vapi_msg_tm_sys_node_shaper_update *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_shaper_update) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_shaper_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_shaper_update));
      return -1;
    }
  if (vapi_calc_tm_sys_node_shaper_update_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_shaper_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_shaper_update_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_shaper_update* vapi_alloc_tm_sys_node_shaper_update(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_shaper_update *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_shaper_update);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_shaper_update*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_shaper_update);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_shaper_update(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_shaper_update *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_shaper_update_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_shaper_update_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_shaper_update_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_shaper_update_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_shaper_update()
{
  static const char name[] = "tm_sys_node_shaper_update";
  static const char name_with_crc[] = "tm_sys_node_shaper_update_22ab653b";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_shaper_update = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_shaper_update, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_shaper_update_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_shaper_update_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_shaper_update_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_shaper_update = vapi_register_msg(&__vapi_metadata_tm_sys_node_shaper_update);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_shaper_update", vapi_msg_id_tm_sys_node_shaper_update);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_delete_reply
#define __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_shaper_profile_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_shaper_profile_delete_reply payload;
} vapi_msg_tm_sys_shaper_profile_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_delete_reply
#define __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_delete_reply
static inline void vapi_msg_tm_sys_shaper_profile_delete_reply_payload_hton(vapi_payload_tm_sys_shaper_profile_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_reply_payload_ntoh(vapi_payload_tm_sys_shaper_profile_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_reply_hton(vapi_msg_tm_sys_shaper_profile_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_shaper_profile_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_reply_ntoh(vapi_msg_tm_sys_shaper_profile_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_shaper_profile_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_shaper_profile_delete_reply_msg_size(vapi_msg_tm_sys_shaper_profile_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_shaper_profile_delete_reply_msg_size(vapi_msg_tm_sys_shaper_profile_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_shaper_profile_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_shaper_profile_delete_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_shaper_profile_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_shaper_profile_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_shaper_profile_delete_reply()
{
  static const char name[] = "tm_sys_shaper_profile_delete_reply";
  static const char name_with_crc[] = "tm_sys_shaper_profile_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_shaper_profile_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_shaper_profile_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_shaper_profile_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_shaper_profile_delete_reply = vapi_register_msg(&__vapi_metadata_tm_sys_shaper_profile_delete_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_shaper_profile_delete_reply", vapi_msg_id_tm_sys_shaper_profile_delete_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_shaper_profile_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_shaper_profile_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_shaper_profile_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_delete
#define __vapi_def_defined_vapi_msg_tm_sys_shaper_profile_delete
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  i32 shaper_id; 
} vapi_payload_tm_sys_shaper_profile_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_shaper_profile_delete payload;
} vapi_msg_tm_sys_shaper_profile_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_delete
#define __vapi_code_defined_vapi_msg_tm_sys_shaper_profile_delete
static inline void vapi_msg_tm_sys_shaper_profile_delete_payload_hton(vapi_payload_tm_sys_shaper_profile_delete *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->shaper_id = htobe32(payload->shaper_id);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_payload_ntoh(vapi_payload_tm_sys_shaper_profile_delete *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->shaper_id = be32toh(payload->shaper_id);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_hton(vapi_msg_tm_sys_shaper_profile_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_shaper_profile_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_shaper_profile_delete_ntoh(vapi_msg_tm_sys_shaper_profile_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_shaper_profile_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_shaper_profile_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_shaper_profile_delete_msg_size(vapi_msg_tm_sys_shaper_profile_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_shaper_profile_delete_msg_size(vapi_msg_tm_sys_shaper_profile_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_shaper_profile_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_shaper_profile_delete));
      return -1;
    }
  if (vapi_calc_tm_sys_shaper_profile_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_shaper_profile_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_shaper_profile_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_shaper_profile_delete* vapi_alloc_tm_sys_shaper_profile_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_shaper_profile_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_shaper_profile_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_shaper_profile_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_shaper_profile_delete);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_shaper_profile_delete(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_shaper_profile_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_shaper_profile_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_shaper_profile_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_shaper_profile_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_shaper_profile_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_shaper_profile_delete()
{
  static const char name[] = "tm_sys_shaper_profile_delete";
  static const char name_with_crc[] = "tm_sys_shaper_profile_delete_ed96e391";
  static vapi_message_desc_t __vapi_metadata_tm_sys_shaper_profile_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_shaper_profile_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_shaper_profile_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_delete_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_shaper_profile_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_shaper_profile_delete = vapi_register_msg(&__vapi_metadata_tm_sys_shaper_profile_delete);
  VAPI_DBG("Assigned msg id %d to tm_sys_shaper_profile_delete", vapi_msg_id_tm_sys_shaper_profile_delete);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_sched_weight_update_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_sched_weight_update_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_sched_weight_update_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_sched_weight_update_reply payload;
} vapi_msg_tm_sys_node_sched_weight_update_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_sched_weight_update_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_sched_weight_update_reply
static inline void vapi_msg_tm_sys_node_sched_weight_update_reply_payload_hton(vapi_payload_tm_sys_node_sched_weight_update_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_reply_payload_ntoh(vapi_payload_tm_sys_node_sched_weight_update_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_reply_hton(vapi_msg_tm_sys_node_sched_weight_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_sched_weight_update_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_sched_weight_update_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_reply_ntoh(vapi_msg_tm_sys_node_sched_weight_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_sched_weight_update_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_sched_weight_update_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_sched_weight_update_reply_msg_size(vapi_msg_tm_sys_node_sched_weight_update_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_sched_weight_update_reply_msg_size(vapi_msg_tm_sys_node_sched_weight_update_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_sched_weight_update_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_sched_weight_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_sched_weight_update_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_sched_weight_update_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_sched_weight_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_sched_weight_update_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_sched_weight_update_reply()
{
  static const char name[] = "tm_sys_node_sched_weight_update_reply";
  static const char name_with_crc[] = "tm_sys_node_sched_weight_update_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_sched_weight_update_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_sched_weight_update_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_sched_weight_update_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_sched_weight_update_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_sched_weight_update_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_sched_weight_update_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_sched_weight_update_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_sched_weight_update_reply", vapi_msg_id_tm_sys_node_sched_weight_update_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_sched_weight_update_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_sched_weight_update_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_sched_weight_update_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_sched_weight_update
#define __vapi_def_defined_vapi_msg_tm_sys_node_sched_weight_update
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 node_id;
  u32 weight; 
} vapi_payload_tm_sys_node_sched_weight_update;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_sched_weight_update payload;
} vapi_msg_tm_sys_node_sched_weight_update;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_sched_weight_update
#define __vapi_code_defined_vapi_msg_tm_sys_node_sched_weight_update
static inline void vapi_msg_tm_sys_node_sched_weight_update_payload_hton(vapi_payload_tm_sys_node_sched_weight_update *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->node_id = htobe32(payload->node_id);
  payload->weight = htobe32(payload->weight);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_payload_ntoh(vapi_payload_tm_sys_node_sched_weight_update *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->node_id = be32toh(payload->node_id);
  payload->weight = be32toh(payload->weight);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_hton(vapi_msg_tm_sys_node_sched_weight_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_sched_weight_update'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_sched_weight_update_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_sched_weight_update_ntoh(vapi_msg_tm_sys_node_sched_weight_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_sched_weight_update'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_sched_weight_update_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_sched_weight_update_msg_size(vapi_msg_tm_sys_node_sched_weight_update *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_sched_weight_update_msg_size(vapi_msg_tm_sys_node_sched_weight_update *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_sched_weight_update) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_sched_weight_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_sched_weight_update));
      return -1;
    }
  if (vapi_calc_tm_sys_node_sched_weight_update_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_sched_weight_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_sched_weight_update_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_sched_weight_update* vapi_alloc_tm_sys_node_sched_weight_update(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_sched_weight_update *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_sched_weight_update);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_sched_weight_update*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_sched_weight_update);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_sched_weight_update(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_sched_weight_update *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_sched_weight_update_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_sched_weight_update_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_sched_weight_update_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_sched_weight_update_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_sched_weight_update()
{
  static const char name[] = "tm_sys_node_sched_weight_update";
  static const char name_with_crc[] = "tm_sys_node_sched_weight_update_8f0ff13e";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_sched_weight_update = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_sched_weight_update, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_sched_weight_update_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_sched_weight_update_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_sched_weight_update_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_sched_weight_update = vapi_register_msg(&__vapi_metadata_tm_sys_node_sched_weight_update);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_sched_weight_update", vapi_msg_id_tm_sys_node_sched_weight_update);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_get_capabilities_reply
#define __vapi_def_defined_vapi_msg_tm_sys_get_capabilities_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_get_capabilities_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_get_capabilities_reply payload;
} vapi_msg_tm_sys_get_capabilities_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_get_capabilities_reply
#define __vapi_code_defined_vapi_msg_tm_sys_get_capabilities_reply
static inline void vapi_msg_tm_sys_get_capabilities_reply_payload_hton(vapi_payload_tm_sys_get_capabilities_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_get_capabilities_reply_payload_ntoh(vapi_payload_tm_sys_get_capabilities_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_get_capabilities_reply_hton(vapi_msg_tm_sys_get_capabilities_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_get_capabilities_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_get_capabilities_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_get_capabilities_reply_ntoh(vapi_msg_tm_sys_get_capabilities_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_get_capabilities_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_get_capabilities_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_get_capabilities_reply_msg_size(vapi_msg_tm_sys_get_capabilities_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_get_capabilities_reply_msg_size(vapi_msg_tm_sys_get_capabilities_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_get_capabilities_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_get_capabilities_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_get_capabilities_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_get_capabilities_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_get_capabilities_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_get_capabilities_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_get_capabilities_reply()
{
  static const char name[] = "tm_sys_get_capabilities_reply";
  static const char name_with_crc[] = "tm_sys_get_capabilities_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_get_capabilities_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_get_capabilities_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_get_capabilities_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_get_capabilities_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_get_capabilities_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_get_capabilities_reply = vapi_register_msg(&__vapi_metadata_tm_sys_get_capabilities_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_get_capabilities_reply", vapi_msg_id_tm_sys_get_capabilities_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_get_capabilities_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_get_capabilities_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_get_capabilities_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_get_capabilities
#define __vapi_def_defined_vapi_msg_tm_sys_get_capabilities
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx; 
} vapi_payload_tm_sys_get_capabilities;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_get_capabilities payload;
} vapi_msg_tm_sys_get_capabilities;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_get_capabilities
#define __vapi_code_defined_vapi_msg_tm_sys_get_capabilities
static inline void vapi_msg_tm_sys_get_capabilities_payload_hton(vapi_payload_tm_sys_get_capabilities *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_get_capabilities_payload_ntoh(vapi_payload_tm_sys_get_capabilities *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_get_capabilities_hton(vapi_msg_tm_sys_get_capabilities *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_get_capabilities'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_get_capabilities_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_get_capabilities_ntoh(vapi_msg_tm_sys_get_capabilities *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_get_capabilities'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_get_capabilities_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_get_capabilities_msg_size(vapi_msg_tm_sys_get_capabilities *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_get_capabilities_msg_size(vapi_msg_tm_sys_get_capabilities *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_get_capabilities) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_get_capabilities' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_get_capabilities));
      return -1;
    }
  if (vapi_calc_tm_sys_get_capabilities_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_get_capabilities' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_get_capabilities_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_get_capabilities* vapi_alloc_tm_sys_get_capabilities(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_get_capabilities *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_get_capabilities);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_get_capabilities*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_get_capabilities);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_get_capabilities(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_get_capabilities *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_get_capabilities_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_get_capabilities_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_get_capabilities_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_get_capabilities_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_get_capabilities()
{
  static const char name[] = "tm_sys_get_capabilities";
  static const char name_with_crc[] = "tm_sys_get_capabilities_991d3cc9";
  static vapi_message_desc_t __vapi_metadata_tm_sys_get_capabilities = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_get_capabilities, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_get_capabilities_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_get_capabilities_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_get_capabilities_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_get_capabilities = vapi_register_msg(&__vapi_metadata_tm_sys_get_capabilities);
  VAPI_DBG("Assigned msg id %d to tm_sys_get_capabilities", vapi_msg_id_tm_sys_get_capabilities);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_level_get_capabilities_reply
#define __vapi_def_defined_vapi_msg_tm_sys_level_get_capabilities_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_level_get_capabilities_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_level_get_capabilities_reply payload;
} vapi_msg_tm_sys_level_get_capabilities_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_level_get_capabilities_reply
#define __vapi_code_defined_vapi_msg_tm_sys_level_get_capabilities_reply
static inline void vapi_msg_tm_sys_level_get_capabilities_reply_payload_hton(vapi_payload_tm_sys_level_get_capabilities_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_reply_payload_ntoh(vapi_payload_tm_sys_level_get_capabilities_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_reply_hton(vapi_msg_tm_sys_level_get_capabilities_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_level_get_capabilities_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_level_get_capabilities_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_reply_ntoh(vapi_msg_tm_sys_level_get_capabilities_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_level_get_capabilities_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_level_get_capabilities_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_level_get_capabilities_reply_msg_size(vapi_msg_tm_sys_level_get_capabilities_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_level_get_capabilities_reply_msg_size(vapi_msg_tm_sys_level_get_capabilities_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_level_get_capabilities_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_level_get_capabilities_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_level_get_capabilities_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_level_get_capabilities_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_level_get_capabilities_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_level_get_capabilities_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_level_get_capabilities_reply()
{
  static const char name[] = "tm_sys_level_get_capabilities_reply";
  static const char name_with_crc[] = "tm_sys_level_get_capabilities_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_level_get_capabilities_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_level_get_capabilities_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_level_get_capabilities_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_level_get_capabilities_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_level_get_capabilities_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_level_get_capabilities_reply = vapi_register_msg(&__vapi_metadata_tm_sys_level_get_capabilities_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_level_get_capabilities_reply", vapi_msg_id_tm_sys_level_get_capabilities_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_level_get_capabilities_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_level_get_capabilities_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_level_get_capabilities_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_level_get_capabilities
#define __vapi_def_defined_vapi_msg_tm_sys_level_get_capabilities
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 level; 
} vapi_payload_tm_sys_level_get_capabilities;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_level_get_capabilities payload;
} vapi_msg_tm_sys_level_get_capabilities;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_level_get_capabilities
#define __vapi_code_defined_vapi_msg_tm_sys_level_get_capabilities
static inline void vapi_msg_tm_sys_level_get_capabilities_payload_hton(vapi_payload_tm_sys_level_get_capabilities *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->level = htobe32(payload->level);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_payload_ntoh(vapi_payload_tm_sys_level_get_capabilities *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->level = be32toh(payload->level);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_hton(vapi_msg_tm_sys_level_get_capabilities *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_level_get_capabilities'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_level_get_capabilities_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_level_get_capabilities_ntoh(vapi_msg_tm_sys_level_get_capabilities *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_level_get_capabilities'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_level_get_capabilities_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_level_get_capabilities_msg_size(vapi_msg_tm_sys_level_get_capabilities *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_level_get_capabilities_msg_size(vapi_msg_tm_sys_level_get_capabilities *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_level_get_capabilities) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_level_get_capabilities' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_level_get_capabilities));
      return -1;
    }
  if (vapi_calc_tm_sys_level_get_capabilities_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_level_get_capabilities' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_level_get_capabilities_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_level_get_capabilities* vapi_alloc_tm_sys_level_get_capabilities(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_level_get_capabilities *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_level_get_capabilities);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_level_get_capabilities*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_level_get_capabilities);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_level_get_capabilities(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_level_get_capabilities *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_level_get_capabilities_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_level_get_capabilities_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_level_get_capabilities_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_level_get_capabilities_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_level_get_capabilities()
{
  static const char name[] = "tm_sys_level_get_capabilities";
  static const char name_with_crc[] = "tm_sys_level_get_capabilities_1b2a3c26";
  static vapi_message_desc_t __vapi_metadata_tm_sys_level_get_capabilities = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_level_get_capabilities, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_level_get_capabilities_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_level_get_capabilities_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_level_get_capabilities_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_level_get_capabilities = vapi_register_msg(&__vapi_metadata_tm_sys_level_get_capabilities);
  VAPI_DBG("Assigned msg id %d to tm_sys_level_get_capabilities", vapi_msg_id_tm_sys_level_get_capabilities);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_read_stats_reply
#define __vapi_def_defined_vapi_msg_tm_sys_node_read_stats_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_node_read_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_node_read_stats_reply payload;
} vapi_msg_tm_sys_node_read_stats_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_read_stats_reply
#define __vapi_code_defined_vapi_msg_tm_sys_node_read_stats_reply
static inline void vapi_msg_tm_sys_node_read_stats_reply_payload_hton(vapi_payload_tm_sys_node_read_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_node_read_stats_reply_payload_ntoh(vapi_payload_tm_sys_node_read_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_node_read_stats_reply_hton(vapi_msg_tm_sys_node_read_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_read_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_node_read_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_read_stats_reply_ntoh(vapi_msg_tm_sys_node_read_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_read_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_read_stats_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_read_stats_reply_msg_size(vapi_msg_tm_sys_node_read_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_read_stats_reply_msg_size(vapi_msg_tm_sys_node_read_stats_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_read_stats_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_read_stats_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_read_stats_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_node_read_stats_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_read_stats_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_read_stats_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_read_stats_reply()
{
  static const char name[] = "tm_sys_node_read_stats_reply";
  static const char name_with_crc[] = "tm_sys_node_read_stats_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_read_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_node_read_stats_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_read_stats_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_read_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_read_stats_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_read_stats_reply = vapi_register_msg(&__vapi_metadata_tm_sys_node_read_stats_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_read_stats_reply", vapi_msg_id_tm_sys_node_read_stats_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_node_read_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_node_read_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_node_read_stats_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_node_read_stats
#define __vapi_def_defined_vapi_msg_tm_sys_node_read_stats
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx;
  u32 node_id; 
} vapi_payload_tm_sys_node_read_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_node_read_stats payload;
} vapi_msg_tm_sys_node_read_stats;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_node_read_stats
#define __vapi_code_defined_vapi_msg_tm_sys_node_read_stats
static inline void vapi_msg_tm_sys_node_read_stats_payload_hton(vapi_payload_tm_sys_node_read_stats *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
  payload->node_id = htobe32(payload->node_id);
}

static inline void vapi_msg_tm_sys_node_read_stats_payload_ntoh(vapi_payload_tm_sys_node_read_stats *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
  payload->node_id = be32toh(payload->node_id);
}

static inline void vapi_msg_tm_sys_node_read_stats_hton(vapi_msg_tm_sys_node_read_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_read_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_node_read_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_node_read_stats_ntoh(vapi_msg_tm_sys_node_read_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_node_read_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_node_read_stats_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_node_read_stats_msg_size(vapi_msg_tm_sys_node_read_stats *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_node_read_stats_msg_size(vapi_msg_tm_sys_node_read_stats *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_node_read_stats) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_read_stats' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_node_read_stats));
      return -1;
    }
  if (vapi_calc_tm_sys_node_read_stats_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_node_read_stats' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_node_read_stats_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_node_read_stats* vapi_alloc_tm_sys_node_read_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_node_read_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_node_read_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_node_read_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_node_read_stats);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_node_read_stats(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_node_read_stats *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_node_read_stats_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_node_read_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_node_read_stats_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_node_read_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_node_read_stats()
{
  static const char name[] = "tm_sys_node_read_stats";
  static const char name_with_crc[] = "tm_sys_node_read_stats_a98a5d55";
  static vapi_message_desc_t __vapi_metadata_tm_sys_node_read_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_node_read_stats, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_node_read_stats_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_read_stats_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_node_read_stats_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_node_read_stats = vapi_register_msg(&__vapi_metadata_tm_sys_node_read_stats);
  VAPI_DBG("Assigned msg id %d to tm_sys_node_read_stats", vapi_msg_id_tm_sys_node_read_stats);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_start_tm_reply
#define __vapi_def_defined_vapi_msg_tm_sys_start_tm_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_start_tm_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_start_tm_reply payload;
} vapi_msg_tm_sys_start_tm_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_start_tm_reply
#define __vapi_code_defined_vapi_msg_tm_sys_start_tm_reply
static inline void vapi_msg_tm_sys_start_tm_reply_payload_hton(vapi_payload_tm_sys_start_tm_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_start_tm_reply_payload_ntoh(vapi_payload_tm_sys_start_tm_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_start_tm_reply_hton(vapi_msg_tm_sys_start_tm_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_start_tm_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_start_tm_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_start_tm_reply_ntoh(vapi_msg_tm_sys_start_tm_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_start_tm_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_start_tm_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_start_tm_reply_msg_size(vapi_msg_tm_sys_start_tm_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_start_tm_reply_msg_size(vapi_msg_tm_sys_start_tm_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_start_tm_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_start_tm_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_start_tm_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_start_tm_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_start_tm_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_start_tm_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_start_tm_reply()
{
  static const char name[] = "tm_sys_start_tm_reply";
  static const char name_with_crc[] = "tm_sys_start_tm_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_start_tm_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_start_tm_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_start_tm_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_start_tm_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_start_tm_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_start_tm_reply = vapi_register_msg(&__vapi_metadata_tm_sys_start_tm_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_start_tm_reply", vapi_msg_id_tm_sys_start_tm_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_start_tm_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_start_tm_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_start_tm_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_start_tm
#define __vapi_def_defined_vapi_msg_tm_sys_start_tm
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx; 
} vapi_payload_tm_sys_start_tm;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_start_tm payload;
} vapi_msg_tm_sys_start_tm;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_start_tm
#define __vapi_code_defined_vapi_msg_tm_sys_start_tm
static inline void vapi_msg_tm_sys_start_tm_payload_hton(vapi_payload_tm_sys_start_tm *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_start_tm_payload_ntoh(vapi_payload_tm_sys_start_tm *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_start_tm_hton(vapi_msg_tm_sys_start_tm *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_start_tm'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_start_tm_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_start_tm_ntoh(vapi_msg_tm_sys_start_tm *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_start_tm'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_start_tm_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_start_tm_msg_size(vapi_msg_tm_sys_start_tm *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_start_tm_msg_size(vapi_msg_tm_sys_start_tm *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_start_tm) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_start_tm' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_start_tm));
      return -1;
    }
  if (vapi_calc_tm_sys_start_tm_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_start_tm' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_start_tm_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_start_tm* vapi_alloc_tm_sys_start_tm(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_start_tm *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_start_tm);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_start_tm*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_start_tm);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_start_tm(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_start_tm *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_start_tm_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_start_tm_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_start_tm_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_start_tm_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_start_tm()
{
  static const char name[] = "tm_sys_start_tm";
  static const char name_with_crc[] = "tm_sys_start_tm_991d3cc9";
  static vapi_message_desc_t __vapi_metadata_tm_sys_start_tm = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_start_tm, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_start_tm_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_start_tm_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_start_tm_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_start_tm = vapi_register_msg(&__vapi_metadata_tm_sys_start_tm);
  VAPI_DBG("Assigned msg id %d to tm_sys_start_tm", vapi_msg_id_tm_sys_start_tm);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_stop_tm_reply
#define __vapi_def_defined_vapi_msg_tm_sys_stop_tm_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_tm_sys_stop_tm_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tm_sys_stop_tm_reply payload;
} vapi_msg_tm_sys_stop_tm_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_stop_tm_reply
#define __vapi_code_defined_vapi_msg_tm_sys_stop_tm_reply
static inline void vapi_msg_tm_sys_stop_tm_reply_payload_hton(vapi_payload_tm_sys_stop_tm_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_tm_sys_stop_tm_reply_payload_ntoh(vapi_payload_tm_sys_stop_tm_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_tm_sys_stop_tm_reply_hton(vapi_msg_tm_sys_stop_tm_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_stop_tm_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tm_sys_stop_tm_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_stop_tm_reply_ntoh(vapi_msg_tm_sys_stop_tm_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_stop_tm_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tm_sys_stop_tm_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_stop_tm_reply_msg_size(vapi_msg_tm_sys_stop_tm_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_stop_tm_reply_msg_size(vapi_msg_tm_sys_stop_tm_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_stop_tm_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_stop_tm_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_stop_tm_reply));
      return -1;
    }
  if (vapi_calc_tm_sys_stop_tm_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_stop_tm_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_stop_tm_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tm_sys_stop_tm_reply()
{
  static const char name[] = "tm_sys_stop_tm_reply";
  static const char name_with_crc[] = "tm_sys_stop_tm_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_tm_sys_stop_tm_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tm_sys_stop_tm_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_stop_tm_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_stop_tm_reply_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_stop_tm_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_stop_tm_reply = vapi_register_msg(&__vapi_metadata_tm_sys_stop_tm_reply);
  VAPI_DBG("Assigned msg id %d to tm_sys_stop_tm_reply", vapi_msg_id_tm_sys_stop_tm_reply);
}

static inline void vapi_set_vapi_msg_tm_sys_stop_tm_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tm_sys_stop_tm_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tm_sys_stop_tm_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tm_sys_stop_tm
#define __vapi_def_defined_vapi_msg_tm_sys_stop_tm
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_idx; 
} vapi_payload_tm_sys_stop_tm;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_tm_sys_stop_tm payload;
} vapi_msg_tm_sys_stop_tm;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tm_sys_stop_tm
#define __vapi_code_defined_vapi_msg_tm_sys_stop_tm
static inline void vapi_msg_tm_sys_stop_tm_payload_hton(vapi_payload_tm_sys_stop_tm *payload)
{
  payload->sw_if_idx = htobe32(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_stop_tm_payload_ntoh(vapi_payload_tm_sys_stop_tm *payload)
{
  payload->sw_if_idx = be32toh(payload->sw_if_idx);
}

static inline void vapi_msg_tm_sys_stop_tm_hton(vapi_msg_tm_sys_stop_tm *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_stop_tm'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_tm_sys_stop_tm_payload_hton(&msg->payload);
}

static inline void vapi_msg_tm_sys_stop_tm_ntoh(vapi_msg_tm_sys_stop_tm *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tm_sys_stop_tm'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_tm_sys_stop_tm_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tm_sys_stop_tm_msg_size(vapi_msg_tm_sys_stop_tm *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tm_sys_stop_tm_msg_size(vapi_msg_tm_sys_stop_tm *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tm_sys_stop_tm) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_stop_tm' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tm_sys_stop_tm));
      return -1;
    }
  if (vapi_calc_tm_sys_stop_tm_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tm_sys_stop_tm' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tm_sys_stop_tm_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tm_sys_stop_tm* vapi_alloc_tm_sys_stop_tm(struct vapi_ctx_s *ctx)
{
  vapi_msg_tm_sys_stop_tm *msg = NULL;
  const size_t size = sizeof(vapi_msg_tm_sys_stop_tm);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tm_sys_stop_tm*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tm_sys_stop_tm);

  return msg;
}

static inline vapi_error_e vapi_tm_sys_stop_tm(struct vapi_ctx_s *ctx,
  vapi_msg_tm_sys_stop_tm *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tm_sys_stop_tm_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tm_sys_stop_tm_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tm_sys_stop_tm_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tm_sys_stop_tm_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tm_sys_stop_tm()
{
  static const char name[] = "tm_sys_stop_tm";
  static const char name_with_crc[] = "tm_sys_stop_tm_991d3cc9";
  static vapi_message_desc_t __vapi_metadata_tm_sys_stop_tm = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_tm_sys_stop_tm, payload),
    (verify_msg_size_fn_t)vapi_verify_tm_sys_stop_tm_msg_size,
    (generic_swap_fn_t)vapi_msg_tm_sys_stop_tm_hton,
    (generic_swap_fn_t)vapi_msg_tm_sys_stop_tm_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tm_sys_stop_tm = vapi_register_msg(&__vapi_metadata_tm_sys_stop_tm);
  VAPI_DBG("Assigned msg id %d to tm_sys_stop_tm", vapi_msg_id_tm_sys_stop_tm);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

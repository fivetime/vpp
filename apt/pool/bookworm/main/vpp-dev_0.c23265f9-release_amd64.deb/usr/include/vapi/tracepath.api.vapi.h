#ifndef __included_tracepath_api_json
#define __included_tracepath_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_tracepath_dump;
extern vapi_msg_id_t vapi_msg_id_tracepath_details;

#define DEFINE_VAPI_MSG_IDS_TRACEPATH_API_JSON\
  vapi_msg_id_t vapi_msg_id_tracepath_dump;\
  vapi_msg_id_t vapi_msg_id_tracepath_details;


#ifndef __vapi_def_defined_vapi_type_trace_path_node
#define __vapi_def_defined_vapi_type_trace_path_node
typedef struct __attribute__((__packed__)) {
  u8 name[64];
} vapi_type_trace_path_node;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_trace_path_node
#define __vapi_code_defined_vapi_type_trace_path_node
static inline void vapi_type_trace_path_node_hton(vapi_type_trace_path_node *msg)
{

}

static inline void vapi_type_trace_path_node_ntoh(vapi_type_trace_path_node *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tracepath_details
#define __vapi_def_defined_vapi_msg_tracepath_details
typedef struct __attribute__ ((__packed__)) {
  u64 path_id;
  u32 n_pkts;
  u64 thread_bitmap;
  u32 n_nodes;
  vapi_type_trace_path_node nodes[0]; 
} vapi_payload_tracepath_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_tracepath_details payload;
} vapi_msg_tracepath_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tracepath_details
#define __vapi_code_defined_vapi_msg_tracepath_details
static inline void vapi_msg_tracepath_details_payload_hton(vapi_payload_tracepath_details *payload)
{
  payload->path_id = htobe64(payload->path_id);
  payload->n_pkts = htobe32(payload->n_pkts);
  payload->thread_bitmap = htobe64(payload->thread_bitmap);
  payload->n_nodes = htobe32(payload->n_nodes);
}

static inline void vapi_msg_tracepath_details_payload_ntoh(vapi_payload_tracepath_details *payload)
{
  payload->path_id = be64toh(payload->path_id);
  payload->n_pkts = be32toh(payload->n_pkts);
  payload->thread_bitmap = be64toh(payload->thread_bitmap);
  payload->n_nodes = be32toh(payload->n_nodes);
}

static inline void vapi_msg_tracepath_details_hton(vapi_msg_tracepath_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tracepath_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_tracepath_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_tracepath_details_ntoh(vapi_msg_tracepath_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tracepath_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_tracepath_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_tracepath_details_msg_size(vapi_msg_tracepath_details *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.nodes[0]) * msg->payload.n_nodes;
}

static inline int vapi_verify_tracepath_details_msg_size(vapi_msg_tracepath_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tracepath_details) > buf_size)
    {
      VAPI_ERR("Truncated 'tracepath_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tracepath_details));
      return -1;
    }
  if (vapi_calc_tracepath_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tracepath_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tracepath_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_tracepath_details()
{
  static const char name[] = "tracepath_details";
  static const char name_with_crc[] = "tracepath_details_7b836a96";
  static vapi_message_desc_t __vapi_metadata_tracepath_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_tracepath_details, payload),
    (verify_msg_size_fn_t)vapi_verify_tracepath_details_msg_size,
    (generic_swap_fn_t)vapi_msg_tracepath_details_hton,
    (generic_swap_fn_t)vapi_msg_tracepath_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tracepath_details = vapi_register_msg(&__vapi_metadata_tracepath_details);
  VAPI_DBG("Assigned msg id %d to tracepath_details", vapi_msg_id_tracepath_details);
}

static inline void vapi_set_vapi_msg_tracepath_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_tracepath_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_tracepath_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_tracepath_dump
#define __vapi_def_defined_vapi_msg_tracepath_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_tracepath_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_tracepath_dump
#define __vapi_code_defined_vapi_msg_tracepath_dump
static inline void vapi_msg_tracepath_dump_hton(vapi_msg_tracepath_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tracepath_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_tracepath_dump_ntoh(vapi_msg_tracepath_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_tracepath_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_tracepath_dump_msg_size(vapi_msg_tracepath_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_tracepath_dump_msg_size(vapi_msg_tracepath_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_tracepath_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'tracepath_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_tracepath_dump));
      return -1;
    }
  if (vapi_calc_tracepath_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'tracepath_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_tracepath_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_tracepath_dump* vapi_alloc_tracepath_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_tracepath_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_tracepath_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_tracepath_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_tracepath_dump);

  return msg;
}

static inline vapi_error_e vapi_tracepath_dump(struct vapi_ctx_s *ctx,
  vapi_msg_tracepath_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_tracepath_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_tracepath_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_tracepath_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_tracepath_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_tracepath_dump()
{
  static const char name[] = "tracepath_dump";
  static const char name_with_crc[] = "tracepath_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_tracepath_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_tracepath_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_tracepath_dump_hton,
    (generic_swap_fn_t)vapi_msg_tracepath_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_tracepath_dump = vapi_register_msg(&__vapi_metadata_tracepath_dump);
  VAPI_DBG("Assigned msg id %d to tracepath_dump", vapi_msg_id_tracepath_dump);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

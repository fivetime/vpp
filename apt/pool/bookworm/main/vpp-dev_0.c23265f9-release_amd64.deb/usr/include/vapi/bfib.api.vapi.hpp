#ifndef __included_hpp_bfib_api_json
#define __included_hpp_bfib_api_json

#include <vapi/vapi.hpp>
#include <vapi/bfib.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_bfib_plugin_get_version>(vapi_msg_bfib_plugin_get_version *msg)
{
  vapi_msg_bfib_plugin_get_version_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bfib_plugin_get_version>(vapi_msg_bfib_plugin_get_version *msg)
{
  vapi_msg_bfib_plugin_get_version_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bfib_plugin_get_version>()
{
  return ::vapi_msg_id_bfib_plugin_get_version; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bfib_plugin_get_version>>()
{
  return ::vapi_msg_id_bfib_plugin_get_version; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bfib_plugin_get_version()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bfib_plugin_get_version>(vapi_msg_id_bfib_plugin_get_version);
}

template <> inline vapi_msg_bfib_plugin_get_version* vapi_alloc<vapi_msg_bfib_plugin_get_version>(Connection &con)
{
  vapi_msg_bfib_plugin_get_version* result = vapi_alloc_bfib_plugin_get_version(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_bfib_plugin_get_version>;

template class Request<vapi_msg_bfib_plugin_get_version, vapi_msg_bfib_plugin_get_version_reply>;

using Bfib_plugin_get_version = Request<vapi_msg_bfib_plugin_get_version, vapi_msg_bfib_plugin_get_version_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_bfib_plugin_get_version_reply>(vapi_msg_bfib_plugin_get_version_reply *msg)
{
  vapi_msg_bfib_plugin_get_version_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bfib_plugin_get_version_reply>(vapi_msg_bfib_plugin_get_version_reply *msg)
{
  vapi_msg_bfib_plugin_get_version_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bfib_plugin_get_version_reply>()
{
  return ::vapi_msg_id_bfib_plugin_get_version_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bfib_plugin_get_version_reply>>()
{
  return ::vapi_msg_id_bfib_plugin_get_version_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bfib_plugin_get_version_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bfib_plugin_get_version_reply>(vapi_msg_id_bfib_plugin_get_version_reply);
}

template class Msg<vapi_msg_bfib_plugin_get_version_reply>;

using Bfib_plugin_get_version_reply = Msg<vapi_msg_bfib_plugin_get_version_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_bfib_route_batch>(vapi_msg_bfib_route_batch *msg)
{
  vapi_msg_bfib_route_batch_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bfib_route_batch>(vapi_msg_bfib_route_batch *msg)
{
  vapi_msg_bfib_route_batch_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bfib_route_batch>()
{
  return ::vapi_msg_id_bfib_route_batch; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bfib_route_batch>>()
{
  return ::vapi_msg_id_bfib_route_batch; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bfib_route_batch()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bfib_route_batch>(vapi_msg_id_bfib_route_batch);
}

template <> inline vapi_msg_bfib_route_batch* vapi_alloc<vapi_msg_bfib_route_batch, size_t>(Connection &con, size_t _items_array_size)
{
  vapi_msg_bfib_route_batch* result = vapi_alloc_bfib_route_batch(con.vapi_ctx, _items_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_bfib_route_batch>;

template class Request<vapi_msg_bfib_route_batch, vapi_msg_bfib_route_batch_reply, size_t>;

using Bfib_route_batch = Request<vapi_msg_bfib_route_batch, vapi_msg_bfib_route_batch_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_bfib_route_batch_reply>(vapi_msg_bfib_route_batch_reply *msg)
{
  vapi_msg_bfib_route_batch_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bfib_route_batch_reply>(vapi_msg_bfib_route_batch_reply *msg)
{
  vapi_msg_bfib_route_batch_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bfib_route_batch_reply>()
{
  return ::vapi_msg_id_bfib_route_batch_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bfib_route_batch_reply>>()
{
  return ::vapi_msg_id_bfib_route_batch_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bfib_route_batch_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bfib_route_batch_reply>(vapi_msg_id_bfib_route_batch_reply);
}

template class Msg<vapi_msg_bfib_route_batch_reply>;

using Bfib_route_batch_reply = Msg<vapi_msg_bfib_route_batch_reply>;
}
#endif

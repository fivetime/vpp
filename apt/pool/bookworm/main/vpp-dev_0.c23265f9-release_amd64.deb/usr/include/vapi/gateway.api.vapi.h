#ifndef __included_gateway_api_json
#define __included_gateway_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_sfdp_gateway_set_geneve_output;
extern vapi_msg_id_t vapi_msg_id_sfdp_gateway_set_geneve_output_reply;
extern vapi_msg_id_t vapi_msg_id_sfdp_gateway_geneve_input_enable_disable;
extern vapi_msg_id_t vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply;

#define DEFINE_VAPI_MSG_IDS_GATEWAY_API_JSON\
  vapi_msg_id_t vapi_msg_id_sfdp_gateway_set_geneve_output;\
  vapi_msg_id_t vapi_msg_id_sfdp_gateway_set_geneve_output_reply;\
  vapi_msg_id_t vapi_msg_id_sfdp_gateway_geneve_input_enable_disable;\
  vapi_msg_id_t vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_if_status_flags
#define __vapi_def_defined_vapi_enum_if_status_flags
typedef enum {
  IF_STATUS_API_FLAG_ADMIN_UP = 1,
  IF_STATUS_API_FLAG_LINK_UP = 2,
}  vapi_enum_if_status_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_if_status_flags
#define __vapi_code_defined_vapi_enum_if_status_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_mtu_proto
#define __vapi_def_defined_vapi_enum_mtu_proto
typedef enum {
  MTU_PROTO_API_L3 = 0,
  MTU_PROTO_API_IP4 = 1,
  MTU_PROTO_API_IP6 = 2,
  MTU_PROTO_API_MPLS = 3,
}  vapi_enum_mtu_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_mtu_proto
#define __vapi_code_defined_vapi_enum_mtu_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_link_duplex
#define __vapi_def_defined_vapi_enum_link_duplex
typedef enum {
  LINK_DUPLEX_API_UNKNOWN = 0,
  LINK_DUPLEX_API_HALF = 1,
  LINK_DUPLEX_API_FULL = 2,
}  vapi_enum_link_duplex;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_link_duplex
#define __vapi_code_defined_vapi_enum_link_duplex
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sub_if_flags
#define __vapi_def_defined_vapi_enum_sub_if_flags
typedef enum {
  SUB_IF_API_FLAG_NO_TAGS = 1,
  SUB_IF_API_FLAG_ONE_TAG = 2,
  SUB_IF_API_FLAG_TWO_TAGS = 4,
  SUB_IF_API_FLAG_DOT1AD = 8,
  SUB_IF_API_FLAG_EXACT_MATCH = 16,
  SUB_IF_API_FLAG_DEFAULT = 32,
  SUB_IF_API_FLAG_OUTER_VLAN_ID_ANY = 64,
  SUB_IF_API_FLAG_INNER_VLAN_ID_ANY = 128,
  SUB_IF_API_FLAG_MASK_VNET = 254,
  SUB_IF_API_FLAG_DOT1AH = 256,
}  vapi_enum_sub_if_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sub_if_flags
#define __vapi_code_defined_vapi_enum_sub_if_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_rx_mode
#define __vapi_def_defined_vapi_enum_rx_mode
typedef enum {
  RX_MODE_API_UNKNOWN = 0,
  RX_MODE_API_POLLING = 1,
  RX_MODE_API_INTERRUPT = 2,
  RX_MODE_API_ADAPTIVE = 3,
  RX_MODE_API_DEFAULT = 4,
}  vapi_enum_rx_mode;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_rx_mode
#define __vapi_code_defined_vapi_enum_rx_mode
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_if_type
#define __vapi_def_defined_vapi_enum_if_type
typedef enum {
  IF_API_TYPE_HARDWARE = 0,
  IF_API_TYPE_SUB = 1,
  IF_API_TYPE_P2P = 2,
  IF_API_TYPE_PIPE = 3,
}  vapi_enum_if_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_if_type
#define __vapi_code_defined_vapi_enum_if_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_direction
#define __vapi_def_defined_vapi_enum_direction
typedef enum {
  RX = 0,
  TX = 1,
} __attribute__((packed)) vapi_enum_direction;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_direction
#define __vapi_code_defined_vapi_enum_direction
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_direction
#define __vapi_def_defined_vapi_enum_sfdp_session_direction
typedef enum {
  SFDP_API_FORWARD = 0,
  SFDP_API_REVERSE = 1,
} __attribute__((packed)) vapi_enum_sfdp_session_direction;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_direction
#define __vapi_code_defined_vapi_enum_sfdp_session_direction
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mac_address
#define __vapi_def_defined_vapi_type_mac_address
typedef u8 vapi_type_mac_address[6];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mac_address
#define __vapi_code_defined_vapi_type_mac_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_interface_index
#define __vapi_def_defined_vapi_type_interface_index
typedef u32 vapi_type_interface_index;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_interface_index
#define __vapi_code_defined_vapi_type_interface_index
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_gateway_set_geneve_output_reply
#define __vapi_def_defined_vapi_msg_sfdp_gateway_set_geneve_output_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_gateway_set_geneve_output_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_gateway_set_geneve_output_reply payload;
} vapi_msg_sfdp_gateway_set_geneve_output_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_gateway_set_geneve_output_reply
#define __vapi_code_defined_vapi_msg_sfdp_gateway_set_geneve_output_reply
static inline void vapi_msg_sfdp_gateway_set_geneve_output_reply_payload_hton(vapi_payload_sfdp_gateway_set_geneve_output_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_reply_payload_ntoh(vapi_payload_sfdp_gateway_set_geneve_output_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_reply_hton(vapi_msg_sfdp_gateway_set_geneve_output_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_set_geneve_output_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_gateway_set_geneve_output_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_reply_ntoh(vapi_msg_sfdp_gateway_set_geneve_output_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_set_geneve_output_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_gateway_set_geneve_output_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_gateway_set_geneve_output_reply_msg_size(vapi_msg_sfdp_gateway_set_geneve_output_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_gateway_set_geneve_output_reply_msg_size(vapi_msg_sfdp_gateway_set_geneve_output_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_gateway_set_geneve_output_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_set_geneve_output_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_gateway_set_geneve_output_reply));
      return -1;
    }
  if (vapi_calc_sfdp_gateway_set_geneve_output_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_set_geneve_output_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_gateway_set_geneve_output_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_gateway_set_geneve_output_reply()
{
  static const char name[] = "sfdp_gateway_set_geneve_output_reply";
  static const char name_with_crc[] = "sfdp_gateway_set_geneve_output_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_gateway_set_geneve_output_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_gateway_set_geneve_output_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_gateway_set_geneve_output_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_set_geneve_output_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_set_geneve_output_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_gateway_set_geneve_output_reply = vapi_register_msg(&__vapi_metadata_sfdp_gateway_set_geneve_output_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_gateway_set_geneve_output_reply", vapi_msg_id_sfdp_gateway_set_geneve_output_reply);
}

static inline void vapi_set_vapi_msg_sfdp_gateway_set_geneve_output_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_gateway_set_geneve_output_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_gateway_set_geneve_output_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_gateway_set_geneve_output
#define __vapi_def_defined_vapi_msg_sfdp_gateway_set_geneve_output
typedef struct __attribute__ ((__packed__)) {
  u32 tenant_id;
  u32 output_tenant_id;
  vapi_type_address src;
  vapi_type_address dst;
  u16 src_port;
  u16 dst_port;
  u8 static_mac;
  vapi_type_mac_address src_mac;
  vapi_type_mac_address dst_mac;
  vapi_enum_sfdp_session_direction dir; 
} vapi_payload_sfdp_gateway_set_geneve_output;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_gateway_set_geneve_output payload;
} vapi_msg_sfdp_gateway_set_geneve_output;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_gateway_set_geneve_output
#define __vapi_code_defined_vapi_msg_sfdp_gateway_set_geneve_output
static inline void vapi_msg_sfdp_gateway_set_geneve_output_payload_hton(vapi_payload_sfdp_gateway_set_geneve_output *payload)
{
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->output_tenant_id = htobe32(payload->output_tenant_id);
  payload->src_port = htobe16(payload->src_port);
  payload->dst_port = htobe16(payload->dst_port);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_payload_ntoh(vapi_payload_sfdp_gateway_set_geneve_output *payload)
{
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->output_tenant_id = be32toh(payload->output_tenant_id);
  payload->src_port = be16toh(payload->src_port);
  payload->dst_port = be16toh(payload->dst_port);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_hton(vapi_msg_sfdp_gateway_set_geneve_output *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_set_geneve_output'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_gateway_set_geneve_output_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_gateway_set_geneve_output_ntoh(vapi_msg_sfdp_gateway_set_geneve_output *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_set_geneve_output'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_gateway_set_geneve_output_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_gateway_set_geneve_output_msg_size(vapi_msg_sfdp_gateway_set_geneve_output *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_gateway_set_geneve_output_msg_size(vapi_msg_sfdp_gateway_set_geneve_output *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_gateway_set_geneve_output) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_set_geneve_output' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_gateway_set_geneve_output));
      return -1;
    }
  if (vapi_calc_sfdp_gateway_set_geneve_output_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_set_geneve_output' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_gateway_set_geneve_output_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_gateway_set_geneve_output* vapi_alloc_sfdp_gateway_set_geneve_output(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_gateway_set_geneve_output *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_gateway_set_geneve_output);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_gateway_set_geneve_output*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_gateway_set_geneve_output);

  return msg;
}

static inline vapi_error_e vapi_sfdp_gateway_set_geneve_output(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_gateway_set_geneve_output *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_gateway_set_geneve_output_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_gateway_set_geneve_output_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_gateway_set_geneve_output_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_gateway_set_geneve_output_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_gateway_set_geneve_output()
{
  static const char name[] = "sfdp_gateway_set_geneve_output";
  static const char name_with_crc[] = "sfdp_gateway_set_geneve_output_508e3ee7";
  static vapi_message_desc_t __vapi_metadata_sfdp_gateway_set_geneve_output = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_gateway_set_geneve_output, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_gateway_set_geneve_output_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_set_geneve_output_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_set_geneve_output_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_gateway_set_geneve_output = vapi_register_msg(&__vapi_metadata_sfdp_gateway_set_geneve_output);
  VAPI_DBG("Assigned msg id %d to sfdp_gateway_set_geneve_output", vapi_msg_id_sfdp_gateway_set_geneve_output);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply
#define __vapi_def_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply payload;
} vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply
#define __vapi_code_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply
static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_payload_hton(vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_payload_ntoh(vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_hton(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_ntoh(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_gateway_geneve_input_enable_disable_reply_msg_size(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_gateway_geneve_input_enable_disable_reply_msg_size(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_geneve_input_enable_disable_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply));
      return -1;
    }
  if (vapi_calc_sfdp_gateway_geneve_input_enable_disable_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_geneve_input_enable_disable_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_gateway_geneve_input_enable_disable_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_gateway_geneve_input_enable_disable_reply()
{
  static const char name[] = "sfdp_gateway_geneve_input_enable_disable_reply";
  static const char name_with_crc[] = "sfdp_gateway_geneve_input_enable_disable_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_sfdp_gateway_geneve_input_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_gateway_geneve_input_enable_disable_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply = vapi_register_msg(&__vapi_metadata_sfdp_gateway_geneve_input_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to sfdp_gateway_geneve_input_enable_disable_reply", vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply);
}

static inline void vapi_set_vapi_msg_sfdp_gateway_geneve_input_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable
#define __vapi_def_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable
typedef struct __attribute__ ((__packed__)) {
  vapi_type_interface_index sw_if_index;
  u8 is_enable; 
} vapi_payload_sfdp_gateway_geneve_input_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sfdp_gateway_geneve_input_enable_disable payload;
} vapi_msg_sfdp_gateway_geneve_input_enable_disable;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable
#define __vapi_code_defined_vapi_msg_sfdp_gateway_geneve_input_enable_disable
static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_payload_hton(vapi_payload_sfdp_gateway_geneve_input_enable_disable *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_payload_ntoh(vapi_payload_sfdp_gateway_geneve_input_enable_disable *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_hton(vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_geneve_input_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sfdp_gateway_geneve_input_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_gateway_geneve_input_enable_disable_ntoh(vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_gateway_geneve_input_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sfdp_gateway_geneve_input_enable_disable_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_gateway_geneve_input_enable_disable_msg_size(vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_gateway_geneve_input_enable_disable_msg_size(vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_gateway_geneve_input_enable_disable) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_geneve_input_enable_disable' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_gateway_geneve_input_enable_disable));
      return -1;
    }
  if (vapi_calc_sfdp_gateway_geneve_input_enable_disable_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_gateway_geneve_input_enable_disable' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_gateway_geneve_input_enable_disable_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_gateway_geneve_input_enable_disable* vapi_alloc_sfdp_gateway_geneve_input_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_gateway_geneve_input_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_gateway_geneve_input_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_gateway_geneve_input_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_sfdp_gateway_geneve_input_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_gateway_geneve_input_enable_disable *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_gateway_geneve_input_enable_disable_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_gateway_geneve_input_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_gateway_geneve_input_enable_disable_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_gateway_geneve_input_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_gateway_geneve_input_enable_disable()
{
  static const char name[] = "sfdp_gateway_geneve_input_enable_disable";
  static const char name_with_crc[] = "sfdp_gateway_geneve_input_enable_disable_3b2a8583";
  static vapi_message_desc_t __vapi_metadata_sfdp_gateway_geneve_input_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sfdp_gateway_geneve_input_enable_disable, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_gateway_geneve_input_enable_disable_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_geneve_input_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_gateway_geneve_input_enable_disable_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_gateway_geneve_input_enable_disable = vapi_register_msg(&__vapi_metadata_sfdp_gateway_geneve_input_enable_disable);
  VAPI_DBG("Assigned msg id %d to sfdp_gateway_geneve_input_enable_disable", vapi_msg_id_sfdp_gateway_geneve_input_enable_disable);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

#ifndef __included_npol_api_json
#define __included_npol_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_npol_get_version;
extern vapi_msg_id_t vapi_msg_id_npol_get_version_reply;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_create;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_create_reply;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_add_del_members;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_add_del_members_reply;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_delete;
extern vapi_msg_id_t vapi_msg_id_npol_ipset_delete_reply;
extern vapi_msg_id_t vapi_msg_id_npol_rule_create;
extern vapi_msg_id_t vapi_msg_id_npol_rule_update;
extern vapi_msg_id_t vapi_msg_id_npol_rule_update_reply;
extern vapi_msg_id_t vapi_msg_id_npol_rule_create_reply;
extern vapi_msg_id_t vapi_msg_id_npol_rule_delete;
extern vapi_msg_id_t vapi_msg_id_npol_rule_delete_reply;
extern vapi_msg_id_t vapi_msg_id_npol_policy_create;
extern vapi_msg_id_t vapi_msg_id_npol_policy_create_reply;
extern vapi_msg_id_t vapi_msg_id_npol_policy_update;
extern vapi_msg_id_t vapi_msg_id_npol_policy_update_reply;
extern vapi_msg_id_t vapi_msg_id_npol_policy_delete;
extern vapi_msg_id_t vapi_msg_id_npol_policy_delete_reply;
extern vapi_msg_id_t vapi_msg_id_npol_configure_policies;
extern vapi_msg_id_t vapi_msg_id_npol_configure_policies_reply;

#define DEFINE_VAPI_MSG_IDS_NPOL_API_JSON\
  vapi_msg_id_t vapi_msg_id_npol_get_version;\
  vapi_msg_id_t vapi_msg_id_npol_get_version_reply;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_create;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_create_reply;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_add_del_members;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_add_del_members_reply;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_delete;\
  vapi_msg_id_t vapi_msg_id_npol_ipset_delete_reply;\
  vapi_msg_id_t vapi_msg_id_npol_rule_create;\
  vapi_msg_id_t vapi_msg_id_npol_rule_update;\
  vapi_msg_id_t vapi_msg_id_npol_rule_update_reply;\
  vapi_msg_id_t vapi_msg_id_npol_rule_create_reply;\
  vapi_msg_id_t vapi_msg_id_npol_rule_delete;\
  vapi_msg_id_t vapi_msg_id_npol_rule_delete_reply;\
  vapi_msg_id_t vapi_msg_id_npol_policy_create;\
  vapi_msg_id_t vapi_msg_id_npol_policy_create_reply;\
  vapi_msg_id_t vapi_msg_id_npol_policy_update;\
  vapi_msg_id_t vapi_msg_id_npol_policy_update_reply;\
  vapi_msg_id_t vapi_msg_id_npol_policy_delete;\
  vapi_msg_id_t vapi_msg_id_npol_policy_delete_reply;\
  vapi_msg_id_t vapi_msg_id_npol_configure_policies;\
  vapi_msg_id_t vapi_msg_id_npol_configure_policies_reply;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_nh_proto
#define __vapi_def_defined_vapi_enum_fib_path_nh_proto
typedef enum {
  FIB_API_PATH_NH_PROTO_IP4 = 0,
  FIB_API_PATH_NH_PROTO_IP6 = 1,
  FIB_API_PATH_NH_PROTO_MPLS = 2,
  FIB_API_PATH_NH_PROTO_ETHERNET = 3,
  FIB_API_PATH_NH_PROTO_BIER = 4,
}  vapi_enum_fib_path_nh_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_nh_proto
#define __vapi_code_defined_vapi_enum_fib_path_nh_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_flags
#define __vapi_def_defined_vapi_enum_fib_path_flags
typedef enum {
  FIB_API_PATH_FLAG_NONE = 0,
  FIB_API_PATH_FLAG_RESOLVE_VIA_ATTACHED = 1,
  FIB_API_PATH_FLAG_RESOLVE_VIA_HOST = 2,
  FIB_API_PATH_FLAG_POP_PW_CW = 4,
}  vapi_enum_fib_path_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_flags
#define __vapi_code_defined_vapi_enum_fib_path_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_type
#define __vapi_def_defined_vapi_enum_fib_path_type
typedef enum {
  FIB_API_PATH_TYPE_NORMAL = 0,
  FIB_API_PATH_TYPE_LOCAL = 1,
  FIB_API_PATH_TYPE_DROP = 2,
  FIB_API_PATH_TYPE_UDP_ENCAP = 3,
  FIB_API_PATH_TYPE_BIER_IMP = 4,
  FIB_API_PATH_TYPE_ICMP_UNREACH = 5,
  FIB_API_PATH_TYPE_ICMP_PROHIBIT = 6,
  FIB_API_PATH_TYPE_SOURCE_LOOKUP = 7,
  FIB_API_PATH_TYPE_DVR = 8,
  FIB_API_PATH_TYPE_INTERFACE_RX = 9,
  FIB_API_PATH_TYPE_CLASSIFY = 10,
}  vapi_enum_fib_path_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_type
#define __vapi_code_defined_vapi_enum_fib_path_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_npol_ipset_type
#define __vapi_def_defined_vapi_enum_npol_ipset_type
typedef enum {
  NPOL_IP = 0,
  NPOL_IP_AND_PORT = 1,
  NPOL_NET = 2,
} __attribute__((packed)) vapi_enum_npol_ipset_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_npol_ipset_type
#define __vapi_code_defined_vapi_enum_npol_ipset_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_npol_rule_action
#define __vapi_def_defined_vapi_enum_npol_rule_action
typedef enum {
  NPOL_ALLOW = 0,
  NPOL_DENY = 1,
  NPOL_LOG = 2,
  NPOL_PASS = 3,
} __attribute__((packed)) vapi_enum_npol_rule_action;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_npol_rule_action
#define __vapi_code_defined_vapi_enum_npol_rule_action
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_npol_entry_type
#define __vapi_def_defined_vapi_enum_npol_entry_type
typedef enum {
  NPOL_CIDR = 0,
  NPOL_PORT_RANGE = 1,
  NPOL_PORT_IP_SET = 2,
  NPOL_IP_SET = 3,
} __attribute__((packed)) vapi_enum_npol_entry_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_npol_entry_type
#define __vapi_code_defined_vapi_enum_npol_entry_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_npol_policy_default
#define __vapi_def_defined_vapi_enum_npol_policy_default
typedef enum {
  NPOL_DEFAULT_ALLOW = 0,
  NPOL_DEFAULT_DENY = 1,
  NPOL_DEFAULT_PASS = 2,
} __attribute__((packed)) vapi_enum_npol_policy_default;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_npol_policy_default
#define __vapi_code_defined_vapi_enum_npol_policy_default
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_npol_rule_filter_type
#define __vapi_def_defined_vapi_enum_npol_rule_filter_type
typedef enum {
  NPOL_RULE_FILTER_NONE_TYPE = 0,
  NPOL_RULE_FILTER_ICMP_TYPE = 1,
  NPOL_RULE_FILTER_ICMP_CODE = 2,
  NPOL_RULE_FILTER_L4_PROTO = 3,
} __attribute__((packed)) vapi_enum_npol_rule_filter_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_npol_rule_filter_type
#define __vapi_code_defined_vapi_enum_npol_rule_filter_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_three_tuple
#define __vapi_def_defined_vapi_type_npol_three_tuple
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 l4_proto;
  u16 port;
} vapi_type_npol_three_tuple;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_three_tuple
#define __vapi_code_defined_vapi_type_npol_three_tuple
static inline void vapi_type_npol_three_tuple_hton(vapi_type_npol_three_tuple *msg)
{
  msg->port = htobe16(msg->port);
}

static inline void vapi_type_npol_three_tuple_ntoh(vapi_type_npol_three_tuple *msg)
{
  msg->port = be16toh(msg->port);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_npol_ipset_member_val
#define __vapi_def_defined_vapi_union_npol_ipset_member_val
typedef union {
  vapi_type_address address;
  vapi_type_prefix prefix;
  vapi_type_npol_three_tuple tuple;
} vapi_union_npol_ipset_member_val;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_npol_ipset_member_val
#define __vapi_code_defined_vapi_union_npol_ipset_member_val
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_port_range
#define __vapi_def_defined_vapi_type_npol_port_range
typedef struct __attribute__((__packed__)) {
  u16 start;
  u16 end;
} vapi_type_npol_port_range;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_port_range
#define __vapi_code_defined_vapi_type_npol_port_range
static inline void vapi_type_npol_port_range_hton(vapi_type_npol_port_range *msg)
{
  msg->start = htobe16(msg->start);
  msg->end = htobe16(msg->end);
}

static inline void vapi_type_npol_port_range_ntoh(vapi_type_npol_port_range *msg)
{
  msg->start = be16toh(msg->start);
  msg->end = be16toh(msg->end);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_entry_set_id
#define __vapi_def_defined_vapi_type_npol_entry_set_id
typedef struct __attribute__((__packed__)) {
  u32 set_id;
} vapi_type_npol_entry_set_id;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_entry_set_id
#define __vapi_code_defined_vapi_type_npol_entry_set_id
static inline void vapi_type_npol_entry_set_id_hton(vapi_type_npol_entry_set_id *msg)
{
  msg->set_id = htobe32(msg->set_id);
}

static inline void vapi_type_npol_entry_set_id_ntoh(vapi_type_npol_entry_set_id *msg)
{
  msg->set_id = be32toh(msg->set_id);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_npol_entry_data
#define __vapi_def_defined_vapi_union_npol_entry_data
typedef union {
  vapi_type_prefix cidr;
  vapi_type_npol_port_range port_range;
  vapi_type_npol_entry_set_id set_id;
} vapi_union_npol_entry_data;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_npol_entry_data
#define __vapi_code_defined_vapi_union_npol_entry_data
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_mpls_label
#define __vapi_def_defined_vapi_type_fib_mpls_label
typedef struct __attribute__((__packed__)) {
  u8 is_uniform;
  u32 label;
  u8 ttl;
  u8 exp;
} vapi_type_fib_mpls_label;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_mpls_label
#define __vapi_code_defined_vapi_type_fib_mpls_label
static inline void vapi_type_fib_mpls_label_hton(vapi_type_fib_mpls_label *msg)
{
  msg->label = htobe32(msg->label);
}

static inline void vapi_type_fib_mpls_label_ntoh(vapi_type_fib_mpls_label *msg)
{
  msg->label = be32toh(msg->label);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_rule_filter
#define __vapi_def_defined_vapi_type_npol_rule_filter
typedef struct __attribute__((__packed__)) {
  u32 value;
  vapi_enum_npol_rule_filter_type type;
  u8 should_match;
} vapi_type_npol_rule_filter;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_rule_filter
#define __vapi_code_defined_vapi_type_npol_rule_filter
static inline void vapi_type_npol_rule_filter_hton(vapi_type_npol_rule_filter *msg)
{
  msg->value = htobe32(msg->value);
}

static inline void vapi_type_npol_rule_filter_ntoh(vapi_type_npol_rule_filter *msg)
{
  msg->value = be32toh(msg->value);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_policy_item
#define __vapi_def_defined_vapi_type_npol_policy_item
typedef struct __attribute__((__packed__)) {
  bool is_inbound;
  u32 rule_id;
} vapi_type_npol_policy_item;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_policy_item
#define __vapi_code_defined_vapi_type_npol_policy_item
static inline void vapi_type_npol_policy_item_hton(vapi_type_npol_policy_item *msg)
{
  msg->rule_id = htobe32(msg->rule_id);
}

static inline void vapi_type_npol_policy_item_ntoh(vapi_type_npol_policy_item *msg)
{
  msg->rule_id = be32toh(msg->rule_id);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_path_nh
#define __vapi_def_defined_vapi_type_fib_path_nh
typedef struct __attribute__((__packed__)) {
  vapi_union_address_union address;
  u32 via_label;
  u32 obj_id;
  u32 classify_table_index;
} vapi_type_fib_path_nh;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_path_nh
#define __vapi_code_defined_vapi_type_fib_path_nh
static inline void vapi_type_fib_path_nh_hton(vapi_type_fib_path_nh *msg)
{
  msg->via_label = htobe32(msg->via_label);
  msg->obj_id = htobe32(msg->obj_id);
  msg->classify_table_index = htobe32(msg->classify_table_index);
}

static inline void vapi_type_fib_path_nh_ntoh(vapi_type_fib_path_nh *msg)
{
  msg->via_label = be32toh(msg->via_label);
  msg->obj_id = be32toh(msg->obj_id);
  msg->classify_table_index = be32toh(msg->classify_table_index);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_path
#define __vapi_def_defined_vapi_type_fib_path
typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u32 table_id;
  u32 rpf_id;
  u8 weight;
  u8 preference;
  vapi_enum_fib_path_type type;
  vapi_enum_fib_path_flags flags;
  vapi_enum_fib_path_nh_proto proto;
  vapi_type_fib_path_nh nh;
  u8 n_labels;
  vapi_type_fib_mpls_label label_stack[16];
} vapi_type_fib_path;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_path
#define __vapi_code_defined_vapi_type_fib_path
static inline void vapi_type_fib_path_hton(vapi_type_fib_path *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
  msg->table_id = htobe32(msg->table_id);
  msg->rpf_id = htobe32(msg->rpf_id);
  msg->type = (vapi_enum_fib_path_type)htobe32(msg->type);
  msg->flags = (vapi_enum_fib_path_flags)htobe32(msg->flags);
  msg->proto = (vapi_enum_fib_path_nh_proto)htobe32(msg->proto);
  vapi_type_fib_path_nh_hton(&msg->nh);
  do { unsigned i; for (i = 0; i < 16; ++i) { vapi_type_fib_mpls_label_hton(&msg->label_stack[i]); } } while(0);
}

static inline void vapi_type_fib_path_ntoh(vapi_type_fib_path *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
  msg->table_id = be32toh(msg->table_id);
  msg->rpf_id = be32toh(msg->rpf_id);
  msg->type = (vapi_enum_fib_path_type)be32toh(msg->type);
  msg->flags = (vapi_enum_fib_path_flags)be32toh(msg->flags);
  msg->proto = (vapi_enum_fib_path_nh_proto)be32toh(msg->proto);
  vapi_type_fib_path_nh_ntoh(&msg->nh);
  do { unsigned i; for (i = 0; i < 16; ++i) { vapi_type_fib_mpls_label_ntoh(&msg->label_stack[i]); } } while(0);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_ipset_member
#define __vapi_def_defined_vapi_type_npol_ipset_member
typedef struct __attribute__((__packed__)) {
  vapi_union_npol_ipset_member_val val;
} vapi_type_npol_ipset_member;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_ipset_member
#define __vapi_code_defined_vapi_type_npol_ipset_member
static inline void vapi_type_npol_ipset_member_hton(vapi_type_npol_ipset_member *msg)
{

}

static inline void vapi_type_npol_ipset_member_ntoh(vapi_type_npol_ipset_member *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_rule_entry
#define __vapi_def_defined_vapi_type_npol_rule_entry
typedef struct __attribute__((__packed__)) {
  bool is_src;
  bool is_not;
  vapi_enum_npol_entry_type type;
  vapi_union_npol_entry_data data;
} vapi_type_npol_rule_entry;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_rule_entry
#define __vapi_code_defined_vapi_type_npol_rule_entry
static inline void vapi_type_npol_rule_entry_hton(vapi_type_npol_rule_entry *msg)
{

}

static inline void vapi_type_npol_rule_entry_ntoh(vapi_type_npol_rule_entry *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_npol_rule
#define __vapi_def_defined_vapi_type_npol_rule
typedef struct __attribute__((__packed__)) {
  vapi_enum_npol_rule_action action;
  vapi_type_npol_rule_filter filters[3];
  u32 num_entries;
  vapi_type_npol_rule_entry matches[0];
} vapi_type_npol_rule;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_npol_rule
#define __vapi_code_defined_vapi_type_npol_rule
static inline void vapi_type_npol_rule_hton(vapi_type_npol_rule *msg)
{
  do { unsigned i; for (i = 0; i < 3; ++i) { vapi_type_npol_rule_filter_hton(&msg->filters[i]); } } while(0);
  msg->num_entries = htobe32(msg->num_entries);
}

static inline void vapi_type_npol_rule_ntoh(vapi_type_npol_rule *msg)
{
  do { unsigned i; for (i = 0; i < 3; ++i) { vapi_type_npol_rule_filter_ntoh(&msg->filters[i]); } } while(0);
  msg->num_entries = be32toh(msg->num_entries);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_get_version_reply
#define __vapi_def_defined_vapi_msg_npol_get_version_reply
typedef struct __attribute__ ((__packed__)) {
  u32 major;
  u32 minor; 
} vapi_payload_npol_get_version_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_get_version_reply payload;
} vapi_msg_npol_get_version_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_get_version_reply
#define __vapi_code_defined_vapi_msg_npol_get_version_reply
static inline void vapi_msg_npol_get_version_reply_payload_hton(vapi_payload_npol_get_version_reply *payload)
{
  payload->major = htobe32(payload->major);
  payload->minor = htobe32(payload->minor);
}

static inline void vapi_msg_npol_get_version_reply_payload_ntoh(vapi_payload_npol_get_version_reply *payload)
{
  payload->major = be32toh(payload->major);
  payload->minor = be32toh(payload->minor);
}

static inline void vapi_msg_npol_get_version_reply_hton(vapi_msg_npol_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_get_version_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_get_version_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_get_version_reply_ntoh(vapi_msg_npol_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_get_version_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_get_version_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_get_version_reply_msg_size(vapi_msg_npol_get_version_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_get_version_reply_msg_size(vapi_msg_npol_get_version_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_get_version_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_get_version_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_get_version_reply));
      return -1;
    }
  if (vapi_calc_npol_get_version_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_get_version_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_get_version_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_get_version_reply()
{
  static const char name[] = "npol_get_version_reply";
  static const char name_with_crc[] = "npol_get_version_reply_9b32cf86";
  static vapi_message_desc_t __vapi_metadata_npol_get_version_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_get_version_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_get_version_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_get_version_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_get_version_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_get_version_reply = vapi_register_msg(&__vapi_metadata_npol_get_version_reply);
  VAPI_DBG("Assigned msg id %d to npol_get_version_reply", vapi_msg_id_npol_get_version_reply);
}

static inline void vapi_set_vapi_msg_npol_get_version_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_get_version_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_get_version_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_get_version
#define __vapi_def_defined_vapi_msg_npol_get_version
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_npol_get_version;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_get_version
#define __vapi_code_defined_vapi_msg_npol_get_version
static inline void vapi_msg_npol_get_version_hton(vapi_msg_npol_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_get_version'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_npol_get_version_ntoh(vapi_msg_npol_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_get_version'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_npol_get_version_msg_size(vapi_msg_npol_get_version *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_get_version_msg_size(vapi_msg_npol_get_version *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_get_version) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_get_version' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_get_version));
      return -1;
    }
  if (vapi_calc_npol_get_version_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_get_version' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_get_version_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_get_version* vapi_alloc_npol_get_version(struct vapi_ctx_s *ctx)
{
  vapi_msg_npol_get_version *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_get_version);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_get_version*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_get_version);

  return msg;
}

static inline vapi_error_e vapi_npol_get_version(struct vapi_ctx_s *ctx,
  vapi_msg_npol_get_version *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_get_version_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_get_version_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_get_version_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_get_version_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_get_version()
{
  static const char name[] = "npol_get_version";
  static const char name_with_crc[] = "npol_get_version_51077d14";
  static vapi_message_desc_t __vapi_metadata_npol_get_version = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_npol_get_version_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_get_version_hton,
    (generic_swap_fn_t)vapi_msg_npol_get_version_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_get_version = vapi_register_msg(&__vapi_metadata_npol_get_version);
  VAPI_DBG("Assigned msg id %d to npol_get_version", vapi_msg_id_npol_get_version);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_create_reply
#define __vapi_def_defined_vapi_msg_npol_ipset_create_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 set_id; 
} vapi_payload_npol_ipset_create_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_ipset_create_reply payload;
} vapi_msg_npol_ipset_create_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_create_reply
#define __vapi_code_defined_vapi_msg_npol_ipset_create_reply
static inline void vapi_msg_npol_ipset_create_reply_payload_hton(vapi_payload_npol_ipset_create_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->set_id = htobe32(payload->set_id);
}

static inline void vapi_msg_npol_ipset_create_reply_payload_ntoh(vapi_payload_npol_ipset_create_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->set_id = be32toh(payload->set_id);
}

static inline void vapi_msg_npol_ipset_create_reply_hton(vapi_msg_npol_ipset_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_create_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_ipset_create_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_create_reply_ntoh(vapi_msg_npol_ipset_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_create_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_create_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_create_reply_msg_size(vapi_msg_npol_ipset_create_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_ipset_create_reply_msg_size(vapi_msg_npol_ipset_create_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_create_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_create_reply));
      return -1;
    }
  if (vapi_calc_npol_ipset_create_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_create_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_ipset_create_reply()
{
  static const char name[] = "npol_ipset_create_reply";
  static const char name_with_crc[] = "npol_ipset_create_reply_6a43f193";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_create_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_ipset_create_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_create_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_create_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_create_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_create_reply = vapi_register_msg(&__vapi_metadata_npol_ipset_create_reply);
  VAPI_DBG("Assigned msg id %d to npol_ipset_create_reply", vapi_msg_id_npol_ipset_create_reply);
}

static inline void vapi_set_vapi_msg_npol_ipset_create_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_ipset_create_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_ipset_create_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_create
#define __vapi_def_defined_vapi_msg_npol_ipset_create
typedef struct __attribute__ ((__packed__)) {
  vapi_enum_npol_ipset_type type; 
} vapi_payload_npol_ipset_create;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_ipset_create payload;
} vapi_msg_npol_ipset_create;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_create
#define __vapi_code_defined_vapi_msg_npol_ipset_create
static inline void vapi_msg_npol_ipset_create_payload_hton(vapi_payload_npol_ipset_create *payload)
{

}

static inline void vapi_msg_npol_ipset_create_payload_ntoh(vapi_payload_npol_ipset_create *payload)
{

}

static inline void vapi_msg_npol_ipset_create_hton(vapi_msg_npol_ipset_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_create'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_ipset_create_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_create_ntoh(vapi_msg_npol_ipset_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_create'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_create_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_create_msg_size(vapi_msg_npol_ipset_create *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_ipset_create_msg_size(vapi_msg_npol_ipset_create *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_create) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_create));
      return -1;
    }
  if (vapi_calc_npol_ipset_create_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_create_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_ipset_create* vapi_alloc_npol_ipset_create(struct vapi_ctx_s *ctx)
{
  vapi_msg_npol_ipset_create *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_ipset_create);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_ipset_create*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_ipset_create);

  return msg;
}

static inline vapi_error_e vapi_npol_ipset_create(struct vapi_ctx_s *ctx,
  vapi_msg_npol_ipset_create *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_ipset_create_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_ipset_create_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_ipset_create_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_ipset_create_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_ipset_create()
{
  static const char name[] = "npol_ipset_create";
  static const char name_with_crc[] = "npol_ipset_create_f948b404";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_create = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_ipset_create, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_create_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_create_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_create_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_create = vapi_register_msg(&__vapi_metadata_npol_ipset_create);
  VAPI_DBG("Assigned msg id %d to npol_ipset_create", vapi_msg_id_npol_ipset_create);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_add_del_members_reply
#define __vapi_def_defined_vapi_msg_npol_ipset_add_del_members_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_ipset_add_del_members_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_ipset_add_del_members_reply payload;
} vapi_msg_npol_ipset_add_del_members_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_add_del_members_reply
#define __vapi_code_defined_vapi_msg_npol_ipset_add_del_members_reply
static inline void vapi_msg_npol_ipset_add_del_members_reply_payload_hton(vapi_payload_npol_ipset_add_del_members_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_ipset_add_del_members_reply_payload_ntoh(vapi_payload_npol_ipset_add_del_members_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_ipset_add_del_members_reply_hton(vapi_msg_npol_ipset_add_del_members_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_add_del_members_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_ipset_add_del_members_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_add_del_members_reply_ntoh(vapi_msg_npol_ipset_add_del_members_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_add_del_members_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_add_del_members_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_add_del_members_reply_msg_size(vapi_msg_npol_ipset_add_del_members_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_ipset_add_del_members_reply_msg_size(vapi_msg_npol_ipset_add_del_members_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_add_del_members_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_add_del_members_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_add_del_members_reply));
      return -1;
    }
  if (vapi_calc_npol_ipset_add_del_members_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_add_del_members_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_add_del_members_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_ipset_add_del_members_reply()
{
  static const char name[] = "npol_ipset_add_del_members_reply";
  static const char name_with_crc[] = "npol_ipset_add_del_members_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_add_del_members_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_ipset_add_del_members_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_add_del_members_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_add_del_members_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_add_del_members_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_add_del_members_reply = vapi_register_msg(&__vapi_metadata_npol_ipset_add_del_members_reply);
  VAPI_DBG("Assigned msg id %d to npol_ipset_add_del_members_reply", vapi_msg_id_npol_ipset_add_del_members_reply);
}

static inline void vapi_set_vapi_msg_npol_ipset_add_del_members_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_ipset_add_del_members_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_ipset_add_del_members_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_add_del_members
#define __vapi_def_defined_vapi_msg_npol_ipset_add_del_members
typedef struct __attribute__ ((__packed__)) {
  u32 set_id;
  bool is_add;
  u32 len;
  vapi_type_npol_ipset_member members[0]; 
} vapi_payload_npol_ipset_add_del_members;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_ipset_add_del_members payload;
} vapi_msg_npol_ipset_add_del_members;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_add_del_members
#define __vapi_code_defined_vapi_msg_npol_ipset_add_del_members
static inline void vapi_msg_npol_ipset_add_del_members_payload_hton(vapi_payload_npol_ipset_add_del_members *payload)
{
  payload->set_id = htobe32(payload->set_id);
  payload->len = htobe32(payload->len);
}

static inline void vapi_msg_npol_ipset_add_del_members_payload_ntoh(vapi_payload_npol_ipset_add_del_members *payload)
{
  payload->set_id = be32toh(payload->set_id);
  payload->len = be32toh(payload->len);
}

static inline void vapi_msg_npol_ipset_add_del_members_hton(vapi_msg_npol_ipset_add_del_members *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_add_del_members'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_ipset_add_del_members_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_add_del_members_ntoh(vapi_msg_npol_ipset_add_del_members *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_add_del_members'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_add_del_members_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_add_del_members_msg_size(vapi_msg_npol_ipset_add_del_members *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.members[0]) * msg->payload.len;
}

static inline int vapi_verify_npol_ipset_add_del_members_msg_size(vapi_msg_npol_ipset_add_del_members *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_add_del_members) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_add_del_members' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_add_del_members));
      return -1;
    }
  if (vapi_calc_npol_ipset_add_del_members_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_add_del_members' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_add_del_members_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_ipset_add_del_members* vapi_alloc_npol_ipset_add_del_members(struct vapi_ctx_s *ctx, size_t _members_array_size)
{
  vapi_msg_npol_ipset_add_del_members *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_ipset_add_del_members) + sizeof(msg->payload.members[0]) * _members_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_ipset_add_del_members*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_ipset_add_del_members);
  msg->payload.len = _members_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_ipset_add_del_members(struct vapi_ctx_s *ctx,
  vapi_msg_npol_ipset_add_del_members *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_ipset_add_del_members_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_ipset_add_del_members_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_ipset_add_del_members_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_ipset_add_del_members_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_ipset_add_del_members()
{
  static const char name[] = "npol_ipset_add_del_members";
  static const char name_with_crc[] = "npol_ipset_add_del_members_8ad1b2ed";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_add_del_members = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_ipset_add_del_members, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_add_del_members_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_add_del_members_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_add_del_members_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_add_del_members = vapi_register_msg(&__vapi_metadata_npol_ipset_add_del_members);
  VAPI_DBG("Assigned msg id %d to npol_ipset_add_del_members", vapi_msg_id_npol_ipset_add_del_members);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_delete_reply
#define __vapi_def_defined_vapi_msg_npol_ipset_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_ipset_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_ipset_delete_reply payload;
} vapi_msg_npol_ipset_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_delete_reply
#define __vapi_code_defined_vapi_msg_npol_ipset_delete_reply
static inline void vapi_msg_npol_ipset_delete_reply_payload_hton(vapi_payload_npol_ipset_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_ipset_delete_reply_payload_ntoh(vapi_payload_npol_ipset_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_ipset_delete_reply_hton(vapi_msg_npol_ipset_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_ipset_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_delete_reply_ntoh(vapi_msg_npol_ipset_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_delete_reply_msg_size(vapi_msg_npol_ipset_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_ipset_delete_reply_msg_size(vapi_msg_npol_ipset_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_delete_reply));
      return -1;
    }
  if (vapi_calc_npol_ipset_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_ipset_delete_reply()
{
  static const char name[] = "npol_ipset_delete_reply";
  static const char name_with_crc[] = "npol_ipset_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_ipset_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_delete_reply = vapi_register_msg(&__vapi_metadata_npol_ipset_delete_reply);
  VAPI_DBG("Assigned msg id %d to npol_ipset_delete_reply", vapi_msg_id_npol_ipset_delete_reply);
}

static inline void vapi_set_vapi_msg_npol_ipset_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_ipset_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_ipset_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_ipset_delete
#define __vapi_def_defined_vapi_msg_npol_ipset_delete
typedef struct __attribute__ ((__packed__)) {
  u32 set_id; 
} vapi_payload_npol_ipset_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_ipset_delete payload;
} vapi_msg_npol_ipset_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_ipset_delete
#define __vapi_code_defined_vapi_msg_npol_ipset_delete
static inline void vapi_msg_npol_ipset_delete_payload_hton(vapi_payload_npol_ipset_delete *payload)
{
  payload->set_id = htobe32(payload->set_id);
}

static inline void vapi_msg_npol_ipset_delete_payload_ntoh(vapi_payload_npol_ipset_delete *payload)
{
  payload->set_id = be32toh(payload->set_id);
}

static inline void vapi_msg_npol_ipset_delete_hton(vapi_msg_npol_ipset_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_ipset_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_ipset_delete_ntoh(vapi_msg_npol_ipset_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_ipset_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_ipset_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_ipset_delete_msg_size(vapi_msg_npol_ipset_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_ipset_delete_msg_size(vapi_msg_npol_ipset_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_ipset_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_ipset_delete));
      return -1;
    }
  if (vapi_calc_npol_ipset_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_ipset_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_ipset_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_ipset_delete* vapi_alloc_npol_ipset_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_npol_ipset_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_ipset_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_ipset_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_ipset_delete);

  return msg;
}

static inline vapi_error_e vapi_npol_ipset_delete(struct vapi_ctx_s *ctx,
  vapi_msg_npol_ipset_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_ipset_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_ipset_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_ipset_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_ipset_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_ipset_delete()
{
  static const char name[] = "npol_ipset_delete";
  static const char name_with_crc[] = "npol_ipset_delete_ceacdbcb";
  static vapi_message_desc_t __vapi_metadata_npol_ipset_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_ipset_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_ipset_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_ipset_delete_hton,
    (generic_swap_fn_t)vapi_msg_npol_ipset_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_ipset_delete = vapi_register_msg(&__vapi_metadata_npol_ipset_delete);
  VAPI_DBG("Assigned msg id %d to npol_ipset_delete", vapi_msg_id_npol_ipset_delete);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_create_reply
#define __vapi_def_defined_vapi_msg_npol_rule_create_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 rule_id; 
} vapi_payload_npol_rule_create_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_rule_create_reply payload;
} vapi_msg_npol_rule_create_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_create_reply
#define __vapi_code_defined_vapi_msg_npol_rule_create_reply
static inline void vapi_msg_npol_rule_create_reply_payload_hton(vapi_payload_npol_rule_create_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->rule_id = htobe32(payload->rule_id);
}

static inline void vapi_msg_npol_rule_create_reply_payload_ntoh(vapi_payload_npol_rule_create_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->rule_id = be32toh(payload->rule_id);
}

static inline void vapi_msg_npol_rule_create_reply_hton(vapi_msg_npol_rule_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_create_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_rule_create_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_create_reply_ntoh(vapi_msg_npol_rule_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_create_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_rule_create_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_create_reply_msg_size(vapi_msg_npol_rule_create_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_rule_create_reply_msg_size(vapi_msg_npol_rule_create_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_create_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_create_reply));
      return -1;
    }
  if (vapi_calc_npol_rule_create_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_create_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_rule_create_reply()
{
  static const char name[] = "npol_rule_create_reply";
  static const char name_with_crc[] = "npol_rule_create_reply_b48f8052";
  static vapi_message_desc_t __vapi_metadata_npol_rule_create_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_rule_create_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_create_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_create_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_create_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_create_reply = vapi_register_msg(&__vapi_metadata_npol_rule_create_reply);
  VAPI_DBG("Assigned msg id %d to npol_rule_create_reply", vapi_msg_id_npol_rule_create_reply);
}

static inline void vapi_set_vapi_msg_npol_rule_create_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_rule_create_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_rule_create_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_create
#define __vapi_def_defined_vapi_msg_npol_rule_create
typedef struct __attribute__ ((__packed__)) {
  vapi_type_npol_rule rule; 
} vapi_payload_npol_rule_create;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_rule_create payload;
} vapi_msg_npol_rule_create;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_create
#define __vapi_code_defined_vapi_msg_npol_rule_create
static inline void vapi_msg_npol_rule_create_payload_hton(vapi_payload_npol_rule_create *payload)
{
  vapi_type_npol_rule_hton(&payload->rule);
}

static inline void vapi_msg_npol_rule_create_payload_ntoh(vapi_payload_npol_rule_create *payload)
{
  vapi_type_npol_rule_ntoh(&payload->rule);
}

static inline void vapi_msg_npol_rule_create_hton(vapi_msg_npol_rule_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_create'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_rule_create_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_create_ntoh(vapi_msg_npol_rule_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_create'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_rule_create_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_create_msg_size(vapi_msg_npol_rule_create *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.rule.matches[0]) * msg->payload.rule.num_entries;
}

static inline int vapi_verify_npol_rule_create_msg_size(vapi_msg_npol_rule_create *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_create) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_create));
      return -1;
    }
  if (vapi_calc_npol_rule_create_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_create_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_rule_create* vapi_alloc_npol_rule_create(struct vapi_ctx_s *ctx, size_t rule_matches_array_size)
{
  vapi_msg_npol_rule_create *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_rule_create) + sizeof(msg->payload.rule.matches[0]) * rule_matches_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_rule_create*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_rule_create);
  msg->payload.rule.num_entries = rule_matches_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_rule_create(struct vapi_ctx_s *ctx,
  vapi_msg_npol_rule_create *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_rule_create_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_rule_create_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_rule_create_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_rule_create_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_rule_create()
{
  static const char name[] = "npol_rule_create";
  static const char name_with_crc[] = "npol_rule_create_f113de45";
  static vapi_message_desc_t __vapi_metadata_npol_rule_create = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_rule_create, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_create_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_create_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_create_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_create = vapi_register_msg(&__vapi_metadata_npol_rule_create);
  VAPI_DBG("Assigned msg id %d to npol_rule_create", vapi_msg_id_npol_rule_create);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_update_reply
#define __vapi_def_defined_vapi_msg_npol_rule_update_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_rule_update_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_rule_update_reply payload;
} vapi_msg_npol_rule_update_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_update_reply
#define __vapi_code_defined_vapi_msg_npol_rule_update_reply
static inline void vapi_msg_npol_rule_update_reply_payload_hton(vapi_payload_npol_rule_update_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_rule_update_reply_payload_ntoh(vapi_payload_npol_rule_update_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_rule_update_reply_hton(vapi_msg_npol_rule_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_update_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_rule_update_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_update_reply_ntoh(vapi_msg_npol_rule_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_update_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_rule_update_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_update_reply_msg_size(vapi_msg_npol_rule_update_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_rule_update_reply_msg_size(vapi_msg_npol_rule_update_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_update_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_update_reply));
      return -1;
    }
  if (vapi_calc_npol_rule_update_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_update_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_rule_update_reply()
{
  static const char name[] = "npol_rule_update_reply";
  static const char name_with_crc[] = "npol_rule_update_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_rule_update_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_rule_update_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_update_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_update_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_update_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_update_reply = vapi_register_msg(&__vapi_metadata_npol_rule_update_reply);
  VAPI_DBG("Assigned msg id %d to npol_rule_update_reply", vapi_msg_id_npol_rule_update_reply);
}

static inline void vapi_set_vapi_msg_npol_rule_update_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_rule_update_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_rule_update_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_update
#define __vapi_def_defined_vapi_msg_npol_rule_update
typedef struct __attribute__ ((__packed__)) {
  u32 rule_id;
  vapi_type_npol_rule rule; 
} vapi_payload_npol_rule_update;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_rule_update payload;
} vapi_msg_npol_rule_update;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_update
#define __vapi_code_defined_vapi_msg_npol_rule_update
static inline void vapi_msg_npol_rule_update_payload_hton(vapi_payload_npol_rule_update *payload)
{
  payload->rule_id = htobe32(payload->rule_id);
  vapi_type_npol_rule_hton(&payload->rule);
}

static inline void vapi_msg_npol_rule_update_payload_ntoh(vapi_payload_npol_rule_update *payload)
{
  payload->rule_id = be32toh(payload->rule_id);
  vapi_type_npol_rule_ntoh(&payload->rule);
}

static inline void vapi_msg_npol_rule_update_hton(vapi_msg_npol_rule_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_update'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_rule_update_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_update_ntoh(vapi_msg_npol_rule_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_update'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_rule_update_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_update_msg_size(vapi_msg_npol_rule_update *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.rule.matches[0]) * msg->payload.rule.num_entries;
}

static inline int vapi_verify_npol_rule_update_msg_size(vapi_msg_npol_rule_update *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_update) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_update));
      return -1;
    }
  if (vapi_calc_npol_rule_update_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_update_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_rule_update* vapi_alloc_npol_rule_update(struct vapi_ctx_s *ctx, size_t rule_matches_array_size)
{
  vapi_msg_npol_rule_update *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_rule_update) + sizeof(msg->payload.rule.matches[0]) * rule_matches_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_rule_update*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_rule_update);
  msg->payload.rule.num_entries = rule_matches_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_rule_update(struct vapi_ctx_s *ctx,
  vapi_msg_npol_rule_update *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_rule_update_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_rule_update_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_rule_update_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_rule_update_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_rule_update()
{
  static const char name[] = "npol_rule_update";
  static const char name_with_crc[] = "npol_rule_update_e38bffe2";
  static vapi_message_desc_t __vapi_metadata_npol_rule_update = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_rule_update, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_update_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_update_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_update_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_update = vapi_register_msg(&__vapi_metadata_npol_rule_update);
  VAPI_DBG("Assigned msg id %d to npol_rule_update", vapi_msg_id_npol_rule_update);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_delete_reply
#define __vapi_def_defined_vapi_msg_npol_rule_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_rule_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_rule_delete_reply payload;
} vapi_msg_npol_rule_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_delete_reply
#define __vapi_code_defined_vapi_msg_npol_rule_delete_reply
static inline void vapi_msg_npol_rule_delete_reply_payload_hton(vapi_payload_npol_rule_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_rule_delete_reply_payload_ntoh(vapi_payload_npol_rule_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_rule_delete_reply_hton(vapi_msg_npol_rule_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_rule_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_delete_reply_ntoh(vapi_msg_npol_rule_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_rule_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_delete_reply_msg_size(vapi_msg_npol_rule_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_rule_delete_reply_msg_size(vapi_msg_npol_rule_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_delete_reply));
      return -1;
    }
  if (vapi_calc_npol_rule_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_rule_delete_reply()
{
  static const char name[] = "npol_rule_delete_reply";
  static const char name_with_crc[] = "npol_rule_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_rule_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_rule_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_delete_reply = vapi_register_msg(&__vapi_metadata_npol_rule_delete_reply);
  VAPI_DBG("Assigned msg id %d to npol_rule_delete_reply", vapi_msg_id_npol_rule_delete_reply);
}

static inline void vapi_set_vapi_msg_npol_rule_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_rule_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_rule_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_rule_delete
#define __vapi_def_defined_vapi_msg_npol_rule_delete
typedef struct __attribute__ ((__packed__)) {
  u32 rule_id; 
} vapi_payload_npol_rule_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_rule_delete payload;
} vapi_msg_npol_rule_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_rule_delete
#define __vapi_code_defined_vapi_msg_npol_rule_delete
static inline void vapi_msg_npol_rule_delete_payload_hton(vapi_payload_npol_rule_delete *payload)
{
  payload->rule_id = htobe32(payload->rule_id);
}

static inline void vapi_msg_npol_rule_delete_payload_ntoh(vapi_payload_npol_rule_delete *payload)
{
  payload->rule_id = be32toh(payload->rule_id);
}

static inline void vapi_msg_npol_rule_delete_hton(vapi_msg_npol_rule_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_rule_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_rule_delete_ntoh(vapi_msg_npol_rule_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_rule_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_rule_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_rule_delete_msg_size(vapi_msg_npol_rule_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_rule_delete_msg_size(vapi_msg_npol_rule_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_rule_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_rule_delete));
      return -1;
    }
  if (vapi_calc_npol_rule_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_rule_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_rule_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_rule_delete* vapi_alloc_npol_rule_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_npol_rule_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_rule_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_rule_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_rule_delete);

  return msg;
}

static inline vapi_error_e vapi_npol_rule_delete(struct vapi_ctx_s *ctx,
  vapi_msg_npol_rule_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_rule_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_rule_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_rule_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_rule_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_rule_delete()
{
  static const char name[] = "npol_rule_delete";
  static const char name_with_crc[] = "npol_rule_delete_d19bb6be";
  static vapi_message_desc_t __vapi_metadata_npol_rule_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_rule_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_rule_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_rule_delete_hton,
    (generic_swap_fn_t)vapi_msg_npol_rule_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_rule_delete = vapi_register_msg(&__vapi_metadata_npol_rule_delete);
  VAPI_DBG("Assigned msg id %d to npol_rule_delete", vapi_msg_id_npol_rule_delete);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_create_reply
#define __vapi_def_defined_vapi_msg_npol_policy_create_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 policy_id; 
} vapi_payload_npol_policy_create_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_policy_create_reply payload;
} vapi_msg_npol_policy_create_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_create_reply
#define __vapi_code_defined_vapi_msg_npol_policy_create_reply
static inline void vapi_msg_npol_policy_create_reply_payload_hton(vapi_payload_npol_policy_create_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->policy_id = htobe32(payload->policy_id);
}

static inline void vapi_msg_npol_policy_create_reply_payload_ntoh(vapi_payload_npol_policy_create_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->policy_id = be32toh(payload->policy_id);
}

static inline void vapi_msg_npol_policy_create_reply_hton(vapi_msg_npol_policy_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_create_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_policy_create_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_create_reply_ntoh(vapi_msg_npol_policy_create_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_create_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_policy_create_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_create_reply_msg_size(vapi_msg_npol_policy_create_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_policy_create_reply_msg_size(vapi_msg_npol_policy_create_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_create_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_create_reply));
      return -1;
    }
  if (vapi_calc_npol_policy_create_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_create_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_create_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_policy_create_reply()
{
  static const char name[] = "npol_policy_create_reply";
  static const char name_with_crc[] = "npol_policy_create_reply_90f27405";
  static vapi_message_desc_t __vapi_metadata_npol_policy_create_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_policy_create_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_create_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_create_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_create_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_create_reply = vapi_register_msg(&__vapi_metadata_npol_policy_create_reply);
  VAPI_DBG("Assigned msg id %d to npol_policy_create_reply", vapi_msg_id_npol_policy_create_reply);
}

static inline void vapi_set_vapi_msg_npol_policy_create_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_policy_create_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_policy_create_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_create
#define __vapi_def_defined_vapi_msg_npol_policy_create
typedef struct __attribute__ ((__packed__)) {
  u32 num_items;
  vapi_type_npol_policy_item rules[0]; 
} vapi_payload_npol_policy_create;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_policy_create payload;
} vapi_msg_npol_policy_create;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_create
#define __vapi_code_defined_vapi_msg_npol_policy_create
static inline void vapi_msg_npol_policy_create_payload_hton(vapi_payload_npol_policy_create *payload)
{
  payload->num_items = htobe32(payload->num_items);
  do { unsigned i; for (i = 0; i < be32toh(payload->num_items); ++i) { vapi_type_npol_policy_item_hton(&payload->rules[i]); } } while(0);
}

static inline void vapi_msg_npol_policy_create_payload_ntoh(vapi_payload_npol_policy_create *payload)
{
  payload->num_items = be32toh(payload->num_items);
  do { unsigned i; for (i = 0; i < payload->num_items; ++i) { vapi_type_npol_policy_item_ntoh(&payload->rules[i]); } } while(0);
}

static inline void vapi_msg_npol_policy_create_hton(vapi_msg_npol_policy_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_create'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_policy_create_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_create_ntoh(vapi_msg_npol_policy_create *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_create'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_policy_create_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_create_msg_size(vapi_msg_npol_policy_create *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.rules[0]) * msg->payload.num_items;
}

static inline int vapi_verify_npol_policy_create_msg_size(vapi_msg_npol_policy_create *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_create) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_create));
      return -1;
    }
  if (vapi_calc_npol_policy_create_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_create' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_create_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_policy_create* vapi_alloc_npol_policy_create(struct vapi_ctx_s *ctx, size_t _rules_array_size)
{
  vapi_msg_npol_policy_create *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_policy_create) + sizeof(msg->payload.rules[0]) * _rules_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_policy_create*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_policy_create);
  msg->payload.num_items = _rules_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_policy_create(struct vapi_ctx_s *ctx,
  vapi_msg_npol_policy_create *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_policy_create_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_policy_create_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_policy_create_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_policy_create_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_policy_create()
{
  static const char name[] = "npol_policy_create";
  static const char name_with_crc[] = "npol_policy_create_3441bb97";
  static vapi_message_desc_t __vapi_metadata_npol_policy_create = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_policy_create, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_create_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_create_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_create_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_create = vapi_register_msg(&__vapi_metadata_npol_policy_create);
  VAPI_DBG("Assigned msg id %d to npol_policy_create", vapi_msg_id_npol_policy_create);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_update_reply
#define __vapi_def_defined_vapi_msg_npol_policy_update_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_policy_update_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_policy_update_reply payload;
} vapi_msg_npol_policy_update_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_update_reply
#define __vapi_code_defined_vapi_msg_npol_policy_update_reply
static inline void vapi_msg_npol_policy_update_reply_payload_hton(vapi_payload_npol_policy_update_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_policy_update_reply_payload_ntoh(vapi_payload_npol_policy_update_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_policy_update_reply_hton(vapi_msg_npol_policy_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_update_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_policy_update_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_update_reply_ntoh(vapi_msg_npol_policy_update_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_update_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_policy_update_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_update_reply_msg_size(vapi_msg_npol_policy_update_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_policy_update_reply_msg_size(vapi_msg_npol_policy_update_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_update_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_update_reply));
      return -1;
    }
  if (vapi_calc_npol_policy_update_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_update_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_update_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_policy_update_reply()
{
  static const char name[] = "npol_policy_update_reply";
  static const char name_with_crc[] = "npol_policy_update_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_policy_update_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_policy_update_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_update_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_update_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_update_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_update_reply = vapi_register_msg(&__vapi_metadata_npol_policy_update_reply);
  VAPI_DBG("Assigned msg id %d to npol_policy_update_reply", vapi_msg_id_npol_policy_update_reply);
}

static inline void vapi_set_vapi_msg_npol_policy_update_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_policy_update_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_policy_update_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_update
#define __vapi_def_defined_vapi_msg_npol_policy_update
typedef struct __attribute__ ((__packed__)) {
  u32 policy_id;
  u32 num_items;
  vapi_type_npol_policy_item rules[0]; 
} vapi_payload_npol_policy_update;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_policy_update payload;
} vapi_msg_npol_policy_update;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_update
#define __vapi_code_defined_vapi_msg_npol_policy_update
static inline void vapi_msg_npol_policy_update_payload_hton(vapi_payload_npol_policy_update *payload)
{
  payload->policy_id = htobe32(payload->policy_id);
  payload->num_items = htobe32(payload->num_items);
  do { unsigned i; for (i = 0; i < be32toh(payload->num_items); ++i) { vapi_type_npol_policy_item_hton(&payload->rules[i]); } } while(0);
}

static inline void vapi_msg_npol_policy_update_payload_ntoh(vapi_payload_npol_policy_update *payload)
{
  payload->policy_id = be32toh(payload->policy_id);
  payload->num_items = be32toh(payload->num_items);
  do { unsigned i; for (i = 0; i < payload->num_items; ++i) { vapi_type_npol_policy_item_ntoh(&payload->rules[i]); } } while(0);
}

static inline void vapi_msg_npol_policy_update_hton(vapi_msg_npol_policy_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_update'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_policy_update_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_update_ntoh(vapi_msg_npol_policy_update *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_update'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_policy_update_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_update_msg_size(vapi_msg_npol_policy_update *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.rules[0]) * msg->payload.num_items;
}

static inline int vapi_verify_npol_policy_update_msg_size(vapi_msg_npol_policy_update *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_update) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_update));
      return -1;
    }
  if (vapi_calc_npol_policy_update_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_update' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_update_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_policy_update* vapi_alloc_npol_policy_update(struct vapi_ctx_s *ctx, size_t _rules_array_size)
{
  vapi_msg_npol_policy_update *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_policy_update) + sizeof(msg->payload.rules[0]) * _rules_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_policy_update*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_policy_update);
  msg->payload.num_items = _rules_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_policy_update(struct vapi_ctx_s *ctx,
  vapi_msg_npol_policy_update *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_policy_update_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_policy_update_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_policy_update_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_policy_update_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_policy_update()
{
  static const char name[] = "npol_policy_update";
  static const char name_with_crc[] = "npol_policy_update_21a5f7ef";
  static vapi_message_desc_t __vapi_metadata_npol_policy_update = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_policy_update, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_update_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_update_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_update_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_update = vapi_register_msg(&__vapi_metadata_npol_policy_update);
  VAPI_DBG("Assigned msg id %d to npol_policy_update", vapi_msg_id_npol_policy_update);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_delete_reply
#define __vapi_def_defined_vapi_msg_npol_policy_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_policy_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_policy_delete_reply payload;
} vapi_msg_npol_policy_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_delete_reply
#define __vapi_code_defined_vapi_msg_npol_policy_delete_reply
static inline void vapi_msg_npol_policy_delete_reply_payload_hton(vapi_payload_npol_policy_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_policy_delete_reply_payload_ntoh(vapi_payload_npol_policy_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_policy_delete_reply_hton(vapi_msg_npol_policy_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_policy_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_delete_reply_ntoh(vapi_msg_npol_policy_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_policy_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_delete_reply_msg_size(vapi_msg_npol_policy_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_policy_delete_reply_msg_size(vapi_msg_npol_policy_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_delete_reply));
      return -1;
    }
  if (vapi_calc_npol_policy_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_policy_delete_reply()
{
  static const char name[] = "npol_policy_delete_reply";
  static const char name_with_crc[] = "npol_policy_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_policy_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_policy_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_delete_reply = vapi_register_msg(&__vapi_metadata_npol_policy_delete_reply);
  VAPI_DBG("Assigned msg id %d to npol_policy_delete_reply", vapi_msg_id_npol_policy_delete_reply);
}

static inline void vapi_set_vapi_msg_npol_policy_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_policy_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_policy_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_policy_delete
#define __vapi_def_defined_vapi_msg_npol_policy_delete
typedef struct __attribute__ ((__packed__)) {
  u32 policy_id; 
} vapi_payload_npol_policy_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_policy_delete payload;
} vapi_msg_npol_policy_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_policy_delete
#define __vapi_code_defined_vapi_msg_npol_policy_delete
static inline void vapi_msg_npol_policy_delete_payload_hton(vapi_payload_npol_policy_delete *payload)
{
  payload->policy_id = htobe32(payload->policy_id);
}

static inline void vapi_msg_npol_policy_delete_payload_ntoh(vapi_payload_npol_policy_delete *payload)
{
  payload->policy_id = be32toh(payload->policy_id);
}

static inline void vapi_msg_npol_policy_delete_hton(vapi_msg_npol_policy_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_policy_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_policy_delete_ntoh(vapi_msg_npol_policy_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_policy_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_policy_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_policy_delete_msg_size(vapi_msg_npol_policy_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_policy_delete_msg_size(vapi_msg_npol_policy_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_policy_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_policy_delete));
      return -1;
    }
  if (vapi_calc_npol_policy_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_policy_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_policy_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_policy_delete* vapi_alloc_npol_policy_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_npol_policy_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_policy_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_policy_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_policy_delete);

  return msg;
}

static inline vapi_error_e vapi_npol_policy_delete(struct vapi_ctx_s *ctx,
  vapi_msg_npol_policy_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_policy_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_policy_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_policy_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_policy_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_policy_delete()
{
  static const char name[] = "npol_policy_delete";
  static const char name_with_crc[] = "npol_policy_delete_ad833868";
  static vapi_message_desc_t __vapi_metadata_npol_policy_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_policy_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_policy_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_policy_delete_hton,
    (generic_swap_fn_t)vapi_msg_npol_policy_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_policy_delete = vapi_register_msg(&__vapi_metadata_npol_policy_delete);
  VAPI_DBG("Assigned msg id %d to npol_policy_delete", vapi_msg_id_npol_policy_delete);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_configure_policies_reply
#define __vapi_def_defined_vapi_msg_npol_configure_policies_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_npol_configure_policies_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_npol_configure_policies_reply payload;
} vapi_msg_npol_configure_policies_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_configure_policies_reply
#define __vapi_code_defined_vapi_msg_npol_configure_policies_reply
static inline void vapi_msg_npol_configure_policies_reply_payload_hton(vapi_payload_npol_configure_policies_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_npol_configure_policies_reply_payload_ntoh(vapi_payload_npol_configure_policies_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_npol_configure_policies_reply_hton(vapi_msg_npol_configure_policies_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_configure_policies_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_npol_configure_policies_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_configure_policies_reply_ntoh(vapi_msg_npol_configure_policies_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_configure_policies_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_npol_configure_policies_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_configure_policies_reply_msg_size(vapi_msg_npol_configure_policies_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_npol_configure_policies_reply_msg_size(vapi_msg_npol_configure_policies_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_configure_policies_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_configure_policies_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_configure_policies_reply));
      return -1;
    }
  if (vapi_calc_npol_configure_policies_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_configure_policies_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_configure_policies_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_npol_configure_policies_reply()
{
  static const char name[] = "npol_configure_policies_reply";
  static const char name_with_crc[] = "npol_configure_policies_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_npol_configure_policies_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_npol_configure_policies_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_configure_policies_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_configure_policies_reply_hton,
    (generic_swap_fn_t)vapi_msg_npol_configure_policies_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_configure_policies_reply = vapi_register_msg(&__vapi_metadata_npol_configure_policies_reply);
  VAPI_DBG("Assigned msg id %d to npol_configure_policies_reply", vapi_msg_id_npol_configure_policies_reply);
}

static inline void vapi_set_vapi_msg_npol_configure_policies_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_npol_configure_policies_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_npol_configure_policies_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_npol_configure_policies
#define __vapi_def_defined_vapi_msg_npol_configure_policies
typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 num_rx_policies;
  u32 num_tx_policies;
  u32 total_ids;
  u8 invert_rx_tx;
  vapi_enum_npol_policy_default policy_default_rx;
  vapi_enum_npol_policy_default policy_default_tx;
  vapi_enum_npol_policy_default profile_default_rx;
  vapi_enum_npol_policy_default profile_default_tx;
  u32 policy_ids[0]; 
} vapi_payload_npol_configure_policies;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_npol_configure_policies payload;
} vapi_msg_npol_configure_policies;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_npol_configure_policies
#define __vapi_code_defined_vapi_msg_npol_configure_policies
static inline void vapi_msg_npol_configure_policies_payload_hton(vapi_payload_npol_configure_policies *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->num_rx_policies = htobe32(payload->num_rx_policies);
  payload->num_tx_policies = htobe32(payload->num_tx_policies);
  payload->total_ids = htobe32(payload->total_ids);
  do { unsigned i; for (i = 0; i < be32toh(payload->total_ids); ++i) { payload->policy_ids[i] = htobe32(payload->policy_ids[i]); } } while(0);
}

static inline void vapi_msg_npol_configure_policies_payload_ntoh(vapi_payload_npol_configure_policies *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->num_rx_policies = be32toh(payload->num_rx_policies);
  payload->num_tx_policies = be32toh(payload->num_tx_policies);
  payload->total_ids = be32toh(payload->total_ids);
  do { unsigned i; for (i = 0; i < payload->total_ids; ++i) { payload->policy_ids[i] = be32toh(payload->policy_ids[i]); } } while(0);
}

static inline void vapi_msg_npol_configure_policies_hton(vapi_msg_npol_configure_policies *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_configure_policies'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_npol_configure_policies_payload_hton(&msg->payload);
}

static inline void vapi_msg_npol_configure_policies_ntoh(vapi_msg_npol_configure_policies *msg)
{
  VAPI_DBG("Swapping `vapi_msg_npol_configure_policies'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_npol_configure_policies_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_npol_configure_policies_msg_size(vapi_msg_npol_configure_policies *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.policy_ids[0]) * msg->payload.total_ids;
}

static inline int vapi_verify_npol_configure_policies_msg_size(vapi_msg_npol_configure_policies *msg, uword buf_size)
{
  if (sizeof(vapi_msg_npol_configure_policies) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_configure_policies' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_npol_configure_policies));
      return -1;
    }
  if (vapi_calc_npol_configure_policies_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'npol_configure_policies' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_npol_configure_policies_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_npol_configure_policies* vapi_alloc_npol_configure_policies(struct vapi_ctx_s *ctx, size_t _policy_ids_array_size)
{
  vapi_msg_npol_configure_policies *msg = NULL;
  const size_t size = sizeof(vapi_msg_npol_configure_policies) + sizeof(msg->payload.policy_ids[0]) * _policy_ids_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_npol_configure_policies*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_npol_configure_policies);
  msg->payload.total_ids = _policy_ids_array_size;

  return msg;
}

static inline vapi_error_e vapi_npol_configure_policies(struct vapi_ctx_s *ctx,
  vapi_msg_npol_configure_policies *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_npol_configure_policies_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_npol_configure_policies_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_npol_configure_policies_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_npol_configure_policies_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_npol_configure_policies()
{
  static const char name[] = "npol_configure_policies";
  static const char name_with_crc[] = "npol_configure_policies_66fe1335";
  static vapi_message_desc_t __vapi_metadata_npol_configure_policies = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_npol_configure_policies, payload),
    (verify_msg_size_fn_t)vapi_verify_npol_configure_policies_msg_size,
    (generic_swap_fn_t)vapi_msg_npol_configure_policies_hton,
    (generic_swap_fn_t)vapi_msg_npol_configure_policies_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_npol_configure_policies = vapi_register_msg(&__vapi_metadata_npol_configure_policies);
  VAPI_DBG("Assigned msg id %d to npol_configure_policies", vapi_msg_id_npol_configure_policies);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

#ifndef __included_bfib_api_json
#define __included_bfib_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_bfib_plugin_get_version;
extern vapi_msg_id_t vapi_msg_id_bfib_plugin_get_version_reply;
extern vapi_msg_id_t vapi_msg_id_bfib_route_batch;
extern vapi_msg_id_t vapi_msg_id_bfib_route_batch_reply;

#define DEFINE_VAPI_MSG_IDS_BFIB_API_JSON\
  vapi_msg_id_t vapi_msg_id_bfib_plugin_get_version;\
  vapi_msg_id_t vapi_msg_id_bfib_plugin_get_version_reply;\
  vapi_msg_id_t vapi_msg_id_bfib_route_batch;\
  vapi_msg_id_t vapi_msg_id_bfib_route_batch_reply;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_nh_proto
#define __vapi_def_defined_vapi_enum_fib_path_nh_proto
typedef enum {
  FIB_API_PATH_NH_PROTO_IP4 = 0,
  FIB_API_PATH_NH_PROTO_IP6 = 1,
  FIB_API_PATH_NH_PROTO_MPLS = 2,
  FIB_API_PATH_NH_PROTO_ETHERNET = 3,
  FIB_API_PATH_NH_PROTO_BIER = 4,
}  vapi_enum_fib_path_nh_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_nh_proto
#define __vapi_code_defined_vapi_enum_fib_path_nh_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_flags
#define __vapi_def_defined_vapi_enum_fib_path_flags
typedef enum {
  FIB_API_PATH_FLAG_NONE = 0,
  FIB_API_PATH_FLAG_RESOLVE_VIA_ATTACHED = 1,
  FIB_API_PATH_FLAG_RESOLVE_VIA_HOST = 2,
  FIB_API_PATH_FLAG_POP_PW_CW = 4,
}  vapi_enum_fib_path_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_flags
#define __vapi_code_defined_vapi_enum_fib_path_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_fib_path_type
#define __vapi_def_defined_vapi_enum_fib_path_type
typedef enum {
  FIB_API_PATH_TYPE_NORMAL = 0,
  FIB_API_PATH_TYPE_LOCAL = 1,
  FIB_API_PATH_TYPE_DROP = 2,
  FIB_API_PATH_TYPE_UDP_ENCAP = 3,
  FIB_API_PATH_TYPE_BIER_IMP = 4,
  FIB_API_PATH_TYPE_ICMP_UNREACH = 5,
  FIB_API_PATH_TYPE_ICMP_PROHIBIT = 6,
  FIB_API_PATH_TYPE_SOURCE_LOOKUP = 7,
  FIB_API_PATH_TYPE_DVR = 8,
  FIB_API_PATH_TYPE_INTERFACE_RX = 9,
  FIB_API_PATH_TYPE_CLASSIFY = 10,
}  vapi_enum_fib_path_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_fib_path_type
#define __vapi_code_defined_vapi_enum_fib_path_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_mpls_label
#define __vapi_def_defined_vapi_type_fib_mpls_label
typedef struct __attribute__((__packed__)) {
  u8 is_uniform;
  u32 label;
  u8 ttl;
  u8 exp;
} vapi_type_fib_mpls_label;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_mpls_label
#define __vapi_code_defined_vapi_type_fib_mpls_label
static inline void vapi_type_fib_mpls_label_hton(vapi_type_fib_mpls_label *msg)
{
  msg->label = htobe32(msg->label);
}

static inline void vapi_type_fib_mpls_label_ntoh(vapi_type_fib_mpls_label *msg)
{
  msg->label = be32toh(msg->label);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_bfib_result
#define __vapi_def_defined_vapi_type_bfib_result
typedef struct __attribute__((__packed__)) {
  u32 cookie;
  i32 retval;
} vapi_type_bfib_result;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_bfib_result
#define __vapi_code_defined_vapi_type_bfib_result
static inline void vapi_type_bfib_result_hton(vapi_type_bfib_result *msg)
{
  msg->cookie = htobe32(msg->cookie);
  msg->retval = htobe32(msg->retval);
}

static inline void vapi_type_bfib_result_ntoh(vapi_type_bfib_result *msg)
{
  msg->cookie = be32toh(msg->cookie);
  msg->retval = be32toh(msg->retval);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_path_nh
#define __vapi_def_defined_vapi_type_fib_path_nh
typedef struct __attribute__((__packed__)) {
  vapi_union_address_union address;
  u32 via_label;
  u32 obj_id;
  u32 classify_table_index;
} vapi_type_fib_path_nh;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_path_nh
#define __vapi_code_defined_vapi_type_fib_path_nh
static inline void vapi_type_fib_path_nh_hton(vapi_type_fib_path_nh *msg)
{
  msg->via_label = htobe32(msg->via_label);
  msg->obj_id = htobe32(msg->obj_id);
  msg->classify_table_index = htobe32(msg->classify_table_index);
}

static inline void vapi_type_fib_path_nh_ntoh(vapi_type_fib_path_nh *msg)
{
  msg->via_label = be32toh(msg->via_label);
  msg->obj_id = be32toh(msg->obj_id);
  msg->classify_table_index = be32toh(msg->classify_table_index);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_fib_path
#define __vapi_def_defined_vapi_type_fib_path
typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u32 table_id;
  u32 rpf_id;
  u8 weight;
  u8 preference;
  vapi_enum_fib_path_type type;
  vapi_enum_fib_path_flags flags;
  vapi_enum_fib_path_nh_proto proto;
  vapi_type_fib_path_nh nh;
  u8 n_labels;
  vapi_type_fib_mpls_label label_stack[16];
} vapi_type_fib_path;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_fib_path
#define __vapi_code_defined_vapi_type_fib_path
static inline void vapi_type_fib_path_hton(vapi_type_fib_path *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
  msg->table_id = htobe32(msg->table_id);
  msg->rpf_id = htobe32(msg->rpf_id);
  msg->type = (vapi_enum_fib_path_type)htobe32(msg->type);
  msg->flags = (vapi_enum_fib_path_flags)htobe32(msg->flags);
  msg->proto = (vapi_enum_fib_path_nh_proto)htobe32(msg->proto);
  vapi_type_fib_path_nh_hton(&msg->nh);
  do { unsigned i; for (i = 0; i < 16; ++i) { vapi_type_fib_mpls_label_hton(&msg->label_stack[i]); } } while(0);
}

static inline void vapi_type_fib_path_ntoh(vapi_type_fib_path *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
  msg->table_id = be32toh(msg->table_id);
  msg->rpf_id = be32toh(msg->rpf_id);
  msg->type = (vapi_enum_fib_path_type)be32toh(msg->type);
  msg->flags = (vapi_enum_fib_path_flags)be32toh(msg->flags);
  msg->proto = (vapi_enum_fib_path_nh_proto)be32toh(msg->proto);
  vapi_type_fib_path_nh_ntoh(&msg->nh);
  do { unsigned i; for (i = 0; i < 16; ++i) { vapi_type_fib_mpls_label_ntoh(&msg->label_stack[i]); } } while(0);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_bfib_route
#define __vapi_def_defined_vapi_type_bfib_route
typedef struct __attribute__((__packed__)) {
  vapi_type_prefix prefix;
  u32 cookie;
  u8 is_add;
  u8 n_paths;
  u8 pad[2];
  vapi_type_fib_path paths[4];
} vapi_type_bfib_route;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_bfib_route
#define __vapi_code_defined_vapi_type_bfib_route
static inline void vapi_type_bfib_route_hton(vapi_type_bfib_route *msg)
{
  msg->cookie = htobe32(msg->cookie);
  do { unsigned i; for (i = 0; i < 4; ++i) { vapi_type_fib_path_hton(&msg->paths[i]); } } while(0);
}

static inline void vapi_type_bfib_route_ntoh(vapi_type_bfib_route *msg)
{
  msg->cookie = be32toh(msg->cookie);
  do { unsigned i; for (i = 0; i < 4; ++i) { vapi_type_fib_path_ntoh(&msg->paths[i]); } } while(0);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_bfib_plugin_get_version_reply
#define __vapi_def_defined_vapi_msg_bfib_plugin_get_version_reply
typedef struct __attribute__ ((__packed__)) {
  u32 major;
  u32 minor; 
} vapi_payload_bfib_plugin_get_version_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_bfib_plugin_get_version_reply payload;
} vapi_msg_bfib_plugin_get_version_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_bfib_plugin_get_version_reply
#define __vapi_code_defined_vapi_msg_bfib_plugin_get_version_reply
static inline void vapi_msg_bfib_plugin_get_version_reply_payload_hton(vapi_payload_bfib_plugin_get_version_reply *payload)
{
  payload->major = htobe32(payload->major);
  payload->minor = htobe32(payload->minor);
}

static inline void vapi_msg_bfib_plugin_get_version_reply_payload_ntoh(vapi_payload_bfib_plugin_get_version_reply *payload)
{
  payload->major = be32toh(payload->major);
  payload->minor = be32toh(payload->minor);
}

static inline void vapi_msg_bfib_plugin_get_version_reply_hton(vapi_msg_bfib_plugin_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_plugin_get_version_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_bfib_plugin_get_version_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_bfib_plugin_get_version_reply_ntoh(vapi_msg_bfib_plugin_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_plugin_get_version_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_bfib_plugin_get_version_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_bfib_plugin_get_version_reply_msg_size(vapi_msg_bfib_plugin_get_version_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_bfib_plugin_get_version_reply_msg_size(vapi_msg_bfib_plugin_get_version_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_bfib_plugin_get_version_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_plugin_get_version_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_bfib_plugin_get_version_reply));
      return -1;
    }
  if (vapi_calc_bfib_plugin_get_version_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_plugin_get_version_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_bfib_plugin_get_version_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_bfib_plugin_get_version_reply()
{
  static const char name[] = "bfib_plugin_get_version_reply";
  static const char name_with_crc[] = "bfib_plugin_get_version_reply_9b32cf86";
  static vapi_message_desc_t __vapi_metadata_bfib_plugin_get_version_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_bfib_plugin_get_version_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_bfib_plugin_get_version_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_bfib_plugin_get_version_reply_hton,
    (generic_swap_fn_t)vapi_msg_bfib_plugin_get_version_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_bfib_plugin_get_version_reply = vapi_register_msg(&__vapi_metadata_bfib_plugin_get_version_reply);
  VAPI_DBG("Assigned msg id %d to bfib_plugin_get_version_reply", vapi_msg_id_bfib_plugin_get_version_reply);
}

static inline void vapi_set_vapi_msg_bfib_plugin_get_version_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_bfib_plugin_get_version_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_bfib_plugin_get_version_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_bfib_plugin_get_version
#define __vapi_def_defined_vapi_msg_bfib_plugin_get_version
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_bfib_plugin_get_version;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_bfib_plugin_get_version
#define __vapi_code_defined_vapi_msg_bfib_plugin_get_version
static inline void vapi_msg_bfib_plugin_get_version_hton(vapi_msg_bfib_plugin_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_plugin_get_version'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_bfib_plugin_get_version_ntoh(vapi_msg_bfib_plugin_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_plugin_get_version'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_bfib_plugin_get_version_msg_size(vapi_msg_bfib_plugin_get_version *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_bfib_plugin_get_version_msg_size(vapi_msg_bfib_plugin_get_version *msg, uword buf_size)
{
  if (sizeof(vapi_msg_bfib_plugin_get_version) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_plugin_get_version' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_bfib_plugin_get_version));
      return -1;
    }
  if (vapi_calc_bfib_plugin_get_version_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_plugin_get_version' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_bfib_plugin_get_version_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_bfib_plugin_get_version* vapi_alloc_bfib_plugin_get_version(struct vapi_ctx_s *ctx)
{
  vapi_msg_bfib_plugin_get_version *msg = NULL;
  const size_t size = sizeof(vapi_msg_bfib_plugin_get_version);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_bfib_plugin_get_version*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_bfib_plugin_get_version);

  return msg;
}

static inline vapi_error_e vapi_bfib_plugin_get_version(struct vapi_ctx_s *ctx,
  vapi_msg_bfib_plugin_get_version *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_bfib_plugin_get_version_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_bfib_plugin_get_version_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_bfib_plugin_get_version_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_bfib_plugin_get_version_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_bfib_plugin_get_version()
{
  static const char name[] = "bfib_plugin_get_version";
  static const char name_with_crc[] = "bfib_plugin_get_version_51077d14";
  static vapi_message_desc_t __vapi_metadata_bfib_plugin_get_version = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_bfib_plugin_get_version_msg_size,
    (generic_swap_fn_t)vapi_msg_bfib_plugin_get_version_hton,
    (generic_swap_fn_t)vapi_msg_bfib_plugin_get_version_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_bfib_plugin_get_version = vapi_register_msg(&__vapi_metadata_bfib_plugin_get_version);
  VAPI_DBG("Assigned msg id %d to bfib_plugin_get_version", vapi_msg_id_bfib_plugin_get_version);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_bfib_route_batch_reply
#define __vapi_def_defined_vapi_msg_bfib_route_batch_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u16 n_items;
  u8 pad[2];
  vapi_type_bfib_result results[0]; 
} vapi_payload_bfib_route_batch_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_bfib_route_batch_reply payload;
} vapi_msg_bfib_route_batch_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_bfib_route_batch_reply
#define __vapi_code_defined_vapi_msg_bfib_route_batch_reply
static inline void vapi_msg_bfib_route_batch_reply_payload_hton(vapi_payload_bfib_route_batch_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->n_items = htobe16(payload->n_items);
  do { unsigned i; for (i = 0; i < be16toh(payload->n_items); ++i) { vapi_type_bfib_result_hton(&payload->results[i]); } } while(0);
}

static inline void vapi_msg_bfib_route_batch_reply_payload_ntoh(vapi_payload_bfib_route_batch_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->n_items = be16toh(payload->n_items);
  do { unsigned i; for (i = 0; i < payload->n_items; ++i) { vapi_type_bfib_result_ntoh(&payload->results[i]); } } while(0);
}

static inline void vapi_msg_bfib_route_batch_reply_hton(vapi_msg_bfib_route_batch_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_route_batch_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_bfib_route_batch_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_bfib_route_batch_reply_ntoh(vapi_msg_bfib_route_batch_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_route_batch_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_bfib_route_batch_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_bfib_route_batch_reply_msg_size(vapi_msg_bfib_route_batch_reply *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.results[0]) * msg->payload.n_items;
}

static inline int vapi_verify_bfib_route_batch_reply_msg_size(vapi_msg_bfib_route_batch_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_bfib_route_batch_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_route_batch_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_bfib_route_batch_reply));
      return -1;
    }
  if (vapi_calc_bfib_route_batch_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_route_batch_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_bfib_route_batch_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_bfib_route_batch_reply()
{
  static const char name[] = "bfib_route_batch_reply";
  static const char name_with_crc[] = "bfib_route_batch_reply_d4e586ff";
  static vapi_message_desc_t __vapi_metadata_bfib_route_batch_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_bfib_route_batch_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_bfib_route_batch_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_bfib_route_batch_reply_hton,
    (generic_swap_fn_t)vapi_msg_bfib_route_batch_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_bfib_route_batch_reply = vapi_register_msg(&__vapi_metadata_bfib_route_batch_reply);
  VAPI_DBG("Assigned msg id %d to bfib_route_batch_reply", vapi_msg_id_bfib_route_batch_reply);
}

static inline void vapi_set_vapi_msg_bfib_route_batch_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_bfib_route_batch_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_bfib_route_batch_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_bfib_route_batch
#define __vapi_def_defined_vapi_msg_bfib_route_batch
typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u16 n_items;
  u8 pad[2];
  vapi_type_bfib_route items[0]; 
} vapi_payload_bfib_route_batch;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_bfib_route_batch payload;
} vapi_msg_bfib_route_batch;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_bfib_route_batch
#define __vapi_code_defined_vapi_msg_bfib_route_batch
static inline void vapi_msg_bfib_route_batch_payload_hton(vapi_payload_bfib_route_batch *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->n_items = htobe16(payload->n_items);
  do { unsigned i; for (i = 0; i < be16toh(payload->n_items); ++i) { vapi_type_bfib_route_hton(&payload->items[i]); } } while(0);
}

static inline void vapi_msg_bfib_route_batch_payload_ntoh(vapi_payload_bfib_route_batch *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->n_items = be16toh(payload->n_items);
  do { unsigned i; for (i = 0; i < payload->n_items; ++i) { vapi_type_bfib_route_ntoh(&payload->items[i]); } } while(0);
}

static inline void vapi_msg_bfib_route_batch_hton(vapi_msg_bfib_route_batch *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_route_batch'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_bfib_route_batch_payload_hton(&msg->payload);
}

static inline void vapi_msg_bfib_route_batch_ntoh(vapi_msg_bfib_route_batch *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bfib_route_batch'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_bfib_route_batch_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_bfib_route_batch_msg_size(vapi_msg_bfib_route_batch *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.items[0]) * msg->payload.n_items;
}

static inline int vapi_verify_bfib_route_batch_msg_size(vapi_msg_bfib_route_batch *msg, uword buf_size)
{
  if (sizeof(vapi_msg_bfib_route_batch) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_route_batch' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_bfib_route_batch));
      return -1;
    }
  if (vapi_calc_bfib_route_batch_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'bfib_route_batch' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_bfib_route_batch_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_bfib_route_batch* vapi_alloc_bfib_route_batch(struct vapi_ctx_s *ctx, size_t _items_array_size)
{
  vapi_msg_bfib_route_batch *msg = NULL;
  const size_t size = sizeof(vapi_msg_bfib_route_batch) + sizeof(msg->payload.items[0]) * _items_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_bfib_route_batch*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_bfib_route_batch);
  msg->payload.n_items = _items_array_size;

  return msg;
}

static inline vapi_error_e vapi_bfib_route_batch(struct vapi_ctx_s *ctx,
  vapi_msg_bfib_route_batch *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_bfib_route_batch_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_bfib_route_batch_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_bfib_route_batch_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_bfib_route_batch_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_bfib_route_batch()
{
  static const char name[] = "bfib_route_batch";
  static const char name_with_crc[] = "bfib_route_batch_31e52189";
  static vapi_message_desc_t __vapi_metadata_bfib_route_batch = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_bfib_route_batch, payload),
    (verify_msg_size_fn_t)vapi_verify_bfib_route_batch_msg_size,
    (generic_swap_fn_t)vapi_msg_bfib_route_batch_hton,
    (generic_swap_fn_t)vapi_msg_bfib_route_batch_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_bfib_route_batch = vapi_register_msg(&__vapi_metadata_bfib_route_batch);
  VAPI_DBG("Assigned msg id %d to bfib_route_batch", vapi_msg_id_bfib_route_batch);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

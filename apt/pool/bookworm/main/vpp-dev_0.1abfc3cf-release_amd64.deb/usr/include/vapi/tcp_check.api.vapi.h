#ifndef __included_tcp_check_api_json
#define __included_tcp_check_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_sfdp_tcp_session_dump;
extern vapi_msg_id_t vapi_msg_id_sfdp_tcp_session_details;

#define DEFINE_VAPI_MSG_IDS_TCP_CHECK_API_JSON\
  vapi_msg_id_t vapi_msg_id_sfdp_tcp_session_dump;\
  vapi_msg_id_t vapi_msg_id_sfdp_tcp_session_details;


#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_address_family
#define __vapi_def_defined_vapi_enum_address_family
typedef enum {
  ADDRESS_IP4 = 0,
  ADDRESS_IP6 = 1,
} __attribute__((packed)) vapi_enum_address_family;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_address_family
#define __vapi_code_defined_vapi_enum_address_family
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_feature_location
#define __vapi_def_defined_vapi_enum_ip_feature_location
typedef enum {
  IP_API_FEATURE_INPUT = 0,
  IP_API_FEATURE_OUTPUT = 1,
  IP_API_FEATURE_LOCAL = 2,
  IP_API_FEATURE_PUNT = 3,
  IP_API_FEATURE_DROP = 4,
} __attribute__((packed)) vapi_enum_ip_feature_location;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_feature_location
#define __vapi_code_defined_vapi_enum_ip_feature_location
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_ecn
#define __vapi_def_defined_vapi_enum_ip_ecn
typedef enum {
  IP_API_ECN_NONE = 0,
  IP_API_ECN_ECT0 = 1,
  IP_API_ECN_ECT1 = 2,
  IP_API_ECN_CE = 3,
} __attribute__((packed)) vapi_enum_ip_ecn;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_ecn
#define __vapi_code_defined_vapi_enum_ip_ecn
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_dscp
#define __vapi_def_defined_vapi_enum_ip_dscp
typedef enum {
  IP_API_DSCP_CS0 = 0,
  IP_API_DSCP_CS1 = 8,
  IP_API_DSCP_AF11 = 10,
  IP_API_DSCP_AF12 = 12,
  IP_API_DSCP_AF13 = 14,
  IP_API_DSCP_CS2 = 16,
  IP_API_DSCP_AF21 = 18,
  IP_API_DSCP_AF22 = 20,
  IP_API_DSCP_AF23 = 22,
  IP_API_DSCP_CS3 = 24,
  IP_API_DSCP_AF31 = 26,
  IP_API_DSCP_AF32 = 28,
  IP_API_DSCP_AF33 = 30,
  IP_API_DSCP_CS4 = 32,
  IP_API_DSCP_AF41 = 34,
  IP_API_DSCP_AF42 = 36,
  IP_API_DSCP_AF43 = 38,
  IP_API_DSCP_CS5 = 40,
  IP_API_DSCP_EF = 46,
  IP_API_DSCP_CS6 = 48,
  IP_API_DSCP_CS7 = 50,
} __attribute__((packed)) vapi_enum_ip_dscp;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_dscp
#define __vapi_code_defined_vapi_enum_ip_dscp
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_ip_proto
#define __vapi_def_defined_vapi_enum_ip_proto
typedef enum {
  IP_API_PROTO_HOPOPT = 0,
  IP_API_PROTO_ICMP = 1,
  IP_API_PROTO_IGMP = 2,
  IP_API_PROTO_TCP = 6,
  IP_API_PROTO_UDP = 17,
  IP_API_PROTO_GRE = 47,
  IP_API_PROTO_ESP = 50,
  IP_API_PROTO_AH = 51,
  IP_API_PROTO_ICMP6 = 58,
  IP_API_PROTO_EIGRP = 88,
  IP_API_PROTO_OSPF = 89,
  IP_API_PROTO_SCTP = 132,
  IP_API_PROTO_RESERVED = 255,
} __attribute__((packed)) vapi_enum_ip_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_ip_proto
#define __vapi_code_defined_vapi_enum_ip_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_direction
#define __vapi_def_defined_vapi_enum_sfdp_session_direction
typedef enum {
  SFDP_API_FORWARD = 0,
  SFDP_API_REVERSE = 1,
} __attribute__((packed)) vapi_enum_sfdp_session_direction;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_direction
#define __vapi_code_defined_vapi_enum_sfdp_session_direction
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_state
#define __vapi_def_defined_vapi_enum_sfdp_session_state
typedef enum {
  SFDP_API_SESSION_STATE_FSOL = 0,
  SFDP_API_SESSION_STATE_ESTABLISHED = 1,
  SFDP_API_SESSION_STATE_TIME_WAIT = 2,
} __attribute__((packed)) vapi_enum_sfdp_session_state;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_state
#define __vapi_code_defined_vapi_enum_sfdp_session_state
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_sp_node
#define __vapi_def_defined_vapi_enum_sfdp_sp_node
typedef enum {
  SFDP_API_SP_NODE_IP4_REASS = 0,
  SFDP_API_SP_NODE_IP6_REASS = 1,
  SFDP_API_SP_NODE_IP4_UNKNOWN_PROTO = 2,
  SFDP_API_SP_NODE_IP6_UNKNOWN_PROTO = 3,
  SFDP_API_SP_NODE_IP4_ICMP4_ERROR = 4,
  SFDP_API_SP_NODE_IP6_ICMP6_ERROR = 5,
} __attribute__((packed)) vapi_enum_sfdp_sp_node;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_sp_node
#define __vapi_code_defined_vapi_enum_sfdp_sp_node
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_session_type
#define __vapi_def_defined_vapi_enum_sfdp_session_type
typedef enum {
  SFDP_API_SESSION_TYPE_IP4 = 0,
  SFDP_API_SESSION_TYPE_IP6 = 1,
  SFDP_API_SESSION_TYPE_USER = 2,
} __attribute__((packed)) vapi_enum_sfdp_session_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_session_type
#define __vapi_code_defined_vapi_enum_sfdp_session_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_timeout_type
#define __vapi_def_defined_vapi_enum_sfdp_timeout_type
typedef enum {
  SFDP_API_TIMEOUT_EMBRYONIC = 0,
  SFDP_API_TIMEOUT_ESTABLISHED = 1,
  SFDP_API_TIMEOUT_TCP_ESTABLISHED = 2,
  SFDP_API_TIMEOUT_SECURITY = 3,
} __attribute__((packed)) vapi_enum_sfdp_timeout_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_timeout_type
#define __vapi_code_defined_vapi_enum_sfdp_timeout_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sfdp_tcp_check_session_flags
#define __vapi_def_defined_vapi_enum_sfdp_tcp_check_session_flags
typedef enum {
  SFDP_API_TCP_CHECK_SESSION_FLAG_WAIT_FOR_RESP_SYN = 1,
  SFDP_API_TCP_CHECK_SESSION_FLAG_WAIT_FOR_INIT_ACK_TO_SYN = 2,
  SFDP_API_TCP_CHECK_SESSION_FLAG_WAIT_FOR_RESP_ACK_TO_SYN = 4,
  SFDP_API_TCP_CHECK_SESSION_FLAG_SEEN_FIN_INIT = 8,
  SFDP_API_TCP_CHECK_SESSION_FLAG_SEEN_FIN_RESP = 16,
  SFDP_API_TCP_CHECK_SESSION_FLAG_SEEN_ACK_TO_FIN_INIT = 32,
  SFDP_API_TCP_CHECK_SESSION_FLAG_SEEN_ACK_TO_FIN_RESP = 64,
  SFDP_API_TCP_CHECK_SESSION_FLAG_ESTABLISHED = 128,
  SFDP_API_TCP_CHECK_SESSION_FLAG_REMOVING = 256,
  SFDP_API_TCP_CHECK_SESSION_FLAG_BLOCKED = 512,
}  vapi_enum_sfdp_tcp_check_session_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sfdp_tcp_check_session_flags
#define __vapi_code_defined_vapi_enum_sfdp_tcp_check_session_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address
#define __vapi_def_defined_vapi_type_ip4_address
typedef u8 vapi_type_ip4_address[4];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address
#define __vapi_code_defined_vapi_type_ip4_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address
#define __vapi_def_defined_vapi_type_ip6_address
typedef u8 vapi_type_ip6_address[16];

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address
#define __vapi_code_defined_vapi_type_ip6_address
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_union_address_union
#define __vapi_def_defined_vapi_union_address_union
typedef union {
  vapi_type_ip4_address ip4;
  vapi_type_ip6_address ip6;
} vapi_union_address_union;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_union_address_union
#define __vapi_code_defined_vapi_union_address_union
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix_matcher
#define __vapi_def_defined_vapi_type_prefix_matcher
typedef struct __attribute__((__packed__)) {
  u8 le;
  u8 ge;
} vapi_type_prefix_matcher;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix_matcher
#define __vapi_code_defined_vapi_type_prefix_matcher
static inline void vapi_type_prefix_matcher_hton(vapi_type_prefix_matcher *msg)
{

}

static inline void vapi_type_prefix_matcher_ntoh(vapi_type_prefix_matcher *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_sfdp_service_name
#define __vapi_def_defined_vapi_type_sfdp_service_name
typedef struct __attribute__((__packed__)) {
  u8 data[32];
} vapi_type_sfdp_service_name;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_sfdp_service_name
#define __vapi_code_defined_vapi_type_sfdp_service_name
static inline void vapi_type_sfdp_service_name_hton(vapi_type_sfdp_service_name *msg)
{

}

static inline void vapi_type_sfdp_service_name_ntoh(vapi_type_sfdp_service_name *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address
#define __vapi_def_defined_vapi_type_address
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  vapi_union_address_union un;
} vapi_type_address;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address
#define __vapi_code_defined_vapi_type_address
static inline void vapi_type_address_hton(vapi_type_address *msg)
{

}

static inline void vapi_type_address_ntoh(vapi_type_address *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_prefix
#define __vapi_def_defined_vapi_type_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_address address;
  u8 len;
} vapi_type_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_prefix
#define __vapi_code_defined_vapi_type_prefix
static inline void vapi_type_prefix_hton(vapi_type_prefix *msg)
{

}

static inline void vapi_type_prefix_ntoh(vapi_type_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_and_mask
#define __vapi_def_defined_vapi_type_ip4_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address addr;
  vapi_type_ip4_address mask;
} vapi_type_ip4_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_and_mask
#define __vapi_code_defined_vapi_type_ip4_address_and_mask
static inline void vapi_type_ip4_address_and_mask_hton(vapi_type_ip4_address_and_mask *msg)
{

}

static inline void vapi_type_ip4_address_and_mask_ntoh(vapi_type_ip4_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_and_mask
#define __vapi_def_defined_vapi_type_ip6_address_and_mask
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address addr;
  vapi_type_ip6_address mask;
} vapi_type_ip6_address_and_mask;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_and_mask
#define __vapi_code_defined_vapi_type_ip6_address_and_mask
static inline void vapi_type_ip6_address_and_mask_hton(vapi_type_ip6_address_and_mask *msg)
{

}

static inline void vapi_type_ip6_address_and_mask_ntoh(vapi_type_ip6_address_and_mask *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_mprefix
#define __vapi_def_defined_vapi_type_mprefix
typedef struct __attribute__((__packed__)) {
  vapi_enum_address_family af;
  u16 grp_address_length;
  vapi_union_address_union grp_address;
  vapi_union_address_union src_address;
} vapi_type_mprefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_mprefix
#define __vapi_code_defined_vapi_type_mprefix
static inline void vapi_type_mprefix_hton(vapi_type_mprefix *msg)
{
  msg->grp_address_length = htobe16(msg->grp_address_length);
}

static inline void vapi_type_mprefix_ntoh(vapi_type_mprefix *msg)
{
  msg->grp_address_length = be16toh(msg->grp_address_length);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_prefix
#define __vapi_def_defined_vapi_type_ip6_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip6_address address;
  u8 len;
} vapi_type_ip6_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_prefix
#define __vapi_code_defined_vapi_type_ip6_prefix
static inline void vapi_type_ip6_prefix_hton(vapi_type_ip6_prefix *msg)
{

}

static inline void vapi_type_ip6_prefix_ntoh(vapi_type_ip6_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_prefix
#define __vapi_def_defined_vapi_type_ip4_prefix
typedef struct __attribute__((__packed__)) {
  vapi_type_ip4_address address;
  u8 len;
} vapi_type_ip4_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_prefix
#define __vapi_code_defined_vapi_type_ip4_prefix
static inline void vapi_type_ip4_prefix_hton(vapi_type_ip4_prefix *msg)
{

}

static inline void vapi_type_ip4_prefix_ntoh(vapi_type_ip4_prefix *msg)
{

}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_sfdp_session_key
#define __vapi_def_defined_vapi_type_sfdp_session_key
typedef struct __attribute__((__packed__)) {
  u32 context_id;
  vapi_type_address init_addr;
  u16 init_port;
  vapi_type_address resp_addr;
  u16 resp_port;
} vapi_type_sfdp_session_key;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_sfdp_session_key
#define __vapi_code_defined_vapi_type_sfdp_session_key
static inline void vapi_type_sfdp_session_key_hton(vapi_type_sfdp_session_key *msg)
{
  msg->context_id = htobe32(msg->context_id);
  msg->init_port = htobe16(msg->init_port);
  msg->resp_port = htobe16(msg->resp_port);
}

static inline void vapi_type_sfdp_session_key_ntoh(vapi_type_sfdp_session_key *msg)
{
  msg->context_id = be32toh(msg->context_id);
  msg->init_port = be16toh(msg->init_port);
  msg->resp_port = be16toh(msg->resp_port);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_address_with_prefix
#define __vapi_def_defined_vapi_type_address_with_prefix
typedef vapi_type_prefix vapi_type_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_address_with_prefix
#define __vapi_code_defined_vapi_type_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip4_address_with_prefix
#define __vapi_def_defined_vapi_type_ip4_address_with_prefix
typedef vapi_type_ip4_prefix vapi_type_ip4_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip4_address_with_prefix
#define __vapi_code_defined_vapi_type_ip4_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_ip6_address_with_prefix
#define __vapi_def_defined_vapi_type_ip6_address_with_prefix
typedef vapi_type_ip6_prefix vapi_type_ip6_address_with_prefix;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_ip6_address_with_prefix
#define __vapi_code_defined_vapi_type_ip6_address_with_prefix
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tcp_session_details
#define __vapi_def_defined_vapi_msg_sfdp_tcp_session_details
typedef struct __attribute__ ((__packed__)) {
  u64 session_id;
  u32 thread_index;
  u32 tenant_id;
  u32 session_idx;
  vapi_enum_sfdp_session_type session_type;
  vapi_enum_sfdp_tcp_check_session_flags flags;
  u8 n_keys;
  vapi_type_sfdp_session_key keys[0]; 
} vapi_payload_sfdp_tcp_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sfdp_tcp_session_details payload;
} vapi_msg_sfdp_tcp_session_details;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tcp_session_details
#define __vapi_code_defined_vapi_msg_sfdp_tcp_session_details
static inline void vapi_msg_sfdp_tcp_session_details_payload_hton(vapi_payload_sfdp_tcp_session_details *payload)
{
  payload->session_id = htobe64(payload->session_id);
  payload->thread_index = htobe32(payload->thread_index);
  payload->tenant_id = htobe32(payload->tenant_id);
  payload->session_idx = htobe32(payload->session_idx);
  payload->flags = (vapi_enum_sfdp_tcp_check_session_flags)htobe32(payload->flags);
  do { unsigned i; for (i = 0; i < payload->n_keys; ++i) { vapi_type_sfdp_session_key_hton(&payload->keys[i]); } } while(0);
}

static inline void vapi_msg_sfdp_tcp_session_details_payload_ntoh(vapi_payload_sfdp_tcp_session_details *payload)
{
  payload->session_id = be64toh(payload->session_id);
  payload->thread_index = be32toh(payload->thread_index);
  payload->tenant_id = be32toh(payload->tenant_id);
  payload->session_idx = be32toh(payload->session_idx);
  payload->flags = (vapi_enum_sfdp_tcp_check_session_flags)be32toh(payload->flags);
  do { unsigned i; for (i = 0; i < payload->n_keys; ++i) { vapi_type_sfdp_session_key_ntoh(&payload->keys[i]); } } while(0);
}

static inline void vapi_msg_sfdp_tcp_session_details_hton(vapi_msg_sfdp_tcp_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tcp_session_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sfdp_tcp_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_sfdp_tcp_session_details_ntoh(vapi_msg_sfdp_tcp_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tcp_session_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sfdp_tcp_session_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_sfdp_tcp_session_details_msg_size(vapi_msg_sfdp_tcp_session_details *msg)
{
  return sizeof(*msg) + sizeof(msg->payload.keys[0]) * msg->payload.n_keys;
}

static inline int vapi_verify_sfdp_tcp_session_details_msg_size(vapi_msg_sfdp_tcp_session_details *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tcp_session_details) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tcp_session_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tcp_session_details));
      return -1;
    }
  if (vapi_calc_sfdp_tcp_session_details_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tcp_session_details' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tcp_session_details_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_sfdp_tcp_session_details()
{
  static const char name[] = "sfdp_tcp_session_details";
  static const char name_with_crc[] = "sfdp_tcp_session_details_4bd58888";
  static vapi_message_desc_t __vapi_metadata_sfdp_tcp_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sfdp_tcp_session_details, payload),
    (verify_msg_size_fn_t)vapi_verify_sfdp_tcp_session_details_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tcp_session_details_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tcp_session_details_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tcp_session_details = vapi_register_msg(&__vapi_metadata_sfdp_tcp_session_details);
  VAPI_DBG("Assigned msg id %d to sfdp_tcp_session_details", vapi_msg_id_sfdp_tcp_session_details);
}

static inline void vapi_set_vapi_msg_sfdp_tcp_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sfdp_tcp_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sfdp_tcp_session_details, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_sfdp_tcp_session_dump
#define __vapi_def_defined_vapi_msg_sfdp_tcp_session_dump
typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_sfdp_tcp_session_dump;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_sfdp_tcp_session_dump
#define __vapi_code_defined_vapi_msg_sfdp_tcp_session_dump
static inline void vapi_msg_sfdp_tcp_session_dump_hton(vapi_msg_sfdp_tcp_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tcp_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_sfdp_tcp_session_dump_ntoh(vapi_msg_sfdp_tcp_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sfdp_tcp_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_sfdp_tcp_session_dump_msg_size(vapi_msg_sfdp_tcp_session_dump *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_sfdp_tcp_session_dump_msg_size(vapi_msg_sfdp_tcp_session_dump *msg, uword buf_size)
{
  if (sizeof(vapi_msg_sfdp_tcp_session_dump) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tcp_session_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_sfdp_tcp_session_dump));
      return -1;
    }
  if (vapi_calc_sfdp_tcp_session_dump_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'sfdp_tcp_session_dump' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_sfdp_tcp_session_dump_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_sfdp_tcp_session_dump* vapi_alloc_sfdp_tcp_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_sfdp_tcp_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_sfdp_tcp_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sfdp_tcp_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sfdp_tcp_session_dump);

  return msg;
}

static inline vapi_error_e vapi_sfdp_tcp_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_sfdp_tcp_session_dump *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_sfdp_tcp_session_details *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sfdp_tcp_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_sfdp_tcp_session_details, VAPI_REQUEST_DUMP,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sfdp_tcp_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_sfdp_tcp_session_dump()
{
  static const char name[] = "sfdp_tcp_session_dump";
  static const char name_with_crc[] = "sfdp_tcp_session_dump_51077d14";
  static vapi_message_desc_t __vapi_metadata_sfdp_tcp_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    VAPI_INVALID_MSG_ID,
    (verify_msg_size_fn_t)vapi_verify_sfdp_tcp_session_dump_msg_size,
    (generic_swap_fn_t)vapi_msg_sfdp_tcp_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_sfdp_tcp_session_dump_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_sfdp_tcp_session_dump = vapi_register_msg(&__vapi_metadata_sfdp_tcp_session_dump);
  VAPI_DBG("Assigned msg id %d to sfdp_tcp_session_dump", vapi_msg_id_sfdp_tcp_session_dump);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

#ifndef __included_af_xdp_api_json
#define __included_af_xdp_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#ifndef __vl_api_string_swap_fns_defined__
#define __vl_api_string_swap_fns_defined__

#include <vlibapi/api_types.h>

static inline void vl_api_string_t_hton(vl_api_string_t *msg)
{
  msg->length = htobe32(msg->length);
}

static inline void vl_api_string_t_ntoh(vl_api_string_t *msg)
{
  msg->length = be32toh(msg->length);
}

#endif //__vl_api_string_swap_fns_defined__
#include <vapi/vlib.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_af_xdp_create_v3;
extern vapi_msg_id_t vapi_msg_id_af_xdp_create_v3_reply;
extern vapi_msg_id_t vapi_msg_id_af_xdp_delete;
extern vapi_msg_id_t vapi_msg_id_af_xdp_delete_reply;

#define DEFINE_VAPI_MSG_IDS_AF_XDP_API_JSON\
  vapi_msg_id_t vapi_msg_id_af_xdp_create_v3;\
  vapi_msg_id_t vapi_msg_id_af_xdp_create_v3_reply;\
  vapi_msg_id_t vapi_msg_id_af_xdp_delete;\
  vapi_msg_id_t vapi_msg_id_af_xdp_delete_reply;


#ifndef __vapi_def_defined_vapi_enum_if_status_flags
#define __vapi_def_defined_vapi_enum_if_status_flags
typedef enum {
  IF_STATUS_API_FLAG_ADMIN_UP = 1,
  IF_STATUS_API_FLAG_LINK_UP = 2,
}  vapi_enum_if_status_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_if_status_flags
#define __vapi_code_defined_vapi_enum_if_status_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_mtu_proto
#define __vapi_def_defined_vapi_enum_mtu_proto
typedef enum {
  MTU_PROTO_API_L3 = 0,
  MTU_PROTO_API_IP4 = 1,
  MTU_PROTO_API_IP6 = 2,
  MTU_PROTO_API_MPLS = 3,
}  vapi_enum_mtu_proto;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_mtu_proto
#define __vapi_code_defined_vapi_enum_mtu_proto
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_link_duplex
#define __vapi_def_defined_vapi_enum_link_duplex
typedef enum {
  LINK_DUPLEX_API_UNKNOWN = 0,
  LINK_DUPLEX_API_HALF = 1,
  LINK_DUPLEX_API_FULL = 2,
}  vapi_enum_link_duplex;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_link_duplex
#define __vapi_code_defined_vapi_enum_link_duplex
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_sub_if_flags
#define __vapi_def_defined_vapi_enum_sub_if_flags
typedef enum {
  SUB_IF_API_FLAG_NO_TAGS = 1,
  SUB_IF_API_FLAG_ONE_TAG = 2,
  SUB_IF_API_FLAG_TWO_TAGS = 4,
  SUB_IF_API_FLAG_DOT1AD = 8,
  SUB_IF_API_FLAG_EXACT_MATCH = 16,
  SUB_IF_API_FLAG_DEFAULT = 32,
  SUB_IF_API_FLAG_OUTER_VLAN_ID_ANY = 64,
  SUB_IF_API_FLAG_INNER_VLAN_ID_ANY = 128,
  SUB_IF_API_FLAG_MASK_VNET = 254,
  SUB_IF_API_FLAG_DOT1AH = 256,
}  vapi_enum_sub_if_flags;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_sub_if_flags
#define __vapi_code_defined_vapi_enum_sub_if_flags
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_rx_mode
#define __vapi_def_defined_vapi_enum_rx_mode
typedef enum {
  RX_MODE_API_UNKNOWN = 0,
  RX_MODE_API_POLLING = 1,
  RX_MODE_API_INTERRUPT = 2,
  RX_MODE_API_ADAPTIVE = 3,
  RX_MODE_API_DEFAULT = 4,
}  vapi_enum_rx_mode;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_rx_mode
#define __vapi_code_defined_vapi_enum_rx_mode
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_if_type
#define __vapi_def_defined_vapi_enum_if_type
typedef enum {
  IF_API_TYPE_HARDWARE = 0,
  IF_API_TYPE_SUB = 1,
  IF_API_TYPE_P2P = 2,
  IF_API_TYPE_PIPE = 3,
}  vapi_enum_if_type;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_if_type
#define __vapi_code_defined_vapi_enum_if_type
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_direction
#define __vapi_def_defined_vapi_enum_direction
typedef enum {
  RX = 0,
  TX = 1,
} __attribute__((packed)) vapi_enum_direction;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_direction
#define __vapi_code_defined_vapi_enum_direction
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_af_xdp_mode
#define __vapi_def_defined_vapi_enum_af_xdp_mode
typedef enum {
  AF_XDP_API_MODE_AUTO = 0,
  AF_XDP_API_MODE_COPY = 1,
  AF_XDP_API_MODE_ZERO_COPY = 2,
}  vapi_enum_af_xdp_mode;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_af_xdp_mode
#define __vapi_code_defined_vapi_enum_af_xdp_mode
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_enum_af_xdp_flag
#define __vapi_def_defined_vapi_enum_af_xdp_flag
typedef enum {
  AF_XDP_API_FLAGS_NO_SYSCALL_LOCK = 1,
  AF_XDP_API_FLAGS_MAC_REUSE = 2,
  AF_XDP_API_FLAGS_MULTI_BUFFER = 4,
} __attribute__((packed)) vapi_enum_af_xdp_flag;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_enum_af_xdp_flag
#define __vapi_code_defined_vapi_enum_af_xdp_flag
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_type_interface_index
#define __vapi_def_defined_vapi_type_interface_index
typedef u32 vapi_type_interface_index;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_type_interface_index
#define __vapi_code_defined_vapi_type_interface_index
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_af_xdp_create_v3_reply
#define __vapi_def_defined_vapi_msg_af_xdp_create_v3_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  vapi_type_interface_index sw_if_index; 
} vapi_payload_af_xdp_create_v3_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_af_xdp_create_v3_reply payload;
} vapi_msg_af_xdp_create_v3_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_af_xdp_create_v3_reply
#define __vapi_code_defined_vapi_msg_af_xdp_create_v3_reply
static inline void vapi_msg_af_xdp_create_v3_reply_payload_hton(vapi_payload_af_xdp_create_v3_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_af_xdp_create_v3_reply_payload_ntoh(vapi_payload_af_xdp_create_v3_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline void vapi_msg_af_xdp_create_v3_reply_hton(vapi_msg_af_xdp_create_v3_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_create_v3_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_af_xdp_create_v3_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_af_xdp_create_v3_reply_ntoh(vapi_msg_af_xdp_create_v3_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_create_v3_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_af_xdp_create_v3_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_af_xdp_create_v3_reply_msg_size(vapi_msg_af_xdp_create_v3_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_af_xdp_create_v3_reply_msg_size(vapi_msg_af_xdp_create_v3_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_af_xdp_create_v3_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_create_v3_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_af_xdp_create_v3_reply));
      return -1;
    }
  if (vapi_calc_af_xdp_create_v3_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_create_v3_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_af_xdp_create_v3_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_af_xdp_create_v3_reply()
{
  static const char name[] = "af_xdp_create_v3_reply";
  static const char name_with_crc[] = "af_xdp_create_v3_reply_5383d31f";
  static vapi_message_desc_t __vapi_metadata_af_xdp_create_v3_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_af_xdp_create_v3_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_af_xdp_create_v3_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_af_xdp_create_v3_reply_hton,
    (generic_swap_fn_t)vapi_msg_af_xdp_create_v3_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_af_xdp_create_v3_reply = vapi_register_msg(&__vapi_metadata_af_xdp_create_v3_reply);
  VAPI_DBG("Assigned msg id %d to af_xdp_create_v3_reply", vapi_msg_id_af_xdp_create_v3_reply);
}

static inline void vapi_set_vapi_msg_af_xdp_create_v3_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_af_xdp_create_v3_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_af_xdp_create_v3_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_af_xdp_create_v3
#define __vapi_def_defined_vapi_msg_af_xdp_create_v3
typedef struct __attribute__ ((__packed__)) {
  u8 host_if[64];
  u8 name[64];
  u16 rxq_num;
  u16 rxq_size;
  u16 txq_size;
  vapi_enum_af_xdp_mode mode;
  vapi_enum_af_xdp_flag flags;
  u8 prog[256];
  u8 netns[64]; 
} vapi_payload_af_xdp_create_v3;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_af_xdp_create_v3 payload;
} vapi_msg_af_xdp_create_v3;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_af_xdp_create_v3
#define __vapi_code_defined_vapi_msg_af_xdp_create_v3
static inline void vapi_msg_af_xdp_create_v3_payload_hton(vapi_payload_af_xdp_create_v3 *payload)
{
  payload->rxq_num = htobe16(payload->rxq_num);
  payload->rxq_size = htobe16(payload->rxq_size);
  payload->txq_size = htobe16(payload->txq_size);
  payload->mode = (vapi_enum_af_xdp_mode)htobe32(payload->mode);
}

static inline void vapi_msg_af_xdp_create_v3_payload_ntoh(vapi_payload_af_xdp_create_v3 *payload)
{
  payload->rxq_num = be16toh(payload->rxq_num);
  payload->rxq_size = be16toh(payload->rxq_size);
  payload->txq_size = be16toh(payload->txq_size);
  payload->mode = (vapi_enum_af_xdp_mode)be32toh(payload->mode);
}

static inline void vapi_msg_af_xdp_create_v3_hton(vapi_msg_af_xdp_create_v3 *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_create_v3'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_af_xdp_create_v3_payload_hton(&msg->payload);
}

static inline void vapi_msg_af_xdp_create_v3_ntoh(vapi_msg_af_xdp_create_v3 *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_create_v3'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_af_xdp_create_v3_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_af_xdp_create_v3_msg_size(vapi_msg_af_xdp_create_v3 *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_af_xdp_create_v3_msg_size(vapi_msg_af_xdp_create_v3 *msg, uword buf_size)
{
  if (sizeof(vapi_msg_af_xdp_create_v3) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_create_v3' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_af_xdp_create_v3));
      return -1;
    }
  if (vapi_calc_af_xdp_create_v3_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_create_v3' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_af_xdp_create_v3_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_af_xdp_create_v3* vapi_alloc_af_xdp_create_v3(struct vapi_ctx_s *ctx)
{
  vapi_msg_af_xdp_create_v3 *msg = NULL;
  const size_t size = sizeof(vapi_msg_af_xdp_create_v3);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_af_xdp_create_v3*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_af_xdp_create_v3);

  return msg;
}

static inline vapi_error_e vapi_af_xdp_create_v3(struct vapi_ctx_s *ctx,
  vapi_msg_af_xdp_create_v3 *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_af_xdp_create_v3_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_af_xdp_create_v3_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_af_xdp_create_v3_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_af_xdp_create_v3_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_af_xdp_create_v3()
{
  static const char name[] = "af_xdp_create_v3";
  static const char name_with_crc[] = "af_xdp_create_v3_cf4b1827";
  static vapi_message_desc_t __vapi_metadata_af_xdp_create_v3 = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_af_xdp_create_v3, payload),
    (verify_msg_size_fn_t)vapi_verify_af_xdp_create_v3_msg_size,
    (generic_swap_fn_t)vapi_msg_af_xdp_create_v3_hton,
    (generic_swap_fn_t)vapi_msg_af_xdp_create_v3_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_af_xdp_create_v3 = vapi_register_msg(&__vapi_metadata_af_xdp_create_v3);
  VAPI_DBG("Assigned msg id %d to af_xdp_create_v3", vapi_msg_id_af_xdp_create_v3);
}
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_af_xdp_delete_reply
#define __vapi_def_defined_vapi_msg_af_xdp_delete_reply
typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_af_xdp_delete_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_af_xdp_delete_reply payload;
} vapi_msg_af_xdp_delete_reply;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_af_xdp_delete_reply
#define __vapi_code_defined_vapi_msg_af_xdp_delete_reply
static inline void vapi_msg_af_xdp_delete_reply_payload_hton(vapi_payload_af_xdp_delete_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_af_xdp_delete_reply_payload_ntoh(vapi_payload_af_xdp_delete_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline void vapi_msg_af_xdp_delete_reply_hton(vapi_msg_af_xdp_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_delete_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_af_xdp_delete_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_af_xdp_delete_reply_ntoh(vapi_msg_af_xdp_delete_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_delete_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_af_xdp_delete_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_af_xdp_delete_reply_msg_size(vapi_msg_af_xdp_delete_reply *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_af_xdp_delete_reply_msg_size(vapi_msg_af_xdp_delete_reply *msg, uword buf_size)
{
  if (sizeof(vapi_msg_af_xdp_delete_reply) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_af_xdp_delete_reply));
      return -1;
    }
  if (vapi_calc_af_xdp_delete_reply_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_delete_reply' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_af_xdp_delete_reply_msg_size(msg));
      return -1;
    }
  return 0;
}

static void __attribute__((constructor)) __vapi_constructor_af_xdp_delete_reply()
{
  static const char name[] = "af_xdp_delete_reply";
  static const char name_with_crc[] = "af_xdp_delete_reply_e8d4e804";
  static vapi_message_desc_t __vapi_metadata_af_xdp_delete_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_af_xdp_delete_reply, payload),
    (verify_msg_size_fn_t)vapi_verify_af_xdp_delete_reply_msg_size,
    (generic_swap_fn_t)vapi_msg_af_xdp_delete_reply_hton,
    (generic_swap_fn_t)vapi_msg_af_xdp_delete_reply_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_af_xdp_delete_reply = vapi_register_msg(&__vapi_metadata_af_xdp_delete_reply);
  VAPI_DBG("Assigned msg id %d to af_xdp_delete_reply", vapi_msg_id_af_xdp_delete_reply);
}

static inline void vapi_set_vapi_msg_af_xdp_delete_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_af_xdp_delete_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_af_xdp_delete_reply, (vapi_event_cb)callback, callback_ctx);
};
#endif
#endif
#endif

#ifndef __vapi_def_defined_vapi_msg_af_xdp_delete
#define __vapi_def_defined_vapi_msg_af_xdp_delete
typedef struct __attribute__ ((__packed__)) {
  vapi_type_interface_index sw_if_index; 
} vapi_payload_af_xdp_delete;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_af_xdp_delete payload;
} vapi_msg_af_xdp_delete;

#ifndef VAPI_EMIT_TYPES_ONLY
#ifndef __vapi_code_defined_vapi_msg_af_xdp_delete
#define __vapi_code_defined_vapi_msg_af_xdp_delete
static inline void vapi_msg_af_xdp_delete_payload_hton(vapi_payload_af_xdp_delete *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_af_xdp_delete_payload_ntoh(vapi_payload_af_xdp_delete *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline void vapi_msg_af_xdp_delete_hton(vapi_msg_af_xdp_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_delete'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_af_xdp_delete_payload_hton(&msg->payload);
}

static inline void vapi_msg_af_xdp_delete_ntoh(vapi_msg_af_xdp_delete *msg)
{
  VAPI_DBG("Swapping `vapi_msg_af_xdp_delete'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_af_xdp_delete_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_af_xdp_delete_msg_size(vapi_msg_af_xdp_delete *msg)
{
  return sizeof(*msg);
}

static inline int vapi_verify_af_xdp_delete_msg_size(vapi_msg_af_xdp_delete *msg, uword buf_size)
{
  if (sizeof(vapi_msg_af_xdp_delete) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        sizeof(vapi_msg_af_xdp_delete));
      return -1;
    }
  if (vapi_calc_af_xdp_delete_msg_size(msg) > buf_size)
    {
      VAPI_ERR("Truncated 'af_xdp_delete' msg received, received %lu"
        "bytes, expected %lu bytes.", buf_size,
        vapi_calc_af_xdp_delete_msg_size(msg));
      return -1;
    }
  return 0;
}

static inline vapi_msg_af_xdp_delete* vapi_alloc_af_xdp_delete(struct vapi_ctx_s *ctx)
{
  vapi_msg_af_xdp_delete *msg = NULL;
  const size_t size = sizeof(vapi_msg_af_xdp_delete);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_af_xdp_delete*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_af_xdp_delete);

  return msg;
}

static inline vapi_error_e vapi_af_xdp_delete(struct vapi_ctx_s *ctx,
  vapi_msg_af_xdp_delete *msg,
  vapi_error_e (*reply_callback)(struct vapi_ctx_s *ctx,
                                 void *callback_ctx,
                                 vapi_error_e rv,
                                 bool is_last,
                                 vapi_payload_af_xdp_delete_reply *reply),
  void *reply_callback_ctx)
{
  if (!msg || !reply_callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_get_request_count(ctx) + 1 > vapi_get_max_request_count(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_af_xdp_delete_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, vapi_msg_id_af_xdp_delete_reply, VAPI_REQUEST_REG,
                       (vapi_cb_t)reply_callback, reply_callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_af_xdp_delete_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static void __attribute__((constructor)) __vapi_constructor_af_xdp_delete()
{
  static const char name[] = "af_xdp_delete";
  static const char name_with_crc[] = "af_xdp_delete_f9e6675e";
  static vapi_message_desc_t __vapi_metadata_af_xdp_delete = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_af_xdp_delete, payload),
    (verify_msg_size_fn_t)vapi_verify_af_xdp_delete_msg_size,
    (generic_swap_fn_t)vapi_msg_af_xdp_delete_hton,
    (generic_swap_fn_t)vapi_msg_af_xdp_delete_ntoh,
    VAPI_INVALID_MSG_ID,
  };

  vapi_msg_id_af_xdp_delete = vapi_register_msg(&__vapi_metadata_af_xdp_delete);
  VAPI_DBG("Assigned msg id %d to af_xdp_delete", vapi_msg_id_af_xdp_delete);
}
#endif
#endif
#endif


#ifdef __cplusplus
}
#endif

#endif

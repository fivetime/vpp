/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2015 Cisco and/or its affiliates.
 */

#ifndef included_vnet_api_errno_h
#define included_vnet_api_errno_h

#include <stdarg.h>
#include <vppinfra/types.h>
#include <vppinfra/format.h>
#include <vnet/error.h>

#define foreach_vnet_api_error foreach_vnet_error

typedef enum
{
#define _(a,b,c) VNET_API_ERROR_##a = (b),
  foreach_vnet_api_error
#undef _
    VNET_API_N_ERROR,
} vnet_api_error_t;

format_function_t format_vnet_api_errno;

static_always_inline vnet_api_error_t
vnet_api_error (clib_error_t *err)
{
  if (err == 0)
    return 0;
  if (err->code >= 0)
    return VNET_API_ERROR_BUG;
  return err->code;
}

static_always_inline vnet_api_error_t
vnet_get_api_error_and_free (clib_error_t *err)
{
  vnet_api_error_t rv = vnet_api_error (err);
  clib_error_free (err);
  return rv;
}

#endif /* included_vnet_api_errno_h */

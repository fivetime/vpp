/* SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018 Cisco and/or its affiliates.
 */

#ifndef SRC_VLIBMEMORY_MEMORY_CLIENT_H_
#define SRC_VLIBMEMORY_MEMORY_CLIENT_H_

#include <vlibapi/memory_shared.h>
#include <setjmp.h>

/*
 * Exported so folks can code a working custom rx_pthread function
 */
typedef struct
{
  u8 rx_thread_jmpbuf_valid;
  u8 connected_to_vlib;
  jmp_buf rx_thread_jmpbuf;
  pthread_t rx_thread_handle;
  /* Plugin message base lookup scheme */
  volatile u8 first_msg_id_reply_ready;
  u16 first_msg_id_reply;
} memory_client_main_t;

extern memory_client_main_t memory_client_main;
extern __thread memory_client_main_t *my_memory_client_main;

int vl_client_connect (const char *name, int ctx_quota, int input_queue_size);
void vl_client_send_disconnect (u8 do_cleanup);
int vl_client_disconnect (void);
int vl_client_api_map (const char *region_name);
void vl_client_api_unmap (void);
void vl_client_disconnect_from_vlib (void);
void vl_client_disconnect_from_vlib_no_unmap (void);
int vl_client_connect_to_vlib (const char *svm_name, const char *client_name,
			       int rx_queue_size);
int vl_client_connect_to_vlib_thread_fn (const char *svm_name,
					 const char *client_name,
					 int rx_queue_size,
					 void *(*)(void *), void *);
int vl_client_connect_to_vlib_no_rx_pthread (const char *svm_name,
					     const char *client_name,
					     int rx_queue_size);
int vl_client_connect_to_vlib_no_map (const char *svm_name,
				      const char *client_name,
				      int rx_queue_size);
int vl_client_connect_to_vlib_no_rx_pthread_no_map (const char *svm_name,
						    const char *client_name,
						    int rx_queue_size);
void vl_client_install_client_message_handlers (void);
u8 vl_mem_client_is_connected (void);
void vl_client_stop_rx_thread (svm_queue_t *vl_input_queue);

always_inline memory_client_main_t *
vlibapi_get_memory_client_main (void)
{
  ASSERT (my_memory_client_main);
  return my_memory_client_main;
}

always_inline void
vlibapi_set_memory_client_main (memory_client_main_t * mm)
{
  my_memory_client_main = mm;
}

#endif /* SRC_VLIBMEMORY_MEMORY_CLIENT_H_ */

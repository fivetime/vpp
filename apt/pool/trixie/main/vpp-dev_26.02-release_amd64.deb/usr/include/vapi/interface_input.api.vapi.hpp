#ifndef __included_hpp_interface_input_api_json
#define __included_hpp_interface_input_api_json

#include <vapi/vapi.hpp>
#include <vapi/interface_input.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_interface_input_set>(vapi_msg_sfdp_interface_input_set *msg)
{
  vapi_msg_sfdp_interface_input_set_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_interface_input_set>(vapi_msg_sfdp_interface_input_set *msg)
{
  vapi_msg_sfdp_interface_input_set_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_interface_input_set>()
{
  return ::vapi_msg_id_sfdp_interface_input_set; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_interface_input_set>>()
{
  return ::vapi_msg_id_sfdp_interface_input_set; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_interface_input_set()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_interface_input_set>(vapi_msg_id_sfdp_interface_input_set);
}

template <> inline vapi_msg_sfdp_interface_input_set* vapi_alloc<vapi_msg_sfdp_interface_input_set>(Connection &con)
{
  vapi_msg_sfdp_interface_input_set* result = vapi_alloc_sfdp_interface_input_set(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_interface_input_set>;

template class Request<vapi_msg_sfdp_interface_input_set, vapi_msg_sfdp_interface_input_set_reply>;

using Sfdp_interface_input_set = Request<vapi_msg_sfdp_interface_input_set, vapi_msg_sfdp_interface_input_set_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_interface_input_set_reply>(vapi_msg_sfdp_interface_input_set_reply *msg)
{
  vapi_msg_sfdp_interface_input_set_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_interface_input_set_reply>(vapi_msg_sfdp_interface_input_set_reply *msg)
{
  vapi_msg_sfdp_interface_input_set_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_interface_input_set_reply>()
{
  return ::vapi_msg_id_sfdp_interface_input_set_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_interface_input_set_reply>>()
{
  return ::vapi_msg_id_sfdp_interface_input_set_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_interface_input_set_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_interface_input_set_reply>(vapi_msg_id_sfdp_interface_input_set_reply);
}

template class Msg<vapi_msg_sfdp_interface_input_set_reply>;

using Sfdp_interface_input_set_reply = Msg<vapi_msg_sfdp_interface_input_set_reply>;
}
#endif

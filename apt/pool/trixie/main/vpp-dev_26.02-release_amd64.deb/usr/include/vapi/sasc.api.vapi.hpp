#ifndef __included_hpp_sasc_api_json
#define __included_hpp_sasc_api_json

#include <vapi/vapi.hpp>
#include <vapi/sasc.api.vapi.h>

namespace vapi {

}
#endif

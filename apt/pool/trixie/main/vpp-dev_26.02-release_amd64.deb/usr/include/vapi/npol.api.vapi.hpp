#ifndef __included_hpp_npol_api_json
#define __included_hpp_npol_api_json

#include <vapi/vapi.hpp>
#include <vapi/npol.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_npol_get_version>(vapi_msg_npol_get_version *msg)
{
  vapi_msg_npol_get_version_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_get_version>(vapi_msg_npol_get_version *msg)
{
  vapi_msg_npol_get_version_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_get_version>()
{
  return ::vapi_msg_id_npol_get_version; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_get_version>>()
{
  return ::vapi_msg_id_npol_get_version; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_get_version()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_get_version>(vapi_msg_id_npol_get_version);
}

template <> inline vapi_msg_npol_get_version* vapi_alloc<vapi_msg_npol_get_version>(Connection &con)
{
  vapi_msg_npol_get_version* result = vapi_alloc_npol_get_version(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_get_version>;

template class Request<vapi_msg_npol_get_version, vapi_msg_npol_get_version_reply>;

using Npol_get_version = Request<vapi_msg_npol_get_version, vapi_msg_npol_get_version_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_get_version_reply>(vapi_msg_npol_get_version_reply *msg)
{
  vapi_msg_npol_get_version_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_get_version_reply>(vapi_msg_npol_get_version_reply *msg)
{
  vapi_msg_npol_get_version_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_get_version_reply>()
{
  return ::vapi_msg_id_npol_get_version_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_get_version_reply>>()
{
  return ::vapi_msg_id_npol_get_version_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_get_version_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_get_version_reply>(vapi_msg_id_npol_get_version_reply);
}

template class Msg<vapi_msg_npol_get_version_reply>;

using Npol_get_version_reply = Msg<vapi_msg_npol_get_version_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_create>(vapi_msg_npol_ipset_create *msg)
{
  vapi_msg_npol_ipset_create_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_create>(vapi_msg_npol_ipset_create *msg)
{
  vapi_msg_npol_ipset_create_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_create>()
{
  return ::vapi_msg_id_npol_ipset_create; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_create>>()
{
  return ::vapi_msg_id_npol_ipset_create; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_create()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_create>(vapi_msg_id_npol_ipset_create);
}

template <> inline vapi_msg_npol_ipset_create* vapi_alloc<vapi_msg_npol_ipset_create>(Connection &con)
{
  vapi_msg_npol_ipset_create* result = vapi_alloc_npol_ipset_create(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_ipset_create>;

template class Request<vapi_msg_npol_ipset_create, vapi_msg_npol_ipset_create_reply>;

using Npol_ipset_create = Request<vapi_msg_npol_ipset_create, vapi_msg_npol_ipset_create_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_create_reply>(vapi_msg_npol_ipset_create_reply *msg)
{
  vapi_msg_npol_ipset_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_create_reply>(vapi_msg_npol_ipset_create_reply *msg)
{
  vapi_msg_npol_ipset_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_create_reply>()
{
  return ::vapi_msg_id_npol_ipset_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_create_reply>>()
{
  return ::vapi_msg_id_npol_ipset_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_create_reply>(vapi_msg_id_npol_ipset_create_reply);
}

template class Msg<vapi_msg_npol_ipset_create_reply>;

using Npol_ipset_create_reply = Msg<vapi_msg_npol_ipset_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_add_del_members>(vapi_msg_npol_ipset_add_del_members *msg)
{
  vapi_msg_npol_ipset_add_del_members_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_add_del_members>(vapi_msg_npol_ipset_add_del_members *msg)
{
  vapi_msg_npol_ipset_add_del_members_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_add_del_members>()
{
  return ::vapi_msg_id_npol_ipset_add_del_members; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_add_del_members>>()
{
  return ::vapi_msg_id_npol_ipset_add_del_members; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_add_del_members()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_add_del_members>(vapi_msg_id_npol_ipset_add_del_members);
}

template <> inline vapi_msg_npol_ipset_add_del_members* vapi_alloc<vapi_msg_npol_ipset_add_del_members, size_t>(Connection &con, size_t _members_array_size)
{
  vapi_msg_npol_ipset_add_del_members* result = vapi_alloc_npol_ipset_add_del_members(con.vapi_ctx, _members_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_ipset_add_del_members>;

template class Request<vapi_msg_npol_ipset_add_del_members, vapi_msg_npol_ipset_add_del_members_reply, size_t>;

using Npol_ipset_add_del_members = Request<vapi_msg_npol_ipset_add_del_members, vapi_msg_npol_ipset_add_del_members_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_add_del_members_reply>(vapi_msg_npol_ipset_add_del_members_reply *msg)
{
  vapi_msg_npol_ipset_add_del_members_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_add_del_members_reply>(vapi_msg_npol_ipset_add_del_members_reply *msg)
{
  vapi_msg_npol_ipset_add_del_members_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_add_del_members_reply>()
{
  return ::vapi_msg_id_npol_ipset_add_del_members_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_add_del_members_reply>>()
{
  return ::vapi_msg_id_npol_ipset_add_del_members_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_add_del_members_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_add_del_members_reply>(vapi_msg_id_npol_ipset_add_del_members_reply);
}

template class Msg<vapi_msg_npol_ipset_add_del_members_reply>;

using Npol_ipset_add_del_members_reply = Msg<vapi_msg_npol_ipset_add_del_members_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_delete>(vapi_msg_npol_ipset_delete *msg)
{
  vapi_msg_npol_ipset_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_delete>(vapi_msg_npol_ipset_delete *msg)
{
  vapi_msg_npol_ipset_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_delete>()
{
  return ::vapi_msg_id_npol_ipset_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_delete>>()
{
  return ::vapi_msg_id_npol_ipset_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_delete>(vapi_msg_id_npol_ipset_delete);
}

template <> inline vapi_msg_npol_ipset_delete* vapi_alloc<vapi_msg_npol_ipset_delete>(Connection &con)
{
  vapi_msg_npol_ipset_delete* result = vapi_alloc_npol_ipset_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_ipset_delete>;

template class Request<vapi_msg_npol_ipset_delete, vapi_msg_npol_ipset_delete_reply>;

using Npol_ipset_delete = Request<vapi_msg_npol_ipset_delete, vapi_msg_npol_ipset_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_ipset_delete_reply>(vapi_msg_npol_ipset_delete_reply *msg)
{
  vapi_msg_npol_ipset_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_ipset_delete_reply>(vapi_msg_npol_ipset_delete_reply *msg)
{
  vapi_msg_npol_ipset_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_ipset_delete_reply>()
{
  return ::vapi_msg_id_npol_ipset_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_ipset_delete_reply>>()
{
  return ::vapi_msg_id_npol_ipset_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_ipset_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_ipset_delete_reply>(vapi_msg_id_npol_ipset_delete_reply);
}

template class Msg<vapi_msg_npol_ipset_delete_reply>;

using Npol_ipset_delete_reply = Msg<vapi_msg_npol_ipset_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_create>(vapi_msg_npol_rule_create *msg)
{
  vapi_msg_npol_rule_create_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_create>(vapi_msg_npol_rule_create *msg)
{
  vapi_msg_npol_rule_create_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_create>()
{
  return ::vapi_msg_id_npol_rule_create; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_create>>()
{
  return ::vapi_msg_id_npol_rule_create; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_create()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_create>(vapi_msg_id_npol_rule_create);
}

template <> inline vapi_msg_npol_rule_create* vapi_alloc<vapi_msg_npol_rule_create, size_t>(Connection &con, size_t rule_matches_array_size)
{
  vapi_msg_npol_rule_create* result = vapi_alloc_npol_rule_create(con.vapi_ctx, rule_matches_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_rule_create>;

template class Request<vapi_msg_npol_rule_create, vapi_msg_npol_rule_create_reply, size_t>;

using Npol_rule_create = Request<vapi_msg_npol_rule_create, vapi_msg_npol_rule_create_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_update>(vapi_msg_npol_rule_update *msg)
{
  vapi_msg_npol_rule_update_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_update>(vapi_msg_npol_rule_update *msg)
{
  vapi_msg_npol_rule_update_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_update>()
{
  return ::vapi_msg_id_npol_rule_update; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_update>>()
{
  return ::vapi_msg_id_npol_rule_update; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_update()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_update>(vapi_msg_id_npol_rule_update);
}

template <> inline vapi_msg_npol_rule_update* vapi_alloc<vapi_msg_npol_rule_update, size_t>(Connection &con, size_t rule_matches_array_size)
{
  vapi_msg_npol_rule_update* result = vapi_alloc_npol_rule_update(con.vapi_ctx, rule_matches_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_rule_update>;

template class Request<vapi_msg_npol_rule_update, vapi_msg_npol_rule_update_reply, size_t>;

using Npol_rule_update = Request<vapi_msg_npol_rule_update, vapi_msg_npol_rule_update_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_update_reply>(vapi_msg_npol_rule_update_reply *msg)
{
  vapi_msg_npol_rule_update_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_update_reply>(vapi_msg_npol_rule_update_reply *msg)
{
  vapi_msg_npol_rule_update_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_update_reply>()
{
  return ::vapi_msg_id_npol_rule_update_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_update_reply>>()
{
  return ::vapi_msg_id_npol_rule_update_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_update_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_update_reply>(vapi_msg_id_npol_rule_update_reply);
}

template class Msg<vapi_msg_npol_rule_update_reply>;

using Npol_rule_update_reply = Msg<vapi_msg_npol_rule_update_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_create_reply>(vapi_msg_npol_rule_create_reply *msg)
{
  vapi_msg_npol_rule_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_create_reply>(vapi_msg_npol_rule_create_reply *msg)
{
  vapi_msg_npol_rule_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_create_reply>()
{
  return ::vapi_msg_id_npol_rule_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_create_reply>>()
{
  return ::vapi_msg_id_npol_rule_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_create_reply>(vapi_msg_id_npol_rule_create_reply);
}

template class Msg<vapi_msg_npol_rule_create_reply>;

using Npol_rule_create_reply = Msg<vapi_msg_npol_rule_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_delete>(vapi_msg_npol_rule_delete *msg)
{
  vapi_msg_npol_rule_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_delete>(vapi_msg_npol_rule_delete *msg)
{
  vapi_msg_npol_rule_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_delete>()
{
  return ::vapi_msg_id_npol_rule_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_delete>>()
{
  return ::vapi_msg_id_npol_rule_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_delete>(vapi_msg_id_npol_rule_delete);
}

template <> inline vapi_msg_npol_rule_delete* vapi_alloc<vapi_msg_npol_rule_delete>(Connection &con)
{
  vapi_msg_npol_rule_delete* result = vapi_alloc_npol_rule_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_rule_delete>;

template class Request<vapi_msg_npol_rule_delete, vapi_msg_npol_rule_delete_reply>;

using Npol_rule_delete = Request<vapi_msg_npol_rule_delete, vapi_msg_npol_rule_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_rule_delete_reply>(vapi_msg_npol_rule_delete_reply *msg)
{
  vapi_msg_npol_rule_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_rule_delete_reply>(vapi_msg_npol_rule_delete_reply *msg)
{
  vapi_msg_npol_rule_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_rule_delete_reply>()
{
  return ::vapi_msg_id_npol_rule_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_rule_delete_reply>>()
{
  return ::vapi_msg_id_npol_rule_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_rule_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_rule_delete_reply>(vapi_msg_id_npol_rule_delete_reply);
}

template class Msg<vapi_msg_npol_rule_delete_reply>;

using Npol_rule_delete_reply = Msg<vapi_msg_npol_rule_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_create>(vapi_msg_npol_policy_create *msg)
{
  vapi_msg_npol_policy_create_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_create>(vapi_msg_npol_policy_create *msg)
{
  vapi_msg_npol_policy_create_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_create>()
{
  return ::vapi_msg_id_npol_policy_create; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_create>>()
{
  return ::vapi_msg_id_npol_policy_create; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_create()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_create>(vapi_msg_id_npol_policy_create);
}

template <> inline vapi_msg_npol_policy_create* vapi_alloc<vapi_msg_npol_policy_create, size_t>(Connection &con, size_t _rules_array_size)
{
  vapi_msg_npol_policy_create* result = vapi_alloc_npol_policy_create(con.vapi_ctx, _rules_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_policy_create>;

template class Request<vapi_msg_npol_policy_create, vapi_msg_npol_policy_create_reply, size_t>;

using Npol_policy_create = Request<vapi_msg_npol_policy_create, vapi_msg_npol_policy_create_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_create_reply>(vapi_msg_npol_policy_create_reply *msg)
{
  vapi_msg_npol_policy_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_create_reply>(vapi_msg_npol_policy_create_reply *msg)
{
  vapi_msg_npol_policy_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_create_reply>()
{
  return ::vapi_msg_id_npol_policy_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_create_reply>>()
{
  return ::vapi_msg_id_npol_policy_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_create_reply>(vapi_msg_id_npol_policy_create_reply);
}

template class Msg<vapi_msg_npol_policy_create_reply>;

using Npol_policy_create_reply = Msg<vapi_msg_npol_policy_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_update>(vapi_msg_npol_policy_update *msg)
{
  vapi_msg_npol_policy_update_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_update>(vapi_msg_npol_policy_update *msg)
{
  vapi_msg_npol_policy_update_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_update>()
{
  return ::vapi_msg_id_npol_policy_update; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_update>>()
{
  return ::vapi_msg_id_npol_policy_update; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_update()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_update>(vapi_msg_id_npol_policy_update);
}

template <> inline vapi_msg_npol_policy_update* vapi_alloc<vapi_msg_npol_policy_update, size_t>(Connection &con, size_t _rules_array_size)
{
  vapi_msg_npol_policy_update* result = vapi_alloc_npol_policy_update(con.vapi_ctx, _rules_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_policy_update>;

template class Request<vapi_msg_npol_policy_update, vapi_msg_npol_policy_update_reply, size_t>;

using Npol_policy_update = Request<vapi_msg_npol_policy_update, vapi_msg_npol_policy_update_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_update_reply>(vapi_msg_npol_policy_update_reply *msg)
{
  vapi_msg_npol_policy_update_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_update_reply>(vapi_msg_npol_policy_update_reply *msg)
{
  vapi_msg_npol_policy_update_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_update_reply>()
{
  return ::vapi_msg_id_npol_policy_update_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_update_reply>>()
{
  return ::vapi_msg_id_npol_policy_update_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_update_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_update_reply>(vapi_msg_id_npol_policy_update_reply);
}

template class Msg<vapi_msg_npol_policy_update_reply>;

using Npol_policy_update_reply = Msg<vapi_msg_npol_policy_update_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_delete>(vapi_msg_npol_policy_delete *msg)
{
  vapi_msg_npol_policy_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_delete>(vapi_msg_npol_policy_delete *msg)
{
  vapi_msg_npol_policy_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_delete>()
{
  return ::vapi_msg_id_npol_policy_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_delete>>()
{
  return ::vapi_msg_id_npol_policy_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_delete>(vapi_msg_id_npol_policy_delete);
}

template <> inline vapi_msg_npol_policy_delete* vapi_alloc<vapi_msg_npol_policy_delete>(Connection &con)
{
  vapi_msg_npol_policy_delete* result = vapi_alloc_npol_policy_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_policy_delete>;

template class Request<vapi_msg_npol_policy_delete, vapi_msg_npol_policy_delete_reply>;

using Npol_policy_delete = Request<vapi_msg_npol_policy_delete, vapi_msg_npol_policy_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_policy_delete_reply>(vapi_msg_npol_policy_delete_reply *msg)
{
  vapi_msg_npol_policy_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_policy_delete_reply>(vapi_msg_npol_policy_delete_reply *msg)
{
  vapi_msg_npol_policy_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_policy_delete_reply>()
{
  return ::vapi_msg_id_npol_policy_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_policy_delete_reply>>()
{
  return ::vapi_msg_id_npol_policy_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_policy_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_policy_delete_reply>(vapi_msg_id_npol_policy_delete_reply);
}

template class Msg<vapi_msg_npol_policy_delete_reply>;

using Npol_policy_delete_reply = Msg<vapi_msg_npol_policy_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_npol_configure_policies>(vapi_msg_npol_configure_policies *msg)
{
  vapi_msg_npol_configure_policies_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_configure_policies>(vapi_msg_npol_configure_policies *msg)
{
  vapi_msg_npol_configure_policies_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_configure_policies>()
{
  return ::vapi_msg_id_npol_configure_policies; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_configure_policies>>()
{
  return ::vapi_msg_id_npol_configure_policies; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_configure_policies()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_configure_policies>(vapi_msg_id_npol_configure_policies);
}

template <> inline vapi_msg_npol_configure_policies* vapi_alloc<vapi_msg_npol_configure_policies, size_t>(Connection &con, size_t _policy_ids_array_size)
{
  vapi_msg_npol_configure_policies* result = vapi_alloc_npol_configure_policies(con.vapi_ctx, _policy_ids_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_npol_configure_policies>;

template class Request<vapi_msg_npol_configure_policies, vapi_msg_npol_configure_policies_reply, size_t>;

using Npol_configure_policies = Request<vapi_msg_npol_configure_policies, vapi_msg_npol_configure_policies_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_npol_configure_policies_reply>(vapi_msg_npol_configure_policies_reply *msg)
{
  vapi_msg_npol_configure_policies_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_npol_configure_policies_reply>(vapi_msg_npol_configure_policies_reply *msg)
{
  vapi_msg_npol_configure_policies_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_npol_configure_policies_reply>()
{
  return ::vapi_msg_id_npol_configure_policies_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_npol_configure_policies_reply>>()
{
  return ::vapi_msg_id_npol_configure_policies_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_npol_configure_policies_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_npol_configure_policies_reply>(vapi_msg_id_npol_configure_policies_reply);
}

template class Msg<vapi_msg_npol_configure_policies_reply>;

using Npol_configure_policies_reply = Msg<vapi_msg_npol_configure_policies_reply>;
}
#endif

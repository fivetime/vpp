#ifndef __included_hpp_nat_api_json
#define __included_hpp_nat_api_json

#include <vapi/vapi.hpp>
#include <vapi/nat.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_set_external_interface>(vapi_msg_sfdp_nat_set_external_interface *msg)
{
  vapi_msg_sfdp_nat_set_external_interface_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_set_external_interface>(vapi_msg_sfdp_nat_set_external_interface *msg)
{
  vapi_msg_sfdp_nat_set_external_interface_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_set_external_interface>()
{
  return ::vapi_msg_id_sfdp_nat_set_external_interface; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_set_external_interface>>()
{
  return ::vapi_msg_id_sfdp_nat_set_external_interface; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_set_external_interface()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_set_external_interface>(vapi_msg_id_sfdp_nat_set_external_interface);
}

template <> inline vapi_msg_sfdp_nat_set_external_interface* vapi_alloc<vapi_msg_sfdp_nat_set_external_interface>(Connection &con)
{
  vapi_msg_sfdp_nat_set_external_interface* result = vapi_alloc_sfdp_nat_set_external_interface(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_nat_set_external_interface>;

template class Request<vapi_msg_sfdp_nat_set_external_interface, vapi_msg_sfdp_nat_set_external_interface_reply>;

using Sfdp_nat_set_external_interface = Request<vapi_msg_sfdp_nat_set_external_interface, vapi_msg_sfdp_nat_set_external_interface_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_set_external_interface_reply>(vapi_msg_sfdp_nat_set_external_interface_reply *msg)
{
  vapi_msg_sfdp_nat_set_external_interface_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_set_external_interface_reply>(vapi_msg_sfdp_nat_set_external_interface_reply *msg)
{
  vapi_msg_sfdp_nat_set_external_interface_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_set_external_interface_reply>()
{
  return ::vapi_msg_id_sfdp_nat_set_external_interface_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_set_external_interface_reply>>()
{
  return ::vapi_msg_id_sfdp_nat_set_external_interface_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_set_external_interface_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_set_external_interface_reply>(vapi_msg_id_sfdp_nat_set_external_interface_reply);
}

template class Msg<vapi_msg_sfdp_nat_set_external_interface_reply>;

using Sfdp_nat_set_external_interface_reply = Msg<vapi_msg_sfdp_nat_set_external_interface_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_alloc_pool_add_del>(vapi_msg_sfdp_nat_alloc_pool_add_del *msg)
{
  vapi_msg_sfdp_nat_alloc_pool_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_alloc_pool_add_del>(vapi_msg_sfdp_nat_alloc_pool_add_del *msg)
{
  vapi_msg_sfdp_nat_alloc_pool_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_alloc_pool_add_del>()
{
  return ::vapi_msg_id_sfdp_nat_alloc_pool_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_alloc_pool_add_del>>()
{
  return ::vapi_msg_id_sfdp_nat_alloc_pool_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_alloc_pool_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_alloc_pool_add_del>(vapi_msg_id_sfdp_nat_alloc_pool_add_del);
}

template <> inline vapi_msg_sfdp_nat_alloc_pool_add_del* vapi_alloc<vapi_msg_sfdp_nat_alloc_pool_add_del, size_t>(Connection &con, size_t _addr_array_size)
{
  vapi_msg_sfdp_nat_alloc_pool_add_del* result = vapi_alloc_sfdp_nat_alloc_pool_add_del(con.vapi_ctx, _addr_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_nat_alloc_pool_add_del>;

template class Request<vapi_msg_sfdp_nat_alloc_pool_add_del, vapi_msg_sfdp_nat_alloc_pool_add_del_reply, size_t>;

using Sfdp_nat_alloc_pool_add_del = Request<vapi_msg_sfdp_nat_alloc_pool_add_del, vapi_msg_sfdp_nat_alloc_pool_add_del_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>(vapi_msg_sfdp_nat_alloc_pool_add_del_reply *msg)
{
  vapi_msg_sfdp_nat_alloc_pool_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>(vapi_msg_sfdp_nat_alloc_pool_add_del_reply *msg)
{
  vapi_msg_sfdp_nat_alloc_pool_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>()
{
  return ::vapi_msg_id_sfdp_nat_alloc_pool_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>>()
{
  return ::vapi_msg_id_sfdp_nat_alloc_pool_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_alloc_pool_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>(vapi_msg_id_sfdp_nat_alloc_pool_add_del_reply);
}

template class Msg<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>;

using Sfdp_nat_alloc_pool_add_del_reply = Msg<vapi_msg_sfdp_nat_alloc_pool_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_snat_set_unset>(vapi_msg_sfdp_nat_snat_set_unset *msg)
{
  vapi_msg_sfdp_nat_snat_set_unset_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_snat_set_unset>(vapi_msg_sfdp_nat_snat_set_unset *msg)
{
  vapi_msg_sfdp_nat_snat_set_unset_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_snat_set_unset>()
{
  return ::vapi_msg_id_sfdp_nat_snat_set_unset; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_snat_set_unset>>()
{
  return ::vapi_msg_id_sfdp_nat_snat_set_unset; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_snat_set_unset()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_snat_set_unset>(vapi_msg_id_sfdp_nat_snat_set_unset);
}

template <> inline vapi_msg_sfdp_nat_snat_set_unset* vapi_alloc<vapi_msg_sfdp_nat_snat_set_unset>(Connection &con)
{
  vapi_msg_sfdp_nat_snat_set_unset* result = vapi_alloc_sfdp_nat_snat_set_unset(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sfdp_nat_snat_set_unset>;

template class Request<vapi_msg_sfdp_nat_snat_set_unset, vapi_msg_sfdp_nat_snat_set_unset_reply>;

using Sfdp_nat_snat_set_unset = Request<vapi_msg_sfdp_nat_snat_set_unset, vapi_msg_sfdp_nat_snat_set_unset_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sfdp_nat_snat_set_unset_reply>(vapi_msg_sfdp_nat_snat_set_unset_reply *msg)
{
  vapi_msg_sfdp_nat_snat_set_unset_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sfdp_nat_snat_set_unset_reply>(vapi_msg_sfdp_nat_snat_set_unset_reply *msg)
{
  vapi_msg_sfdp_nat_snat_set_unset_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sfdp_nat_snat_set_unset_reply>()
{
  return ::vapi_msg_id_sfdp_nat_snat_set_unset_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sfdp_nat_snat_set_unset_reply>>()
{
  return ::vapi_msg_id_sfdp_nat_snat_set_unset_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sfdp_nat_snat_set_unset_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sfdp_nat_snat_set_unset_reply>(vapi_msg_id_sfdp_nat_snat_set_unset_reply);
}

template class Msg<vapi_msg_sfdp_nat_snat_set_unset_reply>;

using Sfdp_nat_snat_set_unset_reply = Msg<vapi_msg_sfdp_nat_snat_set_unset_reply>;
}
#endif
